/* Study 6 ISGC + MVP */
drop table if exists gadb.daner_format;
drop table if exists gadb.daner_format2;
drop table if exists gadb.daner_format3;
drop table if exists gadb.daner_format4;

--create table gadb.daner_format
--create table gadb.daner_format2
create table gadb.daner_format3 
--create table gadb.daner_format4
(CHR varchar(50),
SNP varchar(50),
BP int,
A1 varchar(500),
A2 varchar(500),
FRQ_A float,
FRQ_U float,
info float,
EFFECT_SIZE float,
se float,
p float,
ngt int,
Direction varchar(100),
HetISqt float,
HetDf float,
HetPVa float,
Nca int,
Nco int,
Neff_half float,
Neff float);

COPY gadb.daner_format FROM 's3://itx-bhq-scratch/scratch_prj_qli2/daner_isgc_mvp_ALL_062821.neff.qc2.80.info0.6'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 NULL AS 'NA' BLANKSASNULL EMPTYASNULL REMOVEQUOTES  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY'; --6546679 record(s) loaded successfully.
COPY gadb.daner_format2 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/daner_isgc_mvp_EUR_062821.neff.qc2.80.info0.6'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 NULL AS 'NA' BLANKSASNULL EMPTYASNULL REMOVEQUOTES  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY'; --6861197 record(s) loaded successfully
COPY gadb.daner_format3 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/daner_isgc_mvp_AA_062821.neff.qc2.80.info0.6'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 NULL AS 'NA' BLANKSASNULL EMPTYASNULL REMOVEQUOTES  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY'; --10042934 record(s) loaded successfully
COPY gadb.daner_format4 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/daner_isgc_mvp_ASN_062821.neff.qc2.80.info0.6'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 NULL AS 'NA' BLANKSASNULL EMPTYASNULL REMOVEQUOTES  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY'; --4,800,366 record(s) loaded successfully
    
select * from gadb.daner_format where snp in ('rs6265');  --no record
select * from gadb.daner_format3 where snp in ('rs6265'); --hg19

create table gadb.isgc_and_mvp as
(select *, 'daner_isgc_mvp_ALL_062821.neff.qc2.80.info0.6' as source_file, snp || ':chr' || chr || ':' || bp || ':' || a1 || ':' || a2 as orig_snp, 'OR' as TYPE_OF_EFFECT_SIZE  
from gadb.daner_format
union
select *, 'daner_isgc_mvp_EUR_062821.neff.qc2.80.info0.6' as source_file, snp || ':chr' || chr || ':' || bp || ':' || a1 || ':' || a2 as orig_snp, 'OR' as TYPE_OF_EFFECT_SIZE
from gadb.daner_format2
union
select *, 'daner_isgc_mvp_AA_062821.neff.qc2.80.info0.6' as source_file, snp || ':chr' || chr || ':' || bp || ':' || a1 || ':' || a2 as orig_snp, 'OR' as TYPE_OF_EFFECT_SIZE
from gadb.daner_format3
union
select *, 'daner_isgc_mvp_ASN_062821.neff.qc2.80.info0.6' as source_file, snp || ':chr' || chr || ':' || bp || ':' || a1 || ':' || a2 as orig_snp, 'OR' as TYPE_OF_EFFECT_SIZE
from gadb.daner_format4);

select count(*) from gadb.isgc_and_mvp; --28,251,176
 
drop table if exists gadb.isgc_and_mvp_b38;
create table gadb.isgc_and_mvp_b38 as
select a.*, b.chr as chr_hg38, b.bp as pos_hg38 
from gadb.snp2hg38_coordinate b, gadb.isgc_and_mvp a
where b.orig_snp = a.orig_snp --check to see if right join is not working as expected and if gain more mapping if liftOver 
and b.orig_snp_build_ver in ('hg19');

select count(*) from gadb.isgc_and_mvp_b38; --26,045,926

select * from gadb.isgc_and_mvp_b38 where snp in ('rs626573');

select count(*) from gadb.hg192hg38; --91,491,600
desc gadb.hg192hg38;
select count(distinct(orig_snp)) from gadb.hg192hg38; --60,912,614

create table gadb.snp2hg38_coordinate as 
(select *, 'hg19' as orig_snp_build_ver from gadb.hg192hg38
union
select *, 'hg18' as orig_snp_build_ver from gadb.hg182hg38);

select orig_snp_build_ver, count(*) from gadb.snp2hg38_coordinate group by orig_snp_build_ver;
 


create table gadb.isgc_and_mvp_b38_snp_count as 
select snp, count(*) from gadb.isgc_and_mvp_b38 group by snp; 

select * from gadb.isgc_and_mvp_b38_snp_count limit 50;
select * from gadb.isgc_and_mvp_b38_snp_count where count > 4 limit 50;
select * from gadb.isgc_and_mvp_b38 where snp is null limit 10;
select distinct * from gadb.isgc_and_mvp_b38 where SNP in ('rs6265'); --hg19 11:27658369 (GRCh38)
                                                            -- 11:27679916 (GRCh37)
desc gadb.pgc3_gwas_b38;   
desc gadb.isgc_and_mvp_b38;      
select count(*) from gadb.isgc_and_mvp_b38; --110,280,198
INSERT INTO gadb.pgc3_gwas_b38 (snp, chr, bp, a1, a2, effect_size, type_of_effect_size, se, p, ngt, frq_a, frq_u, info, neff, nca, nco, direction, hetisqt, hetdf, hetpva, chr_hg38, pos_hg38, source_file) 
SELECT snp, chr, bp, a1, a2, effect_size, type_of_effect_size, se, p, ngt, frq_a, frq_u, info, neff, nca, nco, direction, hetisqt, hetdf, hetpva, chr_hg38, pos_hg38, source_file 
FROM gadb.isgc_and_mvp_b38; --110280198 rows affected

select * from gadb.isgc_and_mvp_b38 limit 50;

select * from stl_load_errors;
