select distinct sourceid from patient;

/* codes below from Grace Wang 10-30-18 */
drop table if exists scratch_qli2b.SA_Case;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_sa_date INTO scratch_qli2b.SA_Case
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2013-01-01' 
      AND   diagnosis_cd_type IN ('ICD9','ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
--      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup11
                             WHERE diaggroup in ('Suicidal attempt')))
GROUP BY ptid;

select count(distinct ptid) from scratch_qli2b.SA_Case; -- 333,381;

drop table if exists scratch_qli2b.SA_1;
SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.SA_1
FROM (SELECT ptid,
             birth_yr,
             gender,
             race,  ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')) a
  RIGHT JOIN scratch_qli2b.SA_Case b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_1; -- 330,770;

DROP TABLE if exists scratch_qli2b.SA_control;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.SA_control
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diag_date >= '2013-01-01' 
      AND   diagnosis_cd_type IN ('ICD9','ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
--      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup11
                             WHERE diaggroup in ('Suicidal attempt'))
)
AND   diag_date >= '2013-01-01'
GROUP BY ptid;



DROP TABLE if exists scratch_qli2b.SA_0;
SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.SA_0
FROM (SELECT ptid,
             birth_yr,
             gender,
             race,  ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')) a
  RIGHT JOIN scratch_qli2b.SA_Control b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_0; -- 64,676,102;

DROP TABLE if exists scratch_qli2b.SA_GRP_20181030;
SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_20181030
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_1
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_0)
WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) > 3;



-- select top 700 * from scratch_qli2b.SA_GRP_20181001;
SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20181030
GROUP BY grp_num;

-- grp_num=1 186,619;
-- grp_num=0 31,275,710;
/*

SAS codes: get_data_grp; grp_ps;
H:\HI_COE\QQ\2018_SA
*/


-- import data SA_0 from SAS;
select * from scratch_qli2b.sau2213_SA_GRP_PS_20181001_csv order by grp_num,ptid;

/* end of codes from Grace Wang */
