select distinct sourceid from patient;

select sourceid, count(sourceid) from patient group by sourceid;

select distinct region from patient;

select region, count(region) from patient group by region;

/* codes below from Grace Wang 10-30-18 */
drop table if exists scratch_qli2b.SA_Case_ICD10;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_sa_date INTO scratch_qli2b.SA_Case_ICD10
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      --WHERE diag_date >= '2018-01-01' --2015-10-01 previously
      WHERE diag_date >= '2015-10-01'
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt')))
GROUP BY ptid; 

select count(distinct ptid) from scratch_qli2b.SA_Case_ICD10; -- 155,460 (2015-10-1 comment out probelm list; 42,294 (2018-01-01); 149770 (2015-10-1)

drop table if exists scratch_qli2b.SA_1_ICD10;
SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.SA_1_ICD10
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      AND first_month_active <= 201510 --add for recurrent survivial model; not needed for case control model
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Case_ICD10 b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_1_ICD10 b; -- 154,783 before adding first_month_active criteria; 119060 after; 42126 (case control model); 
        -- add region check 106,243

DROP TABLE if exists scratch_qli2b.SA_control_ICD10;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.SA_control_ICD10
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      --WHERE diag_date >= '2018-01-01' --case control cohort
      WHERE diag_date >= '2015-10-01' --recurrent model cohort
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
)
--AND   diag_date >= '2018-01-01' --case control cohort
AND   diag_date >= '2015-10-01' --recurrent model cohort
AND   diagnosis_cd_type IN ('ICD10') --- added
AND   diagnosis_status IN ('Diagnosis of', 'History of') --- added
AND   problem_list IN ('N') --added
GROUP BY ptid;

DROP TABLE if exists scratch_qli2b.SA_0_ICD10;
SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.SA_0_ICD10
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      AND first_month_active <= 201510 --added for recurrent survivial model, not needed for case/control model
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Control_ICD10 b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_0_ICD10; --- 49,954,447 before adding the two conditions (diagnosis_cd and diagnosis_status);
                                                           --- 48,392,775 after adding the two conditions but before adding the first_month_active criteria;
                                                           --- 33,636,931 after the three changes
                                                           --- 24,823,573 case control cohort
                                                           --- 31,470,679 recurrent survivial model (add region check)

select * from scratch_qli2b.SA_GRP_20190521 where ptid in ('PT080124951');
/*
DROP TABLE if exists scratch_qli2b.SA_GRP_20190520;
SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_20190520
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_1_ICD10
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_0_ICD10)
--WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) > 3;
WHERE cast(substring(index_date,1,4) AS int) >= 2018;
*/
/*
DROP TABLE if exists scratch_qli2b.SA_GRP_20190521;
SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_20190521
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_1_ICD10
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_0_ICD10)
--WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) > 3;
WHERE cast(substring(index_date,1,4) AS int) >= 2017;
*/
DROP TABLE if exists scratch_qli2b.SA_GRP_20190709;
SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_20190709
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_1_ICD10
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_0_ICD10)
--WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) > 3;
WHERE cast(substring(index_date,1,4) AS int) >= 2016; 

DROP TABLE if exists scratch_qli2b.SA_GRP_20190610;
SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
        cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_20190610
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_1_ICD10
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_0_ICD10)
WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) >= 2; --previously > 3
--WHERE cast(substring(index_date,1,4) AS int) >= 2017; --for recurrent survivial model
/*
select index_date, count(ptid) from scratch_qli2b.SA_GRP_20190520 where grp_num = 1 group by index_date; --365
select min(first_month_active) from scratch_qli2b.SA_GRP_20190520;--200601
select max(first_month_active) from scratch_qli2b.SA_GRP_20190520;--201812  
*/
select max(diag_date) from native.diagnosis; --2018-12-31
select index_date, count(ptid) from scratch_qli2b.SA_GRP_20190521 where grp_num = 1 group by index_date; --731
select min(first_month_active) from scratch_qli2b.SA_GRP_20190521; --200601
select max(first_month_active) from scratch_qli2b.SA_GRP_20190521; --201510

select index_date, count(ptid) from scratch_qli2b.SA_GRP_20190709 where grp_num = 1 group by index_date; --1096
select min(first_month_active) from scratch_qli2b.SA_GRP_20190709; --200601
select max(first_month_active) from scratch_qli2b.SA_GRP_20190709; --201510

select index_date, count(ptid) from scratch_qli2b.SA_GRP_20190610 where grp_num = 1 group by index_date; --365
select min(first_month_active) from scratch_qli2b.SA_GRP_20190610; --200601
select max(first_month_active) from scratch_qli2b.SA_GRP_20190610; --201612

/*
SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20190520
GROUP BY grp_num;
--grp_num=1 44,160
--grp_num=0 25,522,953
*/

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20190521
GROUP BY grp_num;

--grp_num=1 70,843
--grp_num=0 25,942,964

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20190709
GROUP BY grp_num;

--grp_num=1 97,411
--grp_num=0 30,057,358

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20190610
GROUP BY grp_num;

--grp_num=1 
--grp_num=0 19,463,383

/*
SAS codes: get_data_grp; grp_ps;
H:\HI_COE\QQ\2018_SA
*/

-- import data SA_0 from SAS;

/*
drop table if exists scratch_qli2b.Optum_data_for_modeling_1_1_match_05212019;
CREATE TABLE scratch_qli2b.Optum_data_for_modeling_1_1_match_05212019 
(grp_num boolean,  
ptid                 char(11)       NOT NULL,
index_date varchar(16)           NOT NULL,
birth_yr             varchar(16),
gender               varchar(7),
race                 varchar(16),
ethnicity            varchar(12),
region               varchar(13),
first_month_active   varchar(6)     NOT NULL,
last_month_active    varchar(6)     NOT NULL,
dur float, 
age float);
*/

/*
drop table if exists scratch_qli2b.Optum_data_for_modeling_1_1_match_05212019;
CREATE TABLE scratch_qli2b.Optum_data_for_modeling_1_1_match_05212019 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);

COPY scratch_qli2b.Optum_data_for_modeling_1_1_match_05212019 FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_05212019_(2).txt_2019-05-21_194320'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
*/
/* http://10.37.94.22:8080/scratch_upload */
drop table if exists scratch_qli2b.Optum_data_for_modeling_1_1_match_06102019;
CREATE TABLE scratch_qli2b.Optum_data_for_modeling_1_1_match_06102019 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);

COPY scratch_qli2b.Optum_data_for_modeling_1_1_match_06102019 FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_06102019_(3).txt_2019-06-10_212053'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
        
select * from stl_load_errors;  
/*
select * from scratch_qli2b.sau2213_SA_GRP_PS_20190521_csv order by grp_num, ptid; 
*/

/* end of codes from Grace Wang */

drop table if exists scratch_qli2b.SA_GRP_20190521b;
create table scratch_qli2b.SA_GRP_20190521b as
(select * from scratch_qli2b.SA_GRP_20190521 where ptid in (select ptid from scratch_qli2b.Optum_data_for_modeling_1_1_match_05212019));

drop table if exists scratch_qli2b.SA_GRP_20190610b;
create table scratch_qli2b.SA_GRP_20190610b as
(select * from scratch_qli2b.SA_GRP_20190610 where ptid in (select ptid from scratch_qli2b.Optum_data_for_modeling_1_1_match_06102019));

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20190521b
GROUP BY grp_num; ---70,843*2

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20190610b
GROUP BY grp_num; ---32335*2

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_20190709b
GROUP BY grp_num;  ---95806*2

DROP TABLE if exists scratch_qli2b.medication_administrations;
create table scratch_qli2b.medication_administrations as 
(select * from native.medication_administrations where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and order_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.patient_reported_medications;
create table scratch_qli2b.patient_reported_medications as 
(select * from native.patient_reported_medications where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and reported_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.prescriptions_written;
create table scratch_qli2b.prescriptions_written as 
(select * from native.prescriptions_written where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and rxdate >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.diagnosis;
create table scratch_qli2b.diagnosis as 
(select * from native.diagnosis where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and diag_date >= '2015-10-1'
and diagnosis_cd_type IN ('ICD10'));

select a.*,b.diag_desc,b.diag_fst4_desc 
from native.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') ---PT251399534 ---PT226603638
and a.diagnosis_cd = b.diag_cd
order by diag_date;

select * from scratch_qli2b.lu_diagnosis b;

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in (select a.diagnosis_cd 
from scratch_qli2b.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') 
and a.diagnosis_cd = b.diag_cd);

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in ('R45851');

select distinct (source_id) from native.patient;

desc scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv;

select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1'); #410
select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 2'); # 47
select count(*) from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt'); #458
select * from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt') and diag_cd not in 
(select REPLACE(code, '.', '') from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1','Group 2'));
 
select * from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where code = '969.7';
