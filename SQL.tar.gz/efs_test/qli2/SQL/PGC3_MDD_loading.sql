/* Study 5 PGC3_MDD */
--CHROM  POS     ID      A1      A2      BETA    SE      PVAL    NGT     FCAS    FCON    IMPINFO NEFF    NCAS    NCON    DIRE    HETI    HETDF   HETPVAL
create table gadb.pgc3_mdd 
(CHR varchar(50),
BP int,
SNP varchar(50),
A1 varchar(50),
A2 varchar(50),
EFFECT_SIZE float,
se float,
p float,
ngt int,
FRQ_A float,
FRQ_U float,
info float,
Neff float,
SAMPLE_SIZE_A int,
SAMPLE_SIZE_U int,
Direction varchar(100),
HetISqt float,
HetDf float,
HetPVa float);

COPY gadb.pgc3_mdd FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pgc-mdd2022-no23andMe-eur-v3.49.24.11.pgc.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 NULL AS 'NA' BLANKSASNULL EMPTYASNULL REMOVEQUOTES  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY'; --7363302 record(s) loaded successfully
select * from gadb.pgc3_mdd where snp in ('rs6265'); -hg19

drop table if exists gadb.pgc3_mdd2;

create table gadb.pgc3_mdd2 as
select *, snp || ':chr' || chr || ':' || bp || ':' || a1 || ':' || a2 as orig_snp, 
 'pgc-mdd2022-no23andMe-eur-v3.49.24.11.pgc.txt' as sum_stat, 'PGC3_MDD' as folder,
 'pgc-mdd2022-no23andMe-eur' as phenotype, 'BETA' as TYPE_OF_EFFECT_SIZE  
from gadb.pgc3_mdd;

drop table if exists gadb.pgc3_mdd_b38;
create table gadb.pgc3_mdd_b38 as
select a.*, b.chr as chr_hg38, b.bp as pos_hg38 
from gadb.pgc3_mdd2 a, gadb.hg192hg38 b
where a.orig_snp(+) = b.orig_snp;

select distinct * from gadb.pgc3_mdd_b38 where SNP in ('rs6265'); --hg19 11:27658369 (GRCh38)
                                                            -- 11:27679916 (GRCh37)
desc gadb.pgc3_gwas_b38;   
desc gadb.pgc3_mdd_b38;      
select count(*) from gadb.pgc3_mdd_b38; --91491600
INSERT INTO gadb.pgc3_gwas_b38 (snp, chr, bp, a1, a2, effect_size, type_of_effect_size, se, p, ngt, frq_a, frq_u, info, neff, nca, nco, direction, hetisqt, hetdf, hetpva, chr_hg38, pos_hg38, source_file, reference) 
SELECT snp, chr, bp, a1, a2, effect_size, type_of_effect_size, se, p, ngt, frq_a, frq_u, info, neff, sample_size_a as nca, sample_size_u as nco, direction, hetisqt, hetdf, hetpva, chr_hg38, pos_hg38, sum_stat as source_file, folder as reference 
FROM gadb.pgc3_mdd_b38; --91491600 rows affected
