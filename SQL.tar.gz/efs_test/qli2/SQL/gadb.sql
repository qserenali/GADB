select distinct diaggroup, diag_cd, icd_ver_cd from scratch_qli2b.optum_diaggroup12 where diaggroup in ('BIP') order by icd_ver_cd;

/* test 

GRANT { { CREATE | USAGE } [,...] | ALL [ PRIVILEGES ] }
    ON SCHEMA schema_name [, ...]
    TO { username [ WITH GRANT OPTION ] | ROLE role_name | GROUP group_name | PUBLIC } [, ...]
*/
create schema gadb authorization qli2;
grant all on schema gadb to gadb_sa;
grant all on gadb.pgc_format to gadb_sa;
grant all on gadb.gene_info to gadb_sa;
grant all on gadb.GENE2REFSEQ to gadb_sa;
grant all on gadb.all_gwas_snps_b38 to gadb_sa;
grant all on gadb.mini_grasp to gadb_sa;
grant all on gadb.mini_nhgri to gadb_sa;
grant all on gadb.mini_additional_gwas to gadb_sa;
grant all on gadb.sumstats_harmonized_hg38 to gadb_sa;
grant all on gadb.sumstats_harmonized_b37_to_hg38 to gadb_sa;
grant all on gadb.sumstats_harmonized_b36_to_hg38 to gadb_sa;
grant all on gadb.ALL_QTL_SNPS_B38 to gadb_sa;
grant all on gadb.mini_grasp_qtl to gadb_sa;
grant all on gadb.mini_gtex_qtl to gadb_sa;
grant all on gadb.sumstats_harmonized to gadb_sa;

/* step 1 move the files to the s3 bucket */
--cd /domino/edv/neuroscience-efs/fromAGE/qli2/sumstat/data
--aws s3 sync Polimanti_2020  s3://itx-bhq-scratch/scratch_prj_qli2/ #with or without / copying the files only

/* step 2 load the tables reference Entrez Gene info */

drop table if exists gadb.gene_info;
create table gadb.gene_info 
(tax_id int,
 GeneID int,
 Symbol char(25),
 LocusTag char(25),
 Synonyms char(255),
 dbXrefs char(255),
 chromosome char(10),
 map_location char(50),
 description char(255),
 type_of_gene char(255),
 Symbol_from_nomenclature_authority char(25),
 Full_name_from_nomenclature_authority char(255),
 Nomenclature_status char(25),
 Other_designations VARCHAR(40960),
 Modification_date int,
 Feature_type char(500));
 
COPY gadb.gene_info FROM 's3://itx-bhq-scratch/scratch_prj_qli2/gene_info.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 
    
select * from stl_load_errors;

drop table if exists gadb.gene2refseq;
create table gadb.gene2refseq
(tax_id int,
 GeneID int,
 status char(50),
 RNA_nucleotide_accession_version char(50),
 RNA_nucleotide_gi char(50),
 protein_accession_version char(50),
 protein_gi char(50),
 genomic_nucleotide_accession_version char(50),
 genomic_nucleotide_gi char(50),
 start_position_on_the_genomic_accession char(20),
 end_position_on_the_genomic_accession char(20),
 orientation char(4),
 assembly char(50),
 mature_peptide_accession_version char(50),
 mature_peptide_gi char(50),
 Symbol char(25));
 
select * from stl_load_errors;

COPY gadb.gene2refseq FROM 's3://itx-bhq-scratch/scratch_prj_qli2/gene2refseq.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 
    
create table gadb.gene2ensembl
(tax_id int,
 GeneID int,
 Ensembl_gene_identifier char(50),
 RNA_nucleotide_accession_version char(50),
 Ensembl_rna_identifier char(59),
 protein_accession_version char(50),
 Ensembl_protein_identifier char(59));
 
COPY gadb.gene2ensembl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/gene2ensembl.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 

drop table if exists gadb.gene2accession;
create table gadb.gene2accession
(tax_id int,
 GeneID int,
 status char(50),
 RNA_nucleotide_accession_version char(50),
 RNA_nucleotide_gi char(50),
 protein_accession_version char(50),
 protein_gi char(50),
 genomic_nucleotide_accession_version char(50),
 genomic_nucleotide_gi char(50),
 start_position_on_the_genomic_accession char(10),
 end_position_on_the_genomic_accession char(10),
 orientation char(5),
 assembly char(50),
 mature_peptide_accession_version char(50),
 mature_peptide_gi char(50),
 Symbol char(50));
 
COPY gadb.gene2accession FROM 's3://itx-bhq-scratch/scratch_prj_qli2/gene2accession.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 

/* Load GRASP */
drop table if exists gadb.GRASP;    
create table gadb.GRASP
(NHLBIkey char(255),
 HUPfield char(50),
 LastCurationDate char(50),
 CreationDate char(50),
 SNPid_dbSNP134 char(50),
 chr_hg38 char(255),
 pos_hg38 char(255),
 PMID char(255),
 SNPid_in_paper varchar(2000),
 LocationWithinPaper char(50),
 Pvalue char(255),
 Phenotype varchar(1000),
 PaperPhenotypeDescription varchar(1000),
 PaperPhenotypeCategories varchar(1000),
 InGene varchar(2000),
 NearestGene char(50),
 InLincRNA char(255),
 InMiRNA char(255),
 InMiRNABS varchar(2000),
 dbSNPfxn char(500),
 dbSNPMAF char(50),
 dbSNPvalidation char(50),
 dbSNPClinStatus char(50),
 ORegAnno varchar(2000),
 ConservPredTFBS varchar(2000), 
 HumanEnhancer char(255),
 RNAedit varchar(1000),
 PolyPhen2 char(255),
 SIFT char(50),
 IS_SNP varchar(20000),  
 UniProt varchar(2000),
 EqtlMethMetabStudy char(10));

COPY gadb.GRASP FROM 's3://itx-bhq-scratch/scratch_prj_qli2/GRASP2fullDataset.hg38.abb.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'MON/DD/YY';

drop table if exists gadb.GRASP_STUDIES;    
CREATE TABLE gadb.GRASP_STUDIES
(
  FIRST_AUTHOR             VARCHAR(250),
  PUBMEDID                 VARCHAR(255),
  GRASPVERSION             VARCHAR(25),
  NO_RESULTS_FLAG          CHAR(1),
  N_RESULTS                INTEGER,
  X_QTL_FLAG               CHAR(1),
  PHENOTYPE_DESCRIPTION    VARCHAR(1000),
  PHENOTYPE_CAT_ASSIGNED   VARCHAR(500),
  DATEPUB                  varchar(255),
  NHGRI_FLAG               CHAR(1),
  JOURNAL                  VARCHAR(50),
  STUDY                    VARCHAR(1000)        NOT NULL,
  SAMPLE_PLACES_MENTIONED  VARCHAR(125),
  M_F_ONLY_FLAG            CHAR(255),
  EXCLUSIVELY_M_F_FLAG     CHAR(255),
  INITIAL_SAMPLE_SIZE      VARCHAR(2000),
  REPLICATION_SAMPLE_SIZE  VARCHAR(2000),
  PLATFORM_QC              VARCHAR(100),
  POPULATION_DESC          VARCHAR(30),
  TOTAL_SAMPLE_SIZE        char(255),
  DIS_SAMPLE_SIZE          INTEGER,
  EUROPEAN_DIS             INTEGER,
  AFRICAN_ANCESTRY_DIS     INTEGER,
  EAST_ASIAN_DIS           INTEGER);
 /* ,
  INDIAN_SOUTH_ASIAN_DIS   INTEGER,
  HISPANIC_DIS             INTEGER,
  NATIVE_DIS               INTEGER,
  MICRONESIAN_DIS          INTEGER,
  ARAB_ME_DIS              INTEGER,
  MIXED_DIS                INTEGER,
  UNSPEC_DIS               INTEGER,
  FILIPINO_DIS             INTEGER,
  INDONESIAN_DIS           INTEGER,
  REP_SAMPLE_SIZE          INTEGER,
  EUROPEAN_REP             INTEGER,
  AFRICAN_ANCESTRY_REP     INTEGER,
  EAST_ASIAN_REP           INTEGER,
  INDIAN_SOUTH_ASIAN_REP   INTEGER,
  HISPANIC_REP             INTEGER,
  NATIVE_REP               INTEGER,
  MICRONESIAN_REP          INTEGER,
  ARAB_ME_REP              INTEGER,
  MIXED_REP                INTEGER,
  UNSPEC_REP               INTEGER,
  FILIPINO_REP             INTEGER,
  INDONESIAN_REP           INTEGER
);*/

COPY gadb.GRASP_STUDIES FROM 's3://itx-bhq-scratch/scratch_prj_qli2/GRASP2_List_Of_Studies.txt_first_24_columns'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY';
    
--more GRASP2_List_Of_Studies.txt|cut -f1-24 >GRASP2_List_Of_Studies.txt_first_24_columns
--sed -i "s/\xfb/ /g" GRASP2_List_Of_Studies.txt_first_24_columns
--sed -i "s/\xe7/c/g" GRASP2_List_Of_Studies.txt_first_24_columns
--sed -i "s/\xe4/a/g" GRASP2_List_Of_Studies.txt_first_24_columns
--sed -i "s/\xe2/1/g" GRASP2_List_Of_Studies.txt_first_24_columns #manually correct Abeta tau

select * from stl_load_errors;

--sed -i "s/\x92/'/g" GRASP2fullDataset.hg38.abb.txt -- replace hex <92> (')
--sed -i "s/\xe7/c/g" GRASP2fullDataset.hg38.abb.txt --replace Latin c?
--sed -i "s/\x96/ /g" GRASP2fullDataset.hg38.abb.txt -- not sure
--sed -i "s/\xb5/u/g" GRASP2fullDataset.hg38.abb.txt --Latin micro symbol
--sed -i "s/\xfb/ /g" GRASP2fullDataset.hg38.abb.txt


/* Load NHGRI content load in 2 waves due to data loading issues */
drop table if exists gadb.NHGRI2;   
create table gadb.NHGRI2
(DATE_ADDED_TO_CATALOG date,
 PUBMEDID char(255),
 FIRST_AUTHOR char(100),
 PUB_DATE varchar(255),    
 JOURNAL char(255),
 LINK char(255),
 STUDY varchar(1000),
 DISEASE_TRAIT varchar(1000),
 INITIAL_SAMPLE_SIZE varchar(1000),
 REPLICATION_SAMPLE_SIZE varchar(1000),
 REGION char(255),
 CHR_ID char(255),
 CHR_POS char(255),
 REPORTED_GENES varchar(2000),
 MAPPED_GENE varchar(2000),
 UPSTREAM_GENE_ID char(255),
 DOWNSTREAM_GENE_ID char(255),
 SNP_GENE_IDS varchar(1000),
 UPSTREAM_GENE_DISTANCE int,
 DOWNSTREAM_GENE_DISTANCE int,
 STRONGEST_SNP_RISK_ALLELE varchar(2000),
 SNPS varchar(2000),
 MERGED int,
 SNP_ID_CURRENT varchar(1000),
 CONTEXT varchar(2000),
 INTERGENIC int,
 RISK_ALLELE_FREQUENCY varchar(255),
 P_VALUE char(255),
 PVALUE_MLOG varchar(1000),
 P_VALUE_TEXT varchar(1000),
 OR_or_BETA float,
 CI_95_TEXT varchar(255),
 PLATFORM_SNPS_PASSING_QC char(255),
 CNV char(5),
 MAPPED_TRAIT varchar(1000),
 MAPPED_TRAIT_URI varchar(1000),        
 STUDY_ACCESSION char(255),
 GENOTYPING_TECHNOLOGY varchar(1000));
 
COPY gadb.NHGRI FROM 's3://itx-bhq-scratch/scratch_prj_qli2/gwas_catalog_v1.0.2-associations_e105_r2022-04-07.tsv_edited'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'YYYY-MM-DD';
COPY gadb.NHGRI2 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/gwas_catalog_v1.0.2-associations_e105_r2022-04-07.tsv_for_troubleshooting2'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'YYYY-MM-DD'; 

--manipulating in R fixed the delimiter issue --    

drop table if exists gadb.NHGRI_all;

create table gadb.NHGRI_all as
select * from gadb.NHGRI
union
select * from gadb.NHGRI2;

select count(*) from gadb.NHGRI_all; --372641 -- The UNION operator removes eliminate duplicate rows,
select count(*) from gadb.NHGRI;  --371536
select count(*) from gadb.NHGRI2; --1216
select count(*) from gadb.GRASP; --8,840,795

--awk -v FS="\t" -v OFS="\t" '{if ($2 != 31339356 && $2 != 30643258 && $2 != 34159505) print}' gwas_catalog_v1.0.2-associations_e105_r2022-04-07.tsv >gwas_catalog_v1.0.2-associations_e105_r2022-04-07.tsv_edited     
--awk -v FS="\t" -v OFS="\t" '{if ($2 == 31339356 || $2 == 30643258 || $2 == 34159505) print}' gwas_catalog_v1.0.2-associations_e105_r2022-04-07.tsv >gwas_catalog_v1.0.2-associations_e105_r2022-04-07.tsv_for_troubleshooting
select * from pgx_owner.DBSNP150_HG19 where snp_id = 'rs6265'; --11:27658369 (GRCh38)
                                                               --11:27679916 (GRCh37)
more unique_snps_in_hg19_to_be_lifted.out|awk '{if ($4=="rs6265") print}'
chr11   27658368        27658369        rs6265
[qli2@awsbjynva1097 results]$ more unique_snps_in_hg18_to_be_lifted.out|awk '{if ($4=="rs6265") print}'
chr11   27658368        27658369        rs6265

/* select set of overlapping columns to prepare materialized view of the union between different data sources */
create table gadb.mini_NHGRI as
(SELECT DISTINCT
          a.SNPS AS SNP_ID,
          a.mapped_trait AS phenotype,
          a.p_value as pvalue,
	        '' || a.PUB_DATE AS DATE_PUBLISHED,
          '' || a.PUBMEDID AS PMID,
          a.CHR_ID,
          a.CHR_POS,
          a.DISEASE_TRAIT AS PHENOTYPE_CATEGORY,
          a.MAPPED_GENE AS IN_GENE,
             'Initial sample size: '
          || a.INITIAL_SAMPLE_SIZE
          || '; Replication sample size: '
          || a.REPLICATION_SAMPLE_SIZE
             AS TOTAL_SAMPLE_SIZE,
          'NHGRI-EBI_GWAS_CATALOG' AS DATASOURCE
     FROM gadb.NHGRI_all a);

drop table if exists gadb.mini_grasp;     
create table gadb.mini_grasp as
 (SELECT DISTINCT b.snpid_in_paper as snp_id,
                  b.phenotype,
                  b.pvalue,
		              '' || a. DATEPUB as DATE_PUBLISHED,
                  '' || a.PUBMEDID AS PMID,
                  b.CHR_hg38 as chr_id,
                  b.pos_hg38 as chr_pos,
                  b.paperphenotypecategories AS PHENOTYPE_CATEGORY,
                  b.ingene as IN_GENE,
                  a.TOTAL_SAMPLE_SIZE AS TOTAL_SAMPLE_SIZE,
                  'GRASP' AS DATASOURCE
    FROM gadb.GRASP_STUDIES a, gadb.GRASP b
    WHERE a.PUBMEDID = b.PMID
    AND a.X_QTL_FLAG IS NULL);

drop table if exists gadb.mini_additional_gwas;   
create table gadb.mini_additional_gwas as
(SELECT DISTINCT
           snp as snp_id,
           sum_stat as phenotype,
           cast (pvalue as varchar),
	         '' as DATE_PUBLISHED,
           '' AS PMID,
           replace(CHR_hg38, 'chr', '')  as CHR_ID,
           cast(a.pos_hg38 as varchar) as CHR_POS,
           phenotype AS PHENOTYPE_CATEGORY,
           '' as IN_GENE,
           'NCase: ' || NCAS || '; NControl: ' || NCON || '; N: ' || n || ';Neff: ' || neff as TOTAL_SAMPLE_SIZE,
           folder AS DATASOURCE
      FROM gadb.sumstats_harmonized_hg38 a);

select distinct X_QTL_FLAG from gadb.GRASP_STUDIES;
select * from gadb.GRASP limit 5;
select distinct eqtlmethmetabstudy from gadb.GRASP;

/* Divide the results into disease/trait associations and xQTL associations, 2 QTL sources for now GRASP based on the study flag or the result flag and GTEx */
drop table if exists gadb.mini_grasp_QTL;    
create table gadb.mini_grasp_QTL as
 (SELECT DISTINCT b.snpid_in_paper as snp_id,
                  b.phenotype,
                  b.pvalue,
		              '' || a. DATEPUB as DATE_PUBLISHED,
                  '' || a.PUBMEDID AS PMID,
                  b.CHR_hg38 as chr_id,
                  b.pos_hg38 as chr_pos,
                  b.paperphenotypecategories AS PHENOTYPE_CATEGORY,
                  b.ingene as IN_GENE,
                  a.TOTAL_SAMPLE_SIZE AS TOTAL_SAMPLE_SIZE,
                  'GRASP' AS DATASOURCE
    FROM gadb.GRASP_STUDIES a, gadb.GRASP b
    WHERE a.PUBMEDID = b.PMID
    AND (a.X_QTL_FLAG in (1) or b.eqtlmethmetabstudy in (1)));

drop table if exists gadb.QTL; 
create table gadb.QTL 
(chr char(255),
 pos char(255),
 ref varchar(2000),
 alt varchar(2000),
 build char(3),
 gene_id varchar(50),
 tss_distance int,
 ma_samples int,
 ma_count int,
 maf float,
 pval_nominal float,
 slope float,   
 slope_se float,
 pval_nominal_threshold float,       
 min_pval_nominal float,        
 pval_beta float,       
 is_ciQTL int,      
 Tissue varchar(50),  
 Source varchar(50),
 DatasourceVersion varchar(50));
 
select * from stl_load_errors;
 
COPY gadb.QTL FROM 's3://itx-bhq-scratch/scratch_prj_qli2/GTEx_Brain.v8.signif_variant_gene_pairs3.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'YYYY-MM-DD';

drop table if exists gadb.QTL2;

create table gadb.QTL2 as
select replace(chr, 'chr', '') as chr_id, substring(gene_id, 0, 16) as ensembl_gene_identifier, a.* from gadb.QTL a;    

select * from gadb.QTL2 limit 5;

drop table if exists gadb.mini_GTEx_QTL; 

create table gadb.mini_GTEx_QTL as
 (SELECT DISTINCT chr_id || '_' || pos || '_' || ref || '_' || alt as snp_id, 
                  'Gene expression of ' || c.symbol || ' in ' || Tissue as phenotype,
                  cast(b.pval_nominal as varchar) as pvalue,
		              '' as DATE_PUBLISHED,
                  '' as PMID,
                  chr_id,
                  b.pos as chr_pos,
                  'Brain eQTL' as PHENOTYPE_CATEGORY,
                  c.symbol as IN_GENE,
                  cast(ma_count as varchar) as TOTAL_SAMPLE_SIZE,
                  DatasourceVersion as DATASOURCE
    FROM gadb.gene2ensembl a, gadb.QTL2 b, gadb.gene_info c
    where a.ensembl_gene_identifier = b.ensembl_gene_identifier (+)
    and a.geneid = c.geneid);
    
--drop table if exists gadb.ALL_GWAS_SNPS_B38;
--CREATE table gadb.ALL_GWAS_SNPS_B38

drop MATERIALIZED VIEW gadb.ALL_GWAS_SNPS_B38;

select * from gadb.mini_nhgri where chr_pos like '%;%';
select * from gadb.mini_nhgri where chr_pos like '%x%';

create MATERIALIZED VIEW gadb.ALL_GWAS_SNPS_B38
as
(select snp_id, phenotype, pvalue, date_published, pmid, chr_id, cast(chr_pos as integer), phenotype_category, in_gene, total_sample_size, datasource from gadb.mini_nhgri
where chr_pos not like '%;%' and chr_pos not like '%x%'
union
select snp_id, phenotype, pvalue, date_published, pmid, chr_id, cast(chr_pos as integer), phenotype_category, in_gene, total_sample_size, datasource  from gadb.mini_grasp
union all
select snp_id, phenotype, pvalue, date_published, pmid, chr_id, cast(chr_pos as integer), phenotype_category, in_gene, total_sample_size, datasource  from gadb.mini_additional_gwas);


 
select count(*) from gadb.mini_GTEx_QTL; --7,548,220
select count(*) from gadb.mini_grasp_qtl; -- 993,567
select count(*) from gadb.ALL_QTL_SNPS_B38; --8,541,787
select count(*) from gadb.grasp; --8840796

drop MATERIALIZED VIEW gadb.ALL_QTL_SNPS_B38;

create MATERIALIZED VIEW gadb.ALL_QTL_SNPS_B38
as
(select * from gadb.mini_GTEx_QTL
union
select * from gadb.mini_grasp_qtl);

select * from gadb.nhgri_all where snps in  ('rs11688303'); -- where snp_id_current = 11688303; -- limit 5; --where SNPS in single quote works double quotes do not
select * from gadb.all_gwas_snps_b38 where snp_id in  ('rs11688303');

select * from stl_load_errors;


 



