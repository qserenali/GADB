/*extract patients diagnosed with suicide */
CREATE TABLE scratch_stellasw.sui AS 
select distinct * from (
     SELECT ptid,
     diagnosis_cd AS diag,
     diag_date,
     'SUI' AS CAT 
     FROM diagnosis /*diagnosis*/ 
WHERE diagnosis_cd IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total) /*suicidal_total is the files with all ICD code of suicide*/
AND   diagnosis_status IN ('Diagnosis of')
AND   problem_list = 'N'
UNION
SELECT ptid,
       diag1 AS diag,
       fst_dt AS diag_date,
       'SUI' AS CAT
FROM medical_claims /*medical_claims*/ 
WHERE diag1 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag2 AS diag,
       fst_dt AS diag_date,
       'SUI' AS CAT
FROM medical_claims
WHERE diag2 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag3 AS diag,
       fst_dt AS diag_date,
       'SUI' AS CAT
FROM medical_claims
WHERE diag3 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag4 AS diag,
       fst_dt AS diag_date,
       'SUI' AS CAT
FROM medical_claims
WHERE diag4 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag5 AS diag,
       fst_dt AS diag_date,
       'SUI' AS CAT
FROM medical_claims
WHERE diag5 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag1 AS diag,
       ADMIT_DATE AS diag_date,
       'SUI' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE diag1 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag2 AS diag,
       ADMIT_DATE AS diag_date,
       'SUI' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE diag2 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag3 AS diag,
       ADMIT_DATE AS diag_date,
       'SUI' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE diag3 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag4 AS diag,
       ADMIT_DATE AS diag_date,
       'SUI' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE diag4 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total)
UNION
SELECT ptid,
       diag5 AS diag,
       ADMIT_DATE AS diag_date,
       'SUI' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE diag5 IN (SELECT DISTINCT code FROM scratch_stellasw.suicidal_total))where diag_date between '2007-06-01' and '2017-06-30'; /*time frame*/
-------------------------------------

SELECT COUNT(DISTINCT ptid) FROM scratch_stellasw.sui /*241,253*/;

/*distinct patients ID for patients diagnosed with suicide*/
create table scratch_stellasw.indexid as
select distinct ptid from scratch_stellasw.sui

-----control group
/*control*/
/*patients with schizophrenia, schizoaffective, bipolarI, MDD*/
/*Time frame: 06/01/2017~ 06/30/2017*/
/*exclude suicide patients*/
create table scratch_stellawangsw.control as
select distinct * from (
SELECT ptid,
     diagnosis_cd AS diag,
     diag_date,
     'control' AS CAT 
     FROM diagnosis /*diagnosis*/ 
WHERE (diagnosis_cd ilike '2951%'
or diagnosis_cd ilike '2952%'
or diagnosis_cd ilike '2953%'
or diagnosis_cd ilike '2956%'
or diagnosis_cd ilike '2957%'
or diagnosis_cd ilike '2959%'
or diagnosis_cd ilike '2960%'
or diagnosis_cd ilike '2961%'
or diagnosis_cd ilike '2962%'
or diagnosis_cd ilike '2963%'
)
AND   diagnosis_status IN ('Diagnosis of')
AND   problem_list = 'N'
AND ptid not in (select* from scratch_stellawangsw.indexid) /*indexid is the suicide diagnosed patients' ID*/

UNION
SELECT ptid,
       diag1 AS diag,
       fst_dt AS diag_date,
       'control' AS CAT
FROM medical_claims /*medical_claims*/ 
WHERE (diag1 ilike '2951%'
or diag1 ilike '2952%'
or diag1 ilike '2953%'
or diag1 ilike '2956%'
or diag1 ilike '2957%'
or diag1 ilike '2959%'
or diag1 ilike '2960%'
or diag1 ilike '2961%'
or diag1 ilike '2962%'
or diag1 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

UNION

SELECT ptid,
       diag2 AS diag,
       fst_dt AS diag_date,
       'control' AS CAT
FROM medical_claims /*medical_claims*/ 
WHERE (diag2 ilike '2951%'
or diag2 ilike '2952%'
or diag2 ilike '2953%'
or diag2 ilike '2956%'
or diag2 ilike '2957%'
or diag2 ilike '2959%'
or diag2 ilike '2960%'
or diag2 ilike '2961%'
or diag2 ilike '2962%'
or diag2 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

UNION

SELECT ptid,
       diag3 AS diag,
       fst_dt AS diag_date,
       'control' AS CAT
FROM medical_claims /*medical_claims*/ 
WHERE (diag3 ilike '2951%'
or diag3 ilike '2952%'
or diag3 ilike '2953%'
or diag3 ilike '2956%'
or diag3 ilike '2957%'
or diag3 ilike '2959%'
or diag3 ilike '2960%'
or diag3 ilike '2961%'
or diag3 ilike '2962%'
or diag3 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

UNION
SELECT ptid,
       diag4 AS diag,
       fst_dt AS diag_date,
       'control' AS CAT
FROM medical_claims /*medical_claims*/ 
WHERE (diag4 ilike '2951%'
or diag4 ilike '2952%'
or diag4 ilike '2953%'
or diag4 ilike '2956%'
or diag4 ilike '2957%'
or diag4 ilike '2959%'
or diag4 ilike '2960%'
or diag4 ilike '2961%'
or diag4 ilike '2962%'
or diag4 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

UNION
SELECT ptid,
       diag5 AS diag,
       fst_dt AS diag_date,
       'control' AS CAT
FROM medical_claims /*medical_claims*/ 
WHERE (diag5 ilike '2951%'
or diag5 ilike '2952%'
or diag5 ilike '2953%'
or diag5 ilike '2956%'
or diag5 ilike '2957%'
or diag5 ilike '2959%'
or diag5 ilike '2960%'
or diag5 ilike '2961%'
or diag5 ilike '2962%'
or diag5 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

/*inpatient_confinement*/
union
SELECT ptid,
       diag1 AS diag,
       ADMIT_DATE AS diag_date,
       'control' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE (diag1 ilike '2951%'
or diag1 ilike '2952%'
or diag1 ilike '2953%'
or diag1 ilike '2956%'
or diag1 ilike '2957%'
or diag1 ilike '2959%'
or diag1 ilike '2960%'
or diag1 ilike '2961%'
or diag1 ilike '2962%'
or diag1 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)


union
SELECT ptid,
       diag2 AS diag,
       ADMIT_DATE AS diag_date,
       'control' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE (diag2 ilike '2951%'
or diag2 ilike '2952%'
or diag2 ilike '2953%'
or diag2 ilike '2956%'
or diag2 ilike '2957%'
or diag2 ilike '2959%'
or diag2 ilike '2960%'
or diag2 ilike '2961%'
or diag2 ilike '2962%'
or diag2 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

union
SELECT ptid,
       diag3 AS diag,
       ADMIT_DATE AS diag_date,
       'control' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE (diag3 ilike '2951%'
or diag3 ilike '2952%'
or diag3 ilike '2953%'
or diag3 ilike '2956%'
or diag3 ilike '2957%'
or diag3 ilike '2959%'
or diag3 ilike '2960%'
or diag3 ilike '2961%'
or diag3 ilike '2962%'
or diag3 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

union
SELECT ptid,
       diag4 AS diag,
       ADMIT_DATE AS diag_date,
       'control' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE (diag4 ilike '2951%'
or diag4 ilike '2952%'
or diag4 ilike '2953%'
or diag4 ilike '2956%'
or diag4 ilike '2957%'
or diag4 ilike '2959%'
or diag4 ilike '2960%'
or diag4 ilike '2961%'
or diag4 ilike '2962%'
or diag4 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)

union
SELECT ptid,
       diag5 AS diag,
       ADMIT_DATE AS diag_date,
       'control' AS CAT
FROM inpatient_confinement /*select patients from inpatient_confinement table*/ 
WHERE (diag5 ilike '2951%'
or diag5 ilike '2952%'
or diag5 ilike '2953%'
or diag5 ilike '2956%'
or diag5 ilike '2957%'
or diag5 ilike '2959%'
or diag5 ilike '2960%'
or diag5 ilike '2961%'
or diag5 ilike '2962%'
or diag5 ilike '2963%'
)AND ptid not in (select* from scratch_stellawangsw.indexid)) where diag_date between '2007-06-01' and '2017-06-30'
;

/* 10-9-2017
http://awsagunva1041.jnj.com:7980/SASLogon/login?service=http%3A%2F%2Fawsagunva1041.jnj.com%3A7980%2FSASStudio%2Fj_spring_cas_security_check 
library/export, file/download, upload to http://10.37.94.22:8080/scratch_upload 

Example from Grace Wang
create table scratch_gwang22_260.HE_md_dm_final (
patid bigint,
dx_depression varchar(255),
age int,
sex varchar(255),
index_ad_date date,
trd varchar(255)
);

COPY scratch_gwang22_260.HE_md_dm_final FROM 's3://itx-agu-scratch-import/MDD.csv_2017-03-08_150847'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY'; 
*/

CREATE TABLE scratch_qli2.random1
(
   ptid                 char(11)       NOT NULL,
   birth_yr             varchar(16),
   gender               varchar(7),
   race                 varchar(16),
   ethnicity            varchar(12),
   region               varchar(13),
   division             varchar(30),
   avg_hh_income        float8,
   pct_college_educ     float8,
   deceased_indicator   varchar(11),
   date_of_death        char(6),
   provid_pcp           varchar(8),
   idn_indicator        char(1)        NOT NULL,
   first_month_active   varchar(6)     NOT NULL,
   last_month_active    varchar(6)     NOT NULL,
   notes_eligible       char(1)        NOT NULL,
   has_notes            char(1)        NOT NULL,
   sourceid             varchar(5)     NOT NULL,
   source_data_through  varchar(6)     NOT NULL,
   integrated           char(1)
);

COPY scratch_qli2.random1 FROM 's3://itx-agu-scratch-import/RANDOM1.csv_2017-10-09_145309'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY'; 

/*
Warnings:
Load into table 'random1' completed, 318431 record(s) loaded successfully.

0 rows affected
COPY executed successfully

Execution time: 1m 31s
*/
drop table scratch_qli2.optum_diagGroup;

CREATE TABLE scratch_qli2.optum_diagGroup
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_desc       varchar(100),
   diag_fst3_cd    varchar(3),
   diag_fst3_desc  varchar(40),
   diag_fst4_cd    varchar(4),
   diag_fst4_desc  varchar(40),
   gdr_spec_cd     char(5),
   icd_ver_cd      char(2)
);

/* manually edit Optum's icd-9 lu_diagnosis table */
COPY scratch_qli2.optum_diagGroup FROM 's3://itx-agu-scratch-import/icd9.txt_2017-10-26_224346'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 
/*Warnings:
Load into table 'optum_diaggroup' completed, 18115 record(s) loaded successfully.

0 rows affected
COPY executed successfully

Execution time: 35.42s

manually remove three rows (2 NO DIAGNOSIS CODE, and 1 99) the next version shall be 18112 records (if a code cannot be assigned to two groups).
diag_cd code is not unique and can mapped to 2 valid diag_fst3_cd example: 311
*/

CREATE TABLE scratch_qli2.optum_diagGroup2
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_desc       varchar(100),
   diag_fst3_cd    varchar(3),
   diag_fst3_desc  varchar(40),
   diag_fst4_cd    varchar(4),
   diag_fst4_desc  varchar(40),
   gdr_spec_cd     char(5),
   icd_ver_cd      char(2)
);

COPY scratch_qli2.optum_diagGroup2 FROM 's3://itx-agu-scratch-import/ICD9COMP.txt_2017-10-27_080748'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 

/*
Warnings:
Load into table 'optum_diaggroup2' completed, 18112 record(s) loaded successfully.

0 rows affected
COPY executed successfully

Execution time: 12.17s
*/

drop table scratch_qli2.optum_diagGroup3;

CREATE TABLE scratch_qli2.optum_diagGroup3
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_desc       varchar(100),
   diag_fst3_cd    varchar(3),
   diag_fst3_desc  varchar(100),
   diag_fst4_cd    varchar(4),
   diag_fst4_desc  varchar(100),
   gdr_spec_cd     char(5),
   icd_ver_cd      char(2)
);

COPY scratch_qli2.optum_diagGroup3 FROM 's3://itx-agu-scratch-import/ICD9COMP3.txt_2017-10-31_114927'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

drop table scratch_qli2.optum_diagGroup4;

CREATE TABLE scratch_qli2.optum_diagGroup4
(
   unique_id int,
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

CREATE TABLE scratch_qli2.optum_diagGroup5
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

/*111854 */
insert into scratch_qli2.optum_diagGroup4 (unique_id, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd) 
select row_NUMBER() OVER (ORDER BY icd_ver_cd, diag_fst3_cd, diag_fst4_cd) as unique_id, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from lu_diagnosis
where diag_desc not in ('UNKNOWN DIAGNOSIS', 'NO DIAGNOSIS CODE')
order by icd_ver_cd, diag_fst3_cd, diag_fst4_cd;

insert into scratch_qli2.optum_diagGroup5  
select active, 'MH' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup4 
where (unique_id between 96988 and 97636)
or (unique_id between 4782 and 5721);

insert into scratch_qli2.optum_diagGroup5  
select active, 'Overweight, obesity and other hyperalimentation' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup4 
where diag_fst3_cd in ('E65','E66', 'E67','E68', '278');

insert into scratch_qli2.optum_diagGroup5  
select active, 'Overweight and obesity' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup4 
where diag_fst4_cd in ('2780')
or diag_fst3_cd in ('E66');

insert into scratch_qli2.optum_diagGroup5  
select active, 'Diseases of the circulatory system' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup4 
where (unique_id between 10660 and 12330)
or (unique_id between 99351 and 99958);

insert into scratch_qli2.optum_diagGroup5  
select active, 'COPD' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup4 
where diag_fst4_cd in ('4912')
or diag_fst3_cd in ('J44');

insert into scratch_qli2.optum_diagGroup5  
select active, 'Epilepsy and recurrent seizures' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup4 
where diag_fst3_cd in ('345')
or diag_fst3_cd in ('G40');

insert into scratch_qli2.optum_diagGroup5  
select active, 'Migraine' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup4 
where diag_fst3_cd in ('346')
or diag_fst3_cd in ('G43');

COPY scratch_qli2.optum_diagGroup5 FROM 's3://itx-agu-scratch-import/icd_with_grouping.csv_2017-11-15_005702'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY';

create table scratch_qli2.optum_diagGroup6 as
select * from scratch_qli2.optum_diagGroup4;

update scratch_qli2.optum_diagGroup6
set active = 1
where diag_cd in (select distinct diag_cd from scratch_qli2.optum_diagGroup5
where active = 1); /* 1961 */

update scratch_qli2.optum_diagGroup6 
set active = 0
where diag_cd in (select distinct diag_cd from scratch_qli2.optum_diagGroup5
where active = 0); /* 61 */

update scratch_qli2.optum_diagGroup6
set active = 1 where active is null; /*109832 rows affected */

CREATE TABLE scratch_qli2.optum_diagGroup7
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

insert into scratch_qli2.optum_diagGroup7  
select active, 'MH' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where (unique_id between 96988 and 97636)
or (unique_id between 4782 and 5721);

insert into scratch_qli2.optum_diagGroup7  
select active, 'Overweight, obesity and other hyperalimentation' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where diag_fst3_cd in ('E65','E66', 'E67','E68', '278');

insert into scratch_qli2.optum_diagGroup7  
select active, 'Overweight and obesity' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where diag_fst4_cd in ('2780')
or diag_fst3_cd in ('E66');

insert into scratch_qli2.optum_diagGroup7  
select active, 'Diseases of the circulatory system' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where (unique_id between 10660 and 12330)
or (unique_id between 99351 and 99958);

insert into scratch_qli2.optum_diagGroup7  
select active, 'COPD' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where diag_fst4_cd in ('4912')
or diag_fst3_cd in ('J44');

insert into scratch_qli2.optum_diagGroup7  
select active, 'Epilepsy and recurrent seizures' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where diag_fst3_cd in ('345')
or diag_fst3_cd in ('G40');

insert into scratch_qli2.optum_diagGroup7  
select active, 'Migraine' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where diag_fst3_cd in ('346')
or diag_fst3_cd in ('G43');

insert into scratch_qli2.optum_diagGroup7  
select active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2.optum_diagGroup6 
where diag_fst4_cd in ('5310','5312','5314','5316',
'5320','5322','5324','5326',
'5330','5332','5334','5336',
'5340','5342','5344','5346','4560','5307',
'4552','4555','4558','5997','6238','6266','7191','7847','7848','7863')
or diag_cd in ('53501','53511','53521','53531','53541','53551','53561','53783','45620','53082','56202','56203','56212','56213','56881','5693','56985','59381','56881')
or diag_fst3_cd in ('578','430','431','432','423','459');

COPY scratch_qli2.optum_diagGroup7 FROM 's3://itx-agu-scratch-import/icd_with_grouping.csv_2017-11-15_005702'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY'; /* this file needs to be updated with the one without COPD, seisures, and migraine */

update scratch_qli2.optum_diagGroup7
set active = 0
where diag_cd in (select a.diag_cd
from lu_diagnosis a right outer join scratch_qli2.Optum_diagGroup5 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1'));

/* not sure why these 4 codes was missed */
select *
from lu_diagnosis a right outer join scratch_qli2.Optum_diagGroup7 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1');


create table scratch_stellaqing.optum_diagGroup8 as
select * from scratch_qli2.optum_diagGroup7;

update scratch_stellaqing.optum_diagGroup8
set active = 0
where diag_cd in (select a.diag_cd
from lu_diagnosis a right outer join scratch_qli2.Optum_diagGroup7 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1'));

select *
from lu_diagnosis a right outer join scratch_stellaqing.Optum_diagGroup8 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1');

select count(*) from scratch_qli2.optum_diagGroup7; /* 6478 */ 

create table scratch_qli2.test7 as
select diagGroup, count (diag_cd) from scratch_qli2.optum_diagGroup7 group by diagGroup;

create table scratch_qli2.test5 as
select diagGroup, count (diag_cd) from scratch_qli2.optum_diagGroup5 group by diagGroup;

select a.*, b.diagGroup as diagGroup2, b.count as count2 from scratch_qli2.test5 a full outer join scratch_qli2.test7 b on a.diagGroup=b.diagGroup where a.count != b.count;

select * from scratch_qli2.optum_diagGroup7 where diagGroup in ('Overweight and obesity');
select * from scratch_qli2.optum_diagGroup5 where diagGroup in ('Overweight and obesity');

create table scratch_qli2.mh_note
(diag_cd         varchar(10),
 diag_desc       varchar(100)
 );
 
COPY scratch_qli2.mh_note FROM 's3://itx-agu-scratch-import/MH_note.txt_2017-11-06_110834'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

CREATE TABLE scratch_qli2.drug_class
(drug_class        varchar(150)
);

insert into scratch_qli2.drug_class  
select distinct drug_class from scratch_qli2.qing_medication_administrations
union
select distinct drug_class from scratch_qli2.qing_prescriptions_written
union
select distinct drug_class from scratch_qli2.qing_patient_reported_medications;

drop table scratch_qli2.drug_class;

drop table scratch_qli2.drug_class2;

CREATE TABLE scratch_qli2.drug_class2
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50)
);

insert into scratch_qli2.drug_class2 
select distinct ndc, drug_class, 'medication_administrations' as source from scratch_qli2.qing_medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source from scratch_qli2.qing_prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source from scratch_qli2.qing_patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source  from scratch_qli2.qing_lu_ndc;

drop table scratch_qli2.drug_class3; 

/* preferred */
CREATE TABLE scratch_qli2.drug_class3
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass varchar(150)
);

CREATE TABLE scratch_qli2.drug_class4
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass1 varchar(150),
superclass2 varchar(150)
);

insert into scratch_qli2.drug_class3 
select ndc, drug_class, source, '' as superclass from scratch_qli2.drug_class2;

insert into scratch_qli2.drug_class4 
select ndc, drug_class, source, '' as superclass1, '' as superclass2 from scratch_qli2.drug_class2;

/*from scratch */
insert into scratch_qli2.drug_class3 
select distinct ndc, drug_class, 'medication_administrations' as source, '' as superclass from scratch_qli2.qing_medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source, '' as superclass from scratch_qli2.qing_prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source, '' as superclass from scratch_qli2.qing_patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source, '' as superclass  from scratch_qli2.qing_lu_ndc;
 
update scratch_qli2.drug_class4
set superclass1 = 'antidepressants'
where drug_class ilike '%ANTIDEPRESSANTS%' or drug_class in ('Selective serotonin reuptake inhibitor (SSRI) antidepressants','Antidepressants; miscellaneous','Tricyclic antidepressants','SELECTIVE-SEROTONIN REUPTAKE INHIBITORS','Serotonin and norepinephrine reuptake inhibitors','SEROTONIN MODULATORS','SEL.SEROTONIN,NOREPI REUPTAKE INHIBITOR');

update scratch_qli2.drug_class4
set superclass1 = 'antipsychotics'
where drug_class ilike '%Antipsychotics%';

update scratch_qli2.drug_class4
set superclass1 = 'anxiolytics'
where drug_class ilike '%Anxiolytics%';

update scratch_qli2.drug_class4
set superclass2 = 'sedative hypnotics'
where drug_class ilike '%Sedative hypnotics%' or drug_class ilike '%Sedative-hypnotics%'
or drug_class ilike '%SEDATIVES,AND HYPNOTICS%' or drug_class like '%SEDATIVES & HYPNOTICS%' or drug_class ilike '%SEDATIVE/HYP%';

update scratch_qli2.drug_class3
set superclass = 'antidepressants'
where drug_class ilike '%ANTIDEPRESSANTS%' or drug_class in ('Selective serotonin reuptake inhibitor (SSRI) antidepressants','Antidepressants; miscellaneous','Tricyclic antidepressants','SELECTIVE-SEROTONIN REUPTAKE INHIBITORS','Serotonin and norepinephrine reuptake inhibitors','SEROTONIN MODULATORS','SEL.SEROTONIN,NOREPI REUPTAKE INHIBITOR','Monoamine oxidase (MAO) inhibitors');

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'antipsychotics' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Antipsychotics%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'anxiolytics' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Anxiolytics%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'sedative hypnotics' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Sedative hypnotics%' or drug_class ilike '%Sedative-hypnotics%'
or drug_class ilike '%SEDATIVES,AND HYPNOTICS%' or drug_class like '%SEDATIVES & HYPNOTICS%' or drug_class ilike '%SEDATIVE/HYP%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Antimanic agents' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Antimanic agents%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'statins' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%HMG & CoA reductase inhibitors (statins)%'
or drug_class ilike '%HMG & CoA reductase inhibitor combinations; statin & various%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Antidiabetic' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Antidiabetic combination agents%'
or drug_class ilike '%Antidiabetic agents%'
or drug_class ilike '%Insulin%'
or drug_class ilike '%Glucagon-like peptide 1 receptor agonists; and other misc. diabetes agents'
or drug_class ilike '%Thiazides & related agents';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'HIV antivirals' as superclass
from scratch_qli2.drug_class4
where drug_class ilike 'HIV antivirals%'   
or drug_class ilike 'HIV antiviral%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Opioid dependence drug therapy' as superclass
from scratch_qli2.drug_class4
where drug_class ilike 'Opioid dependence drug therapy%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Narcotic Analgesics' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Narcotic & analgesic combinations%'
or drug_class ilike '%Narcotic agonist analgesics%'; 

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Centrally-acting analgesics' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Centrally-acting analgesics%';  

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'analgesics' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%analgesic%'; 

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Anticonvulsants' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Anticonvulsants%'; 

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'chemotherapeutic' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%chemotherapeutic%'
or drug_class ilike '%Mitotic inhibitors%'
or drug_class ilike '%MTOR inhibitors%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Antihypertensive' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Antihypertensive%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Anticoagulants' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Factor Xa inhibitors%'
or drug_class ilike '%Anticoagulants%';

insert into scratch_qli2.drug_class3
select ndc, drug_class, source, 'Migraine agents' as superclass
from scratch_qli2.drug_class4
where drug_class ilike '%Migraine agents%';

select count(*) from scratch_qli2.drug_class3; /*539554*/

/* scratch_qli2.icdcategorygrouping has decimal point, scratch_qli2.icdcategorygrouping2 without decimal point and corrects trailing space data loading issyes, but 300.0 and 300.00 all became 300 also there is lower letter */
CREATE TABLE scratch_qli2.icdcategorygrouping3
(
   code               varchar(10)     NOT NULL,
   diagnosis_cd_type  varchar(10),
   notes              varchar(300),
   category           varchar(100)
);
insert into scratch_qli2.icdcategorygrouping3
select upper(code),diagnosis_cd_type,notes, category from scratch_qli2.icdcategorygrouping2;


/* new control random 2% */
create table scratch_qli2.control1 as
select ptid from scratch_qli2.random1 where ptid not in (select * from scratch_stellasw.indexid); 
;
select count (distinct ptid) from scratch_qli2.control; /* 621595 */
select count (distinct ptid) from scratch_stellawangsw.control;
select count (distinct ptid) from scratch_qli2.control1; /*313674*/
select count (distinct ptid) from scratch_stellawangsw.sui; /*241,253*/
select count (distinct ptid) from scratch_stellasw.sui; /*241,253*/
select count (distinct ptid) from scratch_stellasw.indexid; /*241,253*/

/*total_cohort=control+suicide*/ 
CREATE TABLE scratch_qli2.total_cohort 
AS
SELECT DISTINCT ptid
FROM scratch_qli2.control1
UNION
SELECT DISTINCT ptid
FROM scratch_stellasw.sui;

/* total_cohort=control+suicide with case/control status */ 
CREATE TABLE scratch_qli2.total_cohort2 
AS
SELECT DISTINCT ptid, 'Control' AS CAT 
FROM scratch_qli2.control1
UNION
SELECT DISTINCT ptid, 'Case' as CAT
FROM scratch_stellasw.sui;

CREATE TABLE scratch_qli2.total_cohort3 
AS
(SELECT DISTINCT a.ptid, diagnosis_cd AS diag,
     diag_date, 'Control' AS CAT 
FROM scratch_qli2.control1 a,  scratch_qli2.qing_diagnosis b
where a.ptid=b.ptid
and b.diagnosis_status IN ('Diagnosis of')
AND b.problem_list = 'N'
UNION
SELECT DISTINCT ptid, diag,
     diag_date, CAT
FROM scratch_stellasw.sui);

/* what kind of diagnosis for control really doesn't matter, just want a date when the patient shows up in the system using the diagnosis table alone */
CREATE TABLE scratch_qli2.control2 
AS
SELECT DISTINCT control1.ptid, diagnosis_cd AS diag, diag_date, 'Control' AS CAT /*, diagnosis_status,  problem_list */
FROM scratch_qli2.control1 left outer join scratch_qli2.qing_diagnosis 
on control1.ptid=qing_diagnosis.ptid;

/*
CREATE TABLE scratch_qli2.control3
as SELECT DISTINCT ptid, diag, diag_date,  cat
where diagnosis_status not in ('History of', 'Family history of', 'Not recorded', 'Possible diagnosis of', 'Other diagnosis status')
*/

CREATE TABLE scratch_qli2.total_cohort4 
AS
(SELECT DISTINCT ptid, diag, diag_date, CAT 
FROM scratch_qli2.control2 
UNION
SELECT DISTINCT ptid, diag, diag_date, CAT
FROM scratch_stellasw.sui);
select count(distinct ptid) from scratch_qli2.control2  where diag_date is null; /*45483 */

select count(distinct ptid) from scratch_qli2.total_cohort4; /*554927 there are patients that do not have any Dx code */
select count(distinct ptid) from scratch_qli2.total_cohort3; /*494034 */
select count(distinct ptid) from scratch_qli2.total_cohort2; /*554,927*/
select ptid from scratch_qli2.total_cohort2 where ptid not in (select ptid from scratch_qli2.total_cohort3); /* 60893 */

select ptid from scratch_qli2.total_cohort2 where ptid not in (select ptid from scratch_qli2.total_cohort3) 
and ptid not in (select distinct ptid from scratch_qli2.control2  where diag_date is null); /* 15410 */

select * from scratch_qli2.qing_diagnosis where ptid = 'PT116704835'; /* some had Not recorded diagnostic status and did not make it to total_cohort3 */

select count(*) from scratch_qli2.total_cohort; /*554,927*/
select count (distinct ptid) from scratch_qli2.total_cohort /*554,927*/


/*use total cohort patient ID to extract tables*/

/*create temp table*/
/*_pos_episode_visit*/
create table scratch_qli2.qing_pos_episode_visit as
select*from
_pos_episode_visit where ptid in (select * from scratch_qli2.total_cohort);

create table scratch_qli2.qing_version as
select*from
_version;

/*care_area*/
create table scratch_qli2.qing_care_area as
select*from
care_area where ptid in (select * from scratch_qli2.total_cohort);

/*cost_factor--no ptid column in this table*/
create table scratch_qli2.qing_cost_factor as
select*from cost_factor;

/*diagnosis*/
create table scratch_qli2.qing_diagnosis as
select* from diagnosis where ptid in (select * from scratch_qli2.total_cohort);

/*encounter*/
create table scratch_qli2.qing_encounter as
select* from encounter where ptid in (select * from scratch_qli2.total_cohort);

/*encounter_provider---use encid to match*/
create table scratch_qli2.qing_encounter_provider as
select* from encounter_provider; 

/*immunizations*/
create table scratch_qli2.qing_immunizations as
select* from immunizations where ptid in (select * from scratch_qli2.total_cohort);

/*inpatient_confinement*/
create table scratch_qli2.qing_inpatient_confinement as
select* from inpatient_confinement where ptid in (select * from scratch_qli2.total_cohort);

/*insurance*/
--drop table scratch_stellasw.qing_insurance
create table scratch_qli2.qing_insurance as
select* from insurance where ptid in (select * from scratch_qli2.total_cohort);

/*lab_results*/
create table scratch_qli2.qing_lab_results as
select* from lab_results where ptid in (select * from scratch_qli2.total_cohort);

/*labs*/
create table scratch_qli2.qing_labs as
select* from labs where ptid in (select * from scratch_qli2.total_cohort);

/*lu_abnl_cd*/
create table scratch_qli2.qing_lu_abnl_cd as
select* from lu_abnl_cd; 

/*lu_ahfsclss*/
create table scratch_qli2.qing_lu_ahfsclss as
select* from lu_ahfsclss; 

/*lu_bus_line*/
create table scratch_qli2.qing_lu_bus_line as
select* from lu_bus_line; 

/*lu_cdhp*/
create table scratch_qli2.qing_lu_cdhp as
select* from lu_cdhp; 

/*lu_cob*/
create table scratch_qli2.qing_lu_cob as
select* from lu_cob;

/*lu_daw*/
create table scratch_qli2.qing_lu_daw as
select* from lu_daw;

/*lu_diagnosis*/
create table scratch_qli2.qing_lu_diagnosis as
select* from lu_diagnosis;

/*lu_dischstatus*/
create table scratch_qli2.qing_lu_dischstatus as
select* from lu_dischstatus;

/*lu_drg*/
create table scratch_qli2.qing_lu_drg as
select* from lu_drg;

/*lu_encounter*/
create table scratch_qli2.qing_lu_encounter as
select* from lu_encounter;

/*lu_form_ind*/
create table scratch_qli2.qing_lu_form_ind as
select* from lu_form_ind;

/*lu_form_typ*/
create table scratch_qli2.qing_lu_form_typ as
select* from lu_form_typ;


/*lu_fst_fill*/
create table scratch_qli2.qing_lu_fst_fill as
select* from lu_fst_fill;

/*lu_gnrc_ind*/
create table scratch_qli2.qing_lu_gnrc_ind as
select* from lu_gnrc_ind;

/*lu_hccc*/
create table scratch_qli2.qing_lu_hccc as
select* from lu_hccc;

/*lu_icd_flag*/
create table scratch_qli2.qing_lu_icd_flag as
select* from lu_icd_flag;

/*lu_ipstatus*/
create table scratch_qli2.qing_lu_ipstatus as
select* from lu_ipstatus;

/*lu_loc_cd*/
create table scratch_qli2.qing_lu_loc_cd as
select* from lu_loc_cd;

/*lu_ndc*/
create table scratch_qli2.qing_lu_ndc as
select* from lu_ndc;

/*lu_poa*/
create table scratch_qli2.qing_lu_poa as
select* from lu_poa;

/*lu_pos*/
create table scratch_qli2.qing_lu_pos as
select* from lu_pos;


/*lu_prc_typ*/
create table scratch_qli2.qing_lu_prc_typ as
select* from lu_prc_typ;


/*lu_procedure*/
create table scratch_qli2.qing_lu_procedure as
select* from lu_procedure;

/*lu_procmod*/
create table scratch_qli2.qing_lu_procmod as
select* from lu_procmod; 

/*lu_product*/
create table scratch_qli2.qing_lu_product as
select* from lu_product;

/*lu_provcat*/
create table scratch_qli2.qing_lu_provcat as
select* from lu_provcat;

/*lu_rvnu_cd*/
create table scratch_qli2.qing_lu_rvnu_cd as
select* from lu_rvnu_cd;

/*lu_specclss*/
create table scratch_qli2.qing_lu_specclss as
select* from lu_specclss;

/*lu_tos_cd*/
create table scratch_qli2.qing_lu_tos_cd as
select* from lu_tos_cd;


/*medical_claims*/
create table scratch_qli2.qing_medical_claims as
select* from medical_claims where ptid in (select * from scratch_qli2.total_cohort);

/*medication_administrations*/
create table scratch_qli2.qing_medication_administrations as
select* from medication_administrations where ptid in (select * from scratch_qli2.total_cohort);


/*member_detail*/
create table scratch_qli2.qing_member_detail as
select* from member_detail where ptid in (select * from scratch_qli2.total_cohort);

/*microbiology*/
create table scratch_qli2.qing_microbiology as
select* from microbiology where ptid in (select * from scratch_qli2.total_cohort);

/*nlp_biomarkers*/
create table scratch_qli2.qing_nlp_biomarkers as
select* from nlp_biomarkers where ptid in (select * from scratch_qli2.total_cohort);

/*nlp_custom*/
create table scratch_qli2.qing_nlp_custom as
select* from nlp_custom where ptid in (select * from scratch_qli2.total_cohort);

/*nlp_drug_rationale*/
create table scratch_qli2.qing_nlp_drug_rationale as
select* from nlp_drug_rationale where ptid in (select * from scratch_qli2.total_cohort);

/*nlp_measurement*/
create table scratch_qli2.qing_nlp_measurement as
select* from nlp_measurement where ptid in (select * from scratch_qli2.total_cohort);


/*nlp_sds*/
create table scratch_qli2.qing_nlp_sds as
select* from nlp_sds where ptid in (select * from scratch_qli2.total_cohort);


/*nlp_sds_family*/
create table scratch_qli2.qing_nlp_sds_family as
select* from nlp_sds_family where ptid in (select * from scratch_qli2.total_cohort);

/*observations*/
create table scratch_qli2.qing_observations as
select* from observations where ptid in (select * from scratch_qli2.total_cohort);


/*patient*/
create table scratch_qli2.qing_patient as
select* from patient where ptid in (select * from scratch_qli2.total_cohort);


/*patient_reported_medications*/
create table scratch_qli2.qing_patient_reported_medications as
select* from patient_reported_medications where ptid in (select * from scratch_qli2.total_cohort);

/*prescriptions_written*/
create table scratch_qli2.qing_prescriptions_written as
select* from prescriptions_written where ptid in (select * from scratch_qli2.total_cohort);

/*procedure*/
create table scratch_qli2.qing_procedure as
select* from procedure where ptid in (select * from scratch_qli2.total_cohort);

/*provider*/
create table scratch_qli2.qing_provider as
select* from provider; 


/*rx_claims*/
create table scratch_qli2.qing_rx_claims as
select* from rx_claims where ptid in (select * from scratch_qli2.total_cohort);

/*visit*/
create table scratch_qli2.qing_visit as
select* from visit where ptid in (select * from scratch_qli2.total_cohort);

select min(diag_date) from diagnosis where diagnosis_cd_type = 'ICD9';/*2007-1-1*/
select max(diag_date) from diagnosis where diagnosis_cd_type = 'ICD9'; /*2017-3-31*/
select max(diag_date) from diagnosis where diagnosis_cd_type = 'ICD10'; /*2017-3-31*/
select min(diag_date) from diagnosis where diagnosis_cd_type = 'ICD10';/*2007-1-1*/

select top 50 * from procedure where proc_code in ('J2426');

select * from scratch_qli2b.drug_class3 where ndc like '50458-056%-01';

select distinct drug_name, generic_desc, route, a.drug_class, superclass
from prescriptions_written a, scratch_qli2b.drug_class3 b 
where generic_desc ilike '%acetaminophen%' or drug_name ilike '%acetaminophen%';

select distinct * from (
select distinct drug_name, generic_desc, route, a.drug_class, superclass
from prescriptions_written a, scratch_qli2b.drug_class3 b
where a.ndc=b.ndc
and route in ('Intravenous', 'Subcutaneous', 'Intramuscular','Other injection')
and superclass not in ('')
union
select distinct drug_name, generic_desc, route, a.drug_class, superclass
from medication_administrations a, scratch_qli2b.drug_class3 b
where a.ndc=b.ndc
and route in ('Intravenous', 'Subcutaneous', 'Intramuscular','Other injection')
and superclass not in (''));

/*https://github.com/OHDSI/CommonDataModel/wiki */


/*http://services.rhealth.jnj.com */

select * from scratch_qli2b.lu_procedure where proc_typ_cd in ('HCPCS') and proc_cd like 'J%' and category_dtl_cd = 240;
