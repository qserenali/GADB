drop table scratch_qli2b.drug_class;

CREATE TABLE scratch_qli2b.drug_class
(drug_class        varchar(150)
);

/*509 */
insert into scratch_qli2b.drug_class  
select distinct drug_class from medication_administrations
union
select distinct drug_class from prescriptions_written
union
select distinct drug_class from patient_reported_medications;

drop table scratch_qli2b.drug_class2;

CREATE TABLE scratch_qli2b.drug_class2b
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50)
);
/* 661388 rows affected; 734744 2-21-18 */
insert into scratch_qli2b.drug_class2b 
select distinct ndc, drug_class, 'medication_administrations' as source from medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source from prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source from patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source from scratch_qli2b.lu_ndc;

drop table scratch_qli2b.drug_class3; 

/* preferred */
CREATE TABLE scratch_qli2b.drug_class3b
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass varchar(150)
);
/* 661388 rows affected; 734744 2-21-18 */
insert into scratch_qli2b.drug_class3b 
select ndc, drug_class, source, '' as superclass from scratch_qli2b.drug_class2b;

/*from scratch */
insert into scratch_qli2b.drug_class3 
select distinct ndc, drug_class, 'medication_administrations' as source, '' as superclass from medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source, '' as superclass from prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source, '' as superclass from patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source, '' as superclass  from scratch_qli2b.lu_ndc;

/* 12054 rows affected; 15389 rows affected */ 
update scratch_qli2b.drug_class3b
set superclass = 'antidepressants'
where drug_class ilike '%ANTIDEPRESSANTS%' or drug_class in ('Selective serotonin reuptake inhibitor (SSRI) antidepressants',
'Antidepressants; miscellaneous','Tricyclic antidepressants','SELECTIVE-SEROTONIN REUPTAKE INHIBITORS','Serotonin and norepinephrine reuptake inhibitors',
'SEROTONIN MODULATORS','SEL.SEROTONIN,NOREPI REUPTAKE INHIBITOR','Monoamine oxidase (MAO) inhibitors');

/* 5618 rows affected; 6778 rows affected*/
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'antipsychotics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antipsychotics%';

/* 7162; 8522 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'anxiolytics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Anxiolytics%';

/* 7314; 8024 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'sedative hypnotics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Sedative hypnotics%' or drug_class ilike '%Sedative-hypnotics%'
or drug_class ilike '%SEDATIVES,AND HYPNOTICS%' or drug_class like '%SEDATIVES & HYPNOTICS%' or drug_class ilike '%SEDATIVE/HYP%';

/* 457; 524 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Antimanic agents' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antimanic agents%';

/* 2157; 3398 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'statins' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%HMG & CoA reductase inhibitors (statins)%'
or drug_class ilike '%HMG & CoA reductase inhibitor combinations; statin & various%';

/* 4424; 6443 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Antidiabetic' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antidiabetic combination agents%'
or drug_class ilike '%Antidiabetic agents%'
or drug_class ilike '%Insulin%'
or drug_class ilike '%Glucagon-like peptide 1 receptor agonists; and other misc. diabetes agents'
or drug_class ilike '%Thiazides & related agents';

/* 450; 601 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'HIV antivirals' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike 'HIV antivirals%'   
or drug_class ilike 'HIV antiviral%';

/* 147; 192 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Opioid dependence drug therapy' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike 'Opioid dependence drug therapy%';

/* n = 6701; 9917 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Narcotic Analgesics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Narcotic & analgesic combinations%'
or drug_class ilike '%Narcotic agonist analgesics%'; 

/* 40; 50 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Centrally-acting analgesics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Centrally-acting analgesics%';  

delete from scratch_qli2b.drug_class3 where superclass in ('analgesics');
/* 17690 rows affected */

/* 17690 rows affected with '%analgesic%' alone; 17690 rows affected - surprisingly why there is no increase in rows; 22190 rows affected 2-21-18*/
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'analgesics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%analgesic%' or drug_class in ('MIGRAINE COMBINATIONS','ACETAMINOPHEN (APAP)'); 

/* 2-21-18 12010 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Anticonvulsants' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Anticonvulsants%'; 

/* 2-21-18 1952 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'chemotherapeutic' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%chemotherapeutic%'
or drug_class ilike '%Mitotic inhibitors%'
or drug_class ilike '%MTOR inhibitors%';

/* 3629 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Antihypertensive' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antihypertensive%';

/* 1425 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Anticoagulants' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Factor Xa inhibitors%'
or drug_class ilike '%Anticoagulants%';

/* 272 rows affected; 330 rows affected 2-21-18 */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Factor Xa inhibitors' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Factor Xa inhibitors%';

/* 1008 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Migraine agents' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Migraine agents%';

select count(*) from scratch_qli2b.drug_class3; /*539554, now 729479*/
select count(*) from scratch_qli2b.drug_class3b; /* 821737 2-21-18 */

/* 41 classes */
select * 
from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv
where sui=1 
and tc_level_code = 2;

/* perl code ./connect2Redshift.pl >createGPIclasses.sql
*/

insert into scratch_qli2b.drug_class3
select ndc, '' as drug class, 'GPI' as source, '*ANTIPSYCHOTICS/ANTIMANIC AGENTS*' as superclass
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt
where gpi like '59%';

/* 21 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, '' as drug_class, 'GPI' as source, '*Direct Factor Xa Inhibitors**' as superclass 
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt 
where gpi like '8337%';

/*3994 rows affected*/
insert into scratch_qli2b.drug_class3b
select ndc, '' as drug_class, 'GPI' as source, '*Nonsteroidal Anti-inflammatory Agents (NSAIDs)**' as superclass 
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt 
where gpi like '6610%';

insert into scratch_qli2b.drug_class3b
select ndc, '' as drug_class, 'GPI' as source, 'Drugs predisposing to bleed' as superclass 
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt 
where gpi like '6610%';

/* 848 rows affected */
insert into scratch_qli2b.drug_class3b
select distinct ndc, drug_class, source, superclass 
from scratch_qli2b.drugpredisposed;

/* select distinct source from scratch_qli2b.drug_class3; */

select * from scratch_qli2b.drug_class3 where superclass in ('*ANTIPSYCHOTICS/ANTIMANIC AGENTS*');

/* delete from scratch_qli2b.drug_class3
where drug_class = 'GPI'; */

select distinct superclass from scratch_qli2b.drug_class3 where source in ('GPI');
select distinct superclass from scratch_qli2b.drug_class3b where source in ('GPI'); /* n=44 */

delete from scratch_qli2b.drug_class3b where source in ('prescriptions_written', 'patient_reported_medications'); /* 341138 rows affected 2-21-2018 */

CREATE TABLE scratch_qli2b.drugpredisposed
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass varchar(150)
);
/*
http://10.37.94.22:8080/scratch_upload 
*/
COPY scratch_qli2b.sau1250_worksheet_in_gpi_general_csv FROM 's3://itx-agu-scratch-import/Worksheet_in_GPI_general_training_first_sheet_three_additional_rows.txt_2018-04-03_163946'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';


/* 9-24-18 compared Optum definition to Feb definition diaggroup8 */
drop table scratch_qli2b.endpoint;

create table scratch_qli2b.endpoint as
select _group, replace(a.code, '.', '') as code1 from 
scratch_qli2b.sau1901_janssen_suicide_risk_mod_csv a;

select _group, count(*) from scratch_qli2b.sau1901_janssen_suicide_risk_mod_csv
group by _group; /* 860 by group 399 41 393 27 */

select count(*) from scratch_qli2b.optum_diaggroup8 where diaggroup in ('Suicidal attempt'); /* 2404 */

select * from scratch_qli2b.optum_diaggroup8 where diaggroup in ('Suicidal attempt') and (diag_cd like 'T%S' or diag_cd like 'T%D');

select _group, count(*) from 
scratch_qli2b.endpoint a full join 
scratch_qli2b.optum_diaggroup8 b 
on code1=b.diag_cd
where b.diaggroup in ('Suicidal attempt') and diag_cd not like 'T%S' and diag_cd not like 'T%D' /*1110 before group is not null */
and _group is not null
group by _group; /*851 group by 399 41 393 18 */

drop table scratch_qli2b.endpoint2;

create table scratch_qli2b.endpoint2 as
select a.*, b.* from
scratch_qli2b.endpoint a full join 
scratch_qli2b.optum_diaggroup8 b 
on code1=b.diag_cd
where b.diaggroup in ('Suicidal attempt') and diag_cd not like 'T%S' and diag_cd not like 'T%D' and diag_cd not like 'S%S' and diag_cd not like 'S%D'
and diag_cd not like 'X%S' and diag_cd not like 'X%D' and diag_cd not like 'Y%S' and diag_cd not like 'Y%D'
order by _group, diag_cd; /* 942 */

select count(*) from scratch_qli2b.endpoint2;

select a.*, b.diag_desc from scratch_qli2b.endpoint2 a left join scratch_qli2b.lu_diagnosis b on a.diag_cd=b.diag_cd order by _group, diag_cd; /* 942 */

/*update compared to Optum's version */

/* add X820XXA, X821XXA, X822XXA */

drop table scratch_qli2b.endpoint3;

create table scratch_qli2b.endpoint3 as
select 'Group 1' as _group, diag_cd as code1, '1' as active, 'Suicidal attempt' as diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2b.lu_diagnosis 
where diag_cd like 'X820%A' or diag_cd like 'X821%A' or diag_cd like 'X822%A'; /* or diag_cd like 'X828%A' X828%A' was in already */

desc scratch_qli2b.endpoint2;

select * from scratch_qli2b.endpoint3; /* 3 rows */

select _group, diag_cd from scratch_qli2b.endpoint2 a where diag_cd like '96%'; /*48*/

update scratch_qli2b.endpoint2 set _group='Group 2'  where diag_cd like '96%'; /* 48 rows affected parental code */

select _group, diag_cd from scratch_qli2b.endpoint2 a where diag_cd like 'E95%'; /*55*/

update scratch_qli2b.endpoint2 set _group='Group 1'  where diag_cd like 'E95%'; /* 55 rows affected, parental code */

select _group, diag_cd from scratch_qli2b.endpoint2 a where diag_cd like 'T1491%'; /*2*/

update scratch_qli2b.endpoint2 set _group='Group 1'  where diag_cd like 'T1491%'; /* 2 rows affected */

/* delete from scratch_qli2b.endpoint2 where diag_cd in ('T1491'); */  /*keep this in as T1491 was not broadly adopted during the database period */ /*1 row affected remove this in case the clinician did not differentiate subsequent encounter from initial encounter*/

select * from scratch_qli2b.endpoint2 a where diag_cd like 'E959%';

select * from scratch_qli2b.lu_diagnosis where diag_cd in ('E959'); /* late effects */

delete from scratch_qli2b.endpoint2 where diag_cd in ('E959'); /* late effects */
delete from scratch_qli2b.endpoint2 where diag_cd in ('E95'); /* since E959 was excluded */
select count(*) from  scratch_qli2b.endpoint2; /* n = 940 */

select * from scratch_qli2b.optum_diaggroup8 where diag_cd like '965%'; /*965 9650 9656 Optum is missing these codes*/

select a.*, b.diag_desc from scratch_qli2b.endpoint2 a left join scratch_qli2b.lu_diagnosis b on a.diag_cd=b.diag_cd order by _group, diag_cd; /* 942; 940 as of 10-2-18 */

select a.*, b.diag_desc from scratch_qli2b.endpoint2 a left join scratch_qli2b.lu_diagnosis b on a.diag_cd=b.diag_cd where a.diag_cd like 'T67%';

select * from diagnosis where diagnosis_cd in ('965', '9650', '9656'); /* Optum missing 1736 rows from diagnosis table*/
select * from diagnosis where diagnosis_cd in ('967'); /* 36598 */
select count(*) from diagnosis where diagnosis_cd in ('E95','E950', 'E951','E952', 'E953', 'E955','E957','E958');/*207*/
select count(*) from diagnosis where diagnosis_cd in ('E950', 'E951','E952', 'E953', 'E955','E957','E958');/*7753*/

select count(*) from diagnosis where diagnosis_cd in ('969','9690'); /*7753*/ 
select min(diag_date), max(diag_date) from diagnosis where diagnosis_cd in ('T1491XA'); /* Optum missing 36,598 from diagnosis table*/
select * from diagnosis where diagnosis_cd in ('T1491XA') and diag_date in ('2007-01-01');

select count(*) from diagnosis where diagnosis_cd in ('T1491'); /* 110,360 */

select * from diagnosis where diagnosis_cd in ('X71'); /*0 rows */

select * from scratch_qli2b.optum_diaggroup8 where diag_cd like '881%'; /* 881 8810 8811 8812 */

select count(*) from scratch_qli2b.optum_diaggroup8; /* 9006 */

create table scratch_qli2b.optum_diaggroup9 as
select * from scratch_qli2b.optum_diaggroup8
where diaggroup not in ('Suicidal attempt'); /* 6602 = 9006 - 2404 */

drop table scratch_qli2b.optum_diaggroup10;

create table scratch_qli2b.optum_diaggroup10 as
select active, diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd from scratch_qli2b.endpoint2 where _group in ('Group 1', 'Group 2'); /* 457; 455 as of 10-2-18 delete late effect and E95*/
select count(*) from scratch_qli2b.optum_diaggroup10;

drop table scratch_qli2b.optum_diaggroup11;

/* Union will remove duplicates probably because icd10_pain2 has some overlap with */
create table scratch_qli2b.optum_diaggroup11 as
(select * from scratch_qli2b.optum_diaggroup9 /*6602 */
union
select * from scratch_qli2b.optum_diaggroup10 /*455*/
union
select * from scratch_qli2b.icd10_pain2 /* add ICD10 pain code n=222*/
union
select active, diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd from scratch_qli2b.endpoint3); /* add 3 motor vehicle codes */

select count(*) from scratch_qli2b.optum_diaggroup11; /* 7055 as of 10-2-18; add icd10 pain codes n=222, total 7277; add 3 motor vehicle code n=7280 Oct 9 2018 */

select count(*) from scratch_qli2b.optum_diaggroup12; /* 7283 add the MDD codes noticed missing by Holmusk*/

select count(*) from scratch_qli2b.optum_diaggroup9; /*6602*/
select count(distinct diag_cd) from scratch_qli2b.optum_diaggroup10; /*455*/
select count(distinct diag_cd) from scratch_qli2b.icd10_pain2; /*222 */
select * from scratch_qli2b.icd10_pain2;
select * from scratch_qli2b.optum_diaggroup9 where diaggroup in ('pain');
select distinct diaggroup, diag_cd from scratch_qli2b.optum_diaggroup9; /*6600 */
select count (distinct ptid) from diagnosis where diagnosis_cd in (select diag_cd from scratch_qli2b.optum_diaggroup11 where diaggroup in  ('Suicidal attempt'));

select distinct superclass from scratch_qli2b.drug_class3b where source = 'GPI'; /* n = 44 */

select * from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv where sui=true and tc_level_code=2; /*n =41 */

select max(diag_date) from diagnosis; /*2018-03-31*/

select * from scratch_qli2b.lu_diagnosis where diag_cd in ('G8929');
select * from scratch_qli2b.lu_diagnosis where diag_cd like 'T67%';

select distinct diaggroup from scratch_qli2b.optum_diaggroup11;

select icd_ver_cd, diaggroup, count(diag_cd) from scratch_qli2b.optum_diaggroup11 group by icd_ver_cd, diaggroup order by diaggroup, icd_ver_cd;

select * from scratch_qli2b.optum_diaggroup8 where diaggroup like 'pain';

select * from scratch_qli2b.optum_diaggroup11 where diag_cd like 'T6319%';

create table scratch_qli2b.icd10_pain as 
select distinct replace(code, '.', '') as code1 from scratch_qli2b.sau2221_atlas_search_csv a;

create table scratch_qli2b.icd9_pain as 
select distinct replace(code, '.', '') as code1  from scratch_qli2b.sau2223_atlas_search__1__csv;

create table scratch_qli2b.icd10_pain2 as 
select '1' as active, 'pain' as diaggroup, a.code1 as diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2b.icd10_pain a left join scratch_qli2b.lu_diagnosis b 
on a.code1 = b.diag_cd 
where diag_desc not in ('') ; /* 222 */

select a.*, b.* from scratch_qli2b.optum_diaggroup11 a full join scratch_qli2b.icd9_pain b on code1=diag_cd where diaggroup in ('pain'); 

select * from scratch_qli2b.optum_diaggroup11 where diag_cd like 'T1491%';
select * from scratch_qli2b.optum_diaggroup11 where diag_cd like 'E95%';

select min(index_date), max(index_date) from scratch_michigansa.sa_grp_ps_20181001_new;
