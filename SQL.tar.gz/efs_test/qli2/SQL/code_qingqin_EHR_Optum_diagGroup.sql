drop table scratch_qli2c.optum_diagGroup4;

CREATE TABLE scratch_qli2b.optum_diagGroup4
(
   unique_id int,
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

CREATE TABLE scratch_qli2c.optum_diagGroup5
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

/*111854 original, 111856 now; 2-22-18 111856 rows affected*/
insert into scratch_qli2b.optum_diagGroup4 (unique_id, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd) 
select row_NUMBER() OVER (ORDER BY icd_ver_cd, diag_fst3_cd, diag_fst4_cd) as unique_id, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2b.lu_diagnosis
where diag_desc not in ('UNKNOWN DIAGNOSIS', 'NO DIAGNOSIS CODE')
order by icd_ver_cd, diag_fst3_cd, diag_fst4_cd;

insert into scratch_qli2c.optum_diagGroup5  
select active, 'MH' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where (unique_id between 96988 and 97636)
or (unique_id between 4782 and 5721);

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Overweight, obesity and other hyperalimentation' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst3_cd in ('E65','E66', 'E67','E68', '278');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Overweight and obesity' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('2780')
or diag_fst3_cd in ('E66');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Diseases of the circulatory system' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where (unique_id between 10660 and 12330)
or (unique_id between 99351 and 99958);

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Epilepsy and recurrent seizures' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst3_cd in ('345')
or diag_fst3_cd in ('G40');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Migraine' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst3_cd in ('346')
or diag_fst3_cd in ('G43');

COPY scratch_qli2c.optum_diagGroup5 FROM 's3://itx-agu-scratch-import/icd_with_grouping.csv_2017-11-15_005702'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY';

delete from scratch_qli2c.optum_diagGroup5
where diagGroup in ('COPD', 'seizures', 'migraine');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'COPD' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('4912')
or diag_fst3_cd in ('J44');

insert into scratch_qli2c.optum_diagGroup5  
select '1' as active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('5310','5312','5314','5316',
'5320','5322','5324','5326',
'5330','5332','5334','5336',
'5340','5342','5344','5346',
'4560','5307',
'4552','4555','4558','5997','6238','6266','7191','7847','7848','7863',
'4230','4590')
or diag_cd in ('53501','53511','53521','53531','53541','53551','53561',
'53783','45620','53082',
'56202','56203','56212','56213','56881','5693','56985','59381','56881')
or diag_fst3_cd in ('578','430','431','432');

insert into scratch_qli2c.optum_diagGroup5  
select '1' as active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('K250','K252','K254','K256',
'K260','K262','K264','K266',
'K270','K272','K274','K276',
'K280','K282','K284','K2806',
'N921','M250','I312')
or diag_cd in ('K2901','K2921','K2931','K2941','K2951','K2961','K2971','K2981','K2991',
'K31811','I8501','I8511','53021','K2211','K226',
'K5701','K5711','K5713','K5721','K5731','K5733','K5741','K5751','K5753','K5781','K5791','K5793',
'K661','K625','K5521','N280','K661','K920','K921','K922','R58')
or diag_fst3_cd in ('R31','I60','I61','I62','R04');

select diagGroup, count(diag_cd)  
from scratch_qli2c.optum_diagGroup5 
where diagGroup is not null 
group by diagGroup
order by diagGroup;

select count(*) from scratch_qli2c.optum_diagGroup5; 

drop table scratch_qli2c.optum_diagGroup6;

create table scratch_qli2c.optum_diagGroup6 as
select * from scratch_qli2c.optum_diagGroup4;

select count(*) from scratch_qli2c.optum_diagGroup5;

/*2212 optum_diagGroup6 update active tag using optum_diagGroup5*/
update scratch_qli2c.optum_diagGroup6
set active = 1
where diag_cd in (select distinct diag_cd from scratch_qli2c.optum_diagGroup5
where active = 1); /* 1961, now 2206 */

update scratch_qli2c.optum_diagGroup6 
set active = 0
where diag_cd in (select distinct diag_cd from scratch_qli2c.optum_diagGroup5
where active = 0); /* 61 */

update scratch_qli2c.optum_diagGroup6
set active = 1 where active is null; /*109832 rows affected 109583*/

CREATE TABLE scratch_qli2c.optum_diagGroup7
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

insert into scratch_qli2c.optum_diagGroup7  
select active, 'MH' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where (unique_id between 96988 and 97636)
or (unique_id between 4782 and 5721);

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Overweight, obesity and other hyperalimentation' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst3_cd in ('E65','E66', 'E67','E68', '278');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Overweight and obesity' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst4_cd in ('2780')
or diag_fst3_cd in ('E66');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Diseases of the circulatory system' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where (unique_id between 10660 and 12330)
or (unique_id between 99351 and 99958);

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Epilepsy and recurrent seizures' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst3_cd in ('345')
or diag_fst3_cd in ('G40');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Migraine' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst3_cd in ('346')
or diag_fst3_cd in ('G43');

insert into scratch_qli2c.optum_diagGroup7  
select '1' as active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst4_cd in ('5310','5312','5314','5316',
'5320','5322','5324','5326',
'5330','5332','5334','5336',
'5340','5342','5344','5346',
'4560','5307',
'4552','4555','4558','5997','6238','6266','7191','7847','7848','7863',
'4230','4590')
or diag_cd in ('53501','53511','53521','53531','53541','53551','53561',
'53783','45620','53082',
'56202','56203','56212','56213','56881','5693','56985','59381','56881')
or diag_fst3_cd in ('578','430','431','432');

insert into scratch_qli2c.optum_diagGroup7  
select '1' as active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst4_cd in ('K250','K252','K254','K256',
'K260','K262','K264','K266',
'K270','K272','K274','K276',
'K280','K282','K284','K2806',
'N921','M250','I312')
or diag_cd in ('K2901','K2921','K2931','K2941','K2951','K2961','K2971','K2981','K2991',
'K31811','I8501','I8511','53021','K2211','K226',
'K5701','K5711','K5713','K5721','K5731','K5733','K5741','K5751','K5753','K5781','K5791','K5793',
'K661','K625','K5521','N280','K661','K920','K921','K922','R58')
or diag_fst3_cd in ('R31','I60','I61','I62','R04');

COPY scratch_qli2c.optum_diagGroup7 FROM 's3://itx-agu-scratch-import/icd_with_grouping.csv_2017-11-15_005702'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY'; /* this file needs to be updated with the one without COPD, seizures, and migraine */

delete from scratch_qli2c.optum_diagGroup7 where diagGroup in ('COPD', 'seizures', 'migraine'); /* 166 */

select count(*) from scratch_qli2c.optum_diagGroup5; 

insert into scratch_qli2c.optum_diagGroup7  
select active, 'COPD' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst4_cd in ('4912')
or diag_fst3_cd in ('J44');

select count(*) from scratch_qli2c.optum_diagGroup7;

update scratch_qli2c.optum_diagGroup7
set active = 0
where diag_cd in (select a.diag_cd
from lu_diagnosis a right outer join scratch_qli2c.Optum_diagGroup5 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1'));

/* not sure why these 4 codes was missed */
select *
from lu_diagnosis a right outer join scratch_qli2c.Optum_diagGroup7 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1');


create table scratch_qli2c.optum_diagGroup8 as
select * from scratch_qli2c.optum_diagGroup7;

update scratch_qli2c.optum_diagGroup8
set active = 0
where diag_cd in (select a.diag_cd
from lu_diagnosis a right outer join scratch_qli2c.Optum_diagGroup7 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1'));

select *
from lu_diagnosis a right outer join scratch_qli2c.Optum_diagGroup8 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1');

select count(*) from scratch_qli2c.optum_diagGroup8; /* 6599 */ 

drop table scratch_qli2c.attempt_codes;

CREATE TABLE scratch_qli2c.attempt_codes
(code         varchar(10),
code_type      varchar(6));

COPY scratch_qli2c.attempt_codes FROM 's3://itx-agu-scratch-import/suicidal_total.txt_2018-01-16_223154'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; /* endpoint */

select code_type, count(code) from scratch_qli2c.attempt_codes group by code_type;

CREATE TABLE scratch_qli2c.optum_diagGroup
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

insert into scratch_qli2c.optum_diagGroup
(select * from (select '1' as active, 'Suicidal attempt' as Diaggroup, a.code as diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.attempt_codes a left join lu_diagnosis b 
on a.code = b.diag_cd
where a.code_type in ('ICD10')
order by diag_cd) 
where diag_cd in ('Y11', 'Y12', 'Y20') and icd_ver_cd = 9);

update scratch_qli2c.optum_diagGroup
set icd_ver_cd = 10;

insert into scratch_qli2c.optum_diagGroup
(select '1' as active, 'Suicidal attempt' as Diaggroup, a.code as diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.attempt_codes a left join lu_diagnosis b 
on a.code = b.diag_cd
where a.code_type in ('ICD9')
and icd_ver_cd = 9
and diag_desc not in ('UNKNOWN DIAGNOSIS')
order by diag_cd);

insert into scratch_qli2c.optum_diagGroup
(select * from (select '1' as active, 'Suicidal attempt' as Diaggroup, a.code as diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.attempt_codes a left join lu_diagnosis b 
on a.code = b.diag_cd
where a.code_type in ('ICD10')
order by diag_cd) where icd_ver_cd = 10 or icd_ver_cd is null);

select count(*) from scratch_qli2c.optum_diagGroup;

insert into scratch_qli2c.optum_diagGroup8
select * from scratch_qli2c.optum_diagGroup;

select count(*) from scratch_qli2c.optum_diagGroup8;

select * from lu_diagnosis where diag_cd in ('Y28');

select * from stl_load_errors;

select * from scratch_qli2c.optum_diagGroup8;

CREATE TABLE scratch_qli2b.optum_diagGroup8
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

COPY scratch_qli2b.optum_diagGroup8 FROM 's3://itx-agu-scratch-import/optum_diagGroup8.txt_2018-01-17_004256'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; /* 6822 */

select ndc, ahfsclss_desc from lu_ndc /*n = 448,566 */
where ahfsclss_desc not in ('UNKNOWN'); /*414620 */

drop table scratch_qli2b.lu_ndc;

CREATE TABLE scratch_qli2b.lu_ndc
( ndc                       varchar(11),
  ahfsclss_desc             varchar(100)
);

COPY scratch_qli2b.lu_ndc FROM 's3://itx-agu-scratch-import/lu_ndc_subset3.txt_2018-01-17_000853'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 

/* 2-7-18 upload to http://services.rhealth.jnj.com */
delete from scratch_qli2b.optum_diagGroup8
where Diaggroup in ('Suicidal attempt')
and  icd_ver_cd = 10;

/*DELETE FROM scratch_qli2b.optum_diagGroup8 successful
33 rows affected*/
select * from scratch_qli2b.optum_diagGroup8 where Diaggroup in ('Suicidal attempt')
and  icd_ver_cd is null;

delete from scratch_qli2b.optum_diagGroup8
where Diaggroup in ('Suicidal attempt')
and  icd_ver_cd is null;
/*DELETE FROM scratch_qli2b.optum_diagGroup8 successful
20 rows affected*/

select '1' as active, 'Suicidal attempt' as Diaggroup, cast(diag_cd as char(10)), '10' as icd_ver_cd
from scratch_qli2b.sau1214_UpdateSA_ICD10_codes_csv;

insert into scratch_qli2b.optum_diagGroup8
select '1' as active, 'Suicidal attempt' as Diaggroup, cast(a.diag_cd as char(10)), b.diag_fst3_cd, b.diag_fst4_cd,  '10' as icd_ver_cd
from scratch_qli2b.sau1214_UpdateSA_ICD10_codes_csv a left join scratch_qli2b.lu_diagnosis b on a.diag_cd=b.diag_cd;
/*INSERT INTO scratch_qli2b.optum_diagGroup8 successful
2221 rows affected*/

select * from scratch_qli2b.optum_diagGroup8 where Diaggroup in ('Suicidal attempt'); /*2391 */

INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X71','X71','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X72','X72','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X73','X73','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X74','X74','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X75','X75','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X76','X76','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X77','X77','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X78','X78','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X79','X79','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X80','X80','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X81','X81','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X82','X82','','10');
INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X83','X83','','10');

select * from scratch_qli2b.optum_diagGroup8 where Diaggroup in ('Suicidal attempt'); /*2404 8-24-18 11:04pm */

INSERT INTO scratch_qli2b.optum_diagGroup8 VALUES ('1', 'Suicidal attempt', 'X71','X71','','10');

select * from scratch_qli2b.optum_diagGroup8 a left join scratch_qli2b.lu_diagnosis b on a.diag_cd=b.diag_cd where Diaggroup in ('MB');

select * from medication_administrations where ndc in ('00002-8730-59');

select * from scratch_qli2b.lu_ndc where ndc in ('00002873059');

select * from scratch_qli2b.lu_ndc where ndc in ('00002873059');

create table scratch_qli2b.XWalk as
select TRANSLATE(ndc, '-', '') as ndc2, hcpcs from scratch_qli2b.sau1219_2018_02_05XWalkFinalVers_csv;

select * from scratch_qli2b.XWalk where hcpcs like 'K%';

select ndc, hcpcs from scratch_qli2b.sau1219_2018_02_05XWalkFinalVers_csv;

create table scratch_qli2b.HCPC2018_CONTR_ANWEB as
select a.hcpc, b.ndc2 from scratch_qli2b.sau1140_HCPC2018_CONTR_ANWEB_csv a left join scratch_qli2b.XWalk b on a.hcpc = b.hcpcs where a.hcpc like 'J%';

select a.*, b.ahfsclss_desc from scratch_qli2b.HCPC2018_CONTR_ANWEB a left join scratch_qli2b.lu_ndc b
on a.ndc2 = b.ndc
where ahfsclss_desc is null; /* 865 */

select a.*, b.ahfsclss_desc from scratch_qli2b.HCPC2018_CONTR_ANWEB a left join scratch_qli2b.lu_ndc b
on a.ndc2 = b.ndc
where ndc2 is null; /* 259 */

select * from stl_load_errors; 

CREATE TABLE scratch_qli2b.MB_diagGroup
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

COPY scratch_qli2b.MB_diagGroup FROM 's3://itx-agu-scratch-import/New_diagGroup_for_MB_030418.txt_2018-03-04_233409'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

drop table scratch_qli2b.MB_procGroup;

CREATE TABLE scratch_qli2b.MB_procGroup
(
   procGroup	varchar(100),
   include varchar(3),
   category_dtl_cd          char(5),
   category_dtl_code_desc   varchar(50),
   category_genl_cd         char(5),
   category_genl_code_desc  varchar(50),
   proc_cd                  varchar(10),
   proc_desc                varchar(100),
   proc_typ_cd              char(5)
);

COPY scratch_qli2b.MB_procGroup FROM 's3://itx-agu-scratch-import/ProcGroup.txt_2018-03-14_110136'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

CREATE TABLE lu_procedure
(
   category_dtl_cd          char(5),
   category_dtl_code_desc   varchar(50),
   category_genl_cd         char(5),
   category_genl_code_desc  varchar(50),
   proc_cd                  varchar(10),
   proc_desc                varchar(100),
   proc_end_date            date,
   proc_typ_cd              char(5)
);


select count(*) from scratch_qli2b.MB_diagGroup where diagGroup in ('Anemia'); /*250*/

delete from scratch_qli2b.MB_diagGroup where diagGroup is null; /*4 rows affected*/

select * from scratch_qli2b.MB_diagGroup where  diag_fst3_cd in ('70');/*30 rows affected Excel removes the leading 0 */

delete from scratch_qli2b.MB_diagGroup where diag_fst3_cd in ('70');

insert into scratch_qli2b.MB_diagGroup
select '1' as active, 'Abnormal liver function' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd from scratch_qli2b.lu_diagnosis where  diag_fst3_cd in ('070');
/* 30 rows affected */

/* create the table to be inserted into the protocol */
select * from scratch_qli2b.MB_diagGroup a left join scratch_qli2b.lu_diagnosis b 
on a.diag_cd=b.diag_cd order by a.diaggroup, a.diag_fst3_cd, a.diag_fst4_cd, a.diag_cd;

select distinct source from scratch_qli2b.drug_class3b;
delete from scratch_qli2b.drug_class3b where source in ('medication_administrations'); /* 37522 rows affected */
select distinct superclass from scratch_qli2b.drug_class3b where source in ('GPI'); /* n = 42 */

insert into scratch_qli2b.optum_diagGroup
select active, Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd from scratch_qli2b.optum_diagGroup8 where diagGroup in ('Bipolar'); 

insert into scratch_qli2b.MB_diagGroup
select active, Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd from scratch_qli2b.optum_diagGroup8 where diagGroup in ('MB'); /* 254 rows */
/* 254 rows affected */


insert into scratch_qli2b.MB_diagGroup
select active, 'Bleeding history or predisposition' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd from scratch_qli2b.optum_diagGroup8 where diagGroup in ('MB');
/* 254 rows affected */

insert into scratch_qli2b.MB_diagGroup
select active, 'Bleeding history or predisposition (Anemia)' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd from scratch_qli2b.MB_diagGroup where diagGroup in ('MB','Anemia');
/* 504 rows affected */

select distinct diagGroup from scratch_qli2b.MB_diagGroup; /* AF and MB same as scratch_qli2b.optum_diagGroup8, the rest as predictors, xxx-1 is usually a more restrictive defintion than xxx */
