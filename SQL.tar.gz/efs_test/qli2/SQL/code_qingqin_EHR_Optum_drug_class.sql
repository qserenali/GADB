drop table scratch_qli2b.drug_class;

CREATE TABLE scratch_qli2b.drug_class
(drug_class        varchar(150)
);

/*509 */
insert into scratch_qli2b.drug_class  
select distinct drug_class from medication_administrations
union
select distinct drug_class from prescriptions_written
union
select distinct drug_class from patient_reported_medications;

drop table scratch_qli2b.drug_class2;

CREATE TABLE scratch_qli2b.drug_class2b
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50)
);
/* 661388 rows affected; 734744 2-21-18 */
insert into scratch_qli2b.drug_class2b 
select distinct ndc, drug_class, 'medication_administrations' as source from medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source from prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source from patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source from scratch_qli2b.lu_ndc;

drop table scratch_qli2b.drug_class3; 

/* preferred */
CREATE TABLE scratch_qli2b.drug_class3b
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass varchar(150)
);
/* 661388 rows affected; 734744 2-21-18 */
insert into scratch_qli2b.drug_class3b 
select ndc, drug_class, source, '' as superclass from scratch_qli2b.drug_class2b;

/*from scratch */
insert into scratch_qli2b.drug_class3 
select distinct ndc, drug_class, 'medication_administrations' as source, '' as superclass from medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source, '' as superclass from prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source, '' as superclass from patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source, '' as superclass  from scratch_qli2b.lu_ndc;

/* 12054 rows affected; 15389 rows affected */ 
update scratch_qli2b.drug_class3b
set superclass = 'antidepressants'
where drug_class ilike '%ANTIDEPRESSANTS%' or drug_class in ('Selective serotonin reuptake inhibitor (SSRI) antidepressants',
'Antidepressants; miscellaneous','Tricyclic antidepressants','SELECTIVE-SEROTONIN REUPTAKE INHIBITORS','Serotonin and norepinephrine reuptake inhibitors',
'SEROTONIN MODULATORS','SEL.SEROTONIN,NOREPI REUPTAKE INHIBITOR','Monoamine oxidase (MAO) inhibitors');

/* 5618 rows affected; 6778 rows affected*/
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'antipsychotics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antipsychotics%';

/* 7162; 8522 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'anxiolytics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Anxiolytics%';

/* 7314; 8024 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'sedative hypnotics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Sedative hypnotics%' or drug_class ilike '%Sedative-hypnotics%'
or drug_class ilike '%SEDATIVES,AND HYPNOTICS%' or drug_class like '%SEDATIVES & HYPNOTICS%' or drug_class ilike '%SEDATIVE/HYP%';

/* 457; 524 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Antimanic agents' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antimanic agents%';

/* 2157; 3398 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'statins' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%HMG & CoA reductase inhibitors (statins)%'
or drug_class ilike '%HMG & CoA reductase inhibitor combinations; statin & various%';

/* 4424; 6443 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Antidiabetic' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antidiabetic combination agents%'
or drug_class ilike '%Antidiabetic agents%'
or drug_class ilike '%Insulin%'
or drug_class ilike '%Glucagon-like peptide 1 receptor agonists; and other misc. diabetes agents'
or drug_class ilike '%Thiazides & related agents';

/* 450; 601 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'HIV antivirals' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike 'HIV antivirals%'   
or drug_class ilike 'HIV antiviral%';

/* 147; 192 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Opioid dependence drug therapy' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike 'Opioid dependence drug therapy%';

/* n = 6701; 9917 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Narcotic Analgesics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Narcotic & analgesic combinations%'
or drug_class ilike '%Narcotic agonist analgesics%'; 

/* 40; 50 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Centrally-acting analgesics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Centrally-acting analgesics%';  

delete from scratch_qli2b.drug_class3 where superclass in ('analgesics');
/* 17690 rows affected */

/* 17690 rows affected with '%analgesic%' alone; 17690 rows affected - surprisingly why there is no increase in rows; 22190 rows affected 2-21-18*/
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'analgesics' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%analgesic%' or drug_class in ('MIGRAINE COMBINATIONS','ACETAMINOPHEN (APAP)'); 

/* 2-21-18 12010 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Anticonvulsants' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Anticonvulsants%'; 

/* 2-21-18 1952 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'chemotherapeutic' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%chemotherapeutic%'
or drug_class ilike '%Mitotic inhibitors%'
or drug_class ilike '%MTOR inhibitors%';

/* 3629 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Antihypertensive' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Antihypertensive%';

/* 1425 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Anticoagulants' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Factor Xa inhibitors%'
or drug_class ilike '%Anticoagulants%';

/* 272 rows affected; 330 rows affected 2-21-18 */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Factor Xa inhibitors' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Factor Xa inhibitors%';

/* 1008 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, drug_class, source, 'Migraine agents' as superclass
from scratch_qli2b.drug_class2b
where drug_class ilike '%Migraine agents%';

select count(*) from scratch_qli2b.drug_class3; /*539554, now 729479*/
select count(*) from scratch_qli2b.drug_class3b; /* 821737 2-21-18 */

/* 41 classes */
select * 
from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv
where sui=1 
and tc_level_code = 2;

/* perl code ./connect2Redshift.pl >createGPIclasses.sql
*/

insert into scratch_qli2b.drug_class3
select ndc, '' as drug class, 'GPI' as source, '*ANTIPSYCHOTICS/ANTIMANIC AGENTS*' as superclass
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt
where gpi like '59%';

/* 21 rows affected */
insert into scratch_qli2b.drug_class3b
select ndc, '' as drug_class, 'GPI' as source, '*Direct Factor Xa Inhibitors**' as superclass 
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt 
where gpi like '8337%';

/*3994 rows affected*/
insert into scratch_qli2b.drug_class3b
select ndc, '' as drug_class, 'GPI' as source, '*Nonsteroidal Anti-inflammatory Agents (NSAIDs)**' as superclass 
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt 
where gpi like '6610%';

insert into scratch_qli2b.drug_class3b
select ndc, '' as drug_class, 'GPI' as source, 'Drugs predisposing to bleed' as superclass 
from scratch_qli2b.sau1246_ndc2gpi_rx_claims_txt 
where gpi like '6610%';

/* 848 rows affected */
insert into scratch_qli2b.drug_class3b
select distinct ndc, drug_class, source, superclass 
from scratch_qli2b.drugpredisposed;

/* select distinct source from scratch_qli2b.drug_class3; */

select * from scratch_qli2b.drug_class3 where superclass in ('*ANTIPSYCHOTICS/ANTIMANIC AGENTS*');

/* delete from scratch_qli2b.drug_class3
where drug_class = 'GPI'; */

select distinct superclass from scratch_qli2b.drug_class3 where source in ('GPI');
select distinct superclass from scratch_qli2b.drug_class3b where source in ('GPI'); /* n=44 */

delete from scratch_qli2b.drug_class3b where source in ('prescriptions_written', 'patient_reported_medications'); /* 341138 rows affected 2-21-2018 */

CREATE TABLE scratch_qli2b.drugpredisposed
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass varchar(150)
);
/*
http://10.37.94.22:8080/scratch_upload 
*/
COPY scratch_qli2b.sau1250_worksheet_in_gpi_general_csv FROM 's3://itx-agu-scratch-import/Worksheet_in_GPI_general_training_first_sheet_three_additional_rows.txt_2018-04-03_163946'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

/* 8-24-18 */
select distinct source from scratch_qli2b.drug_class3b;
select distinct source from scratch_qli2b.drug_class3;

select distinct superclass from scratch_qli2b.drug_class3b where source in ('lu_ndc');
select distinct superclass from scratch_qli2b.drug_class3b where source in ('GPI');
select distinct superclass from scratch_qli2b.drug_class3 where source not in ('GPI') and superclass not in (''); /* this table still has the other three data sources */

select distinct superclass from scratch_qli2b.drug_class3 where source in ('lu_ndc') and superclass not in ('');

select * from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv where sui in ('true') AND TC_LEVEL_CODE=2; /* n = 41 */
