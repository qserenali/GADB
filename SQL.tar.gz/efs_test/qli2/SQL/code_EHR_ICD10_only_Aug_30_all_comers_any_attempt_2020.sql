SELECT DISTINCT diaggroup FROM scratch_qli2b.optum_diaggroup12

drop table if exists scratch_qli2b.patient;
SELECT ptid, birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active,
             to_date(cast(substring(first_month_active,5,2) AS int) || '/' || cast(substring(first_month_active,1,4) AS int), 'MM/YYYY') as first_month_active2,
             to_date(cast(substring(last_month_active,5,2) AS int) || '/' || cast(substring(last_month_active,1,4) AS int), 'MM/YYYY') as last_month_active2
INTO scratch_qli2b.patient
FROM patient;
      
/* all patients, first / last attemp */

select max(diag_date) from diagnosis; /* 2019-12-31 */

/* ever attempter ICD-9 or -10 before 2018-10-01*/
drop table if exists scratch_qli2b.SA_Case_ever_attempters;

SELECT ptid INTO scratch_qli2b.SA_Case_ever_attempters
FROM (SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diagnosis_status IN ('Diagnosis of')
      AND  diag_date < '2018-10-01' 
      AND  problem_list IN ('N')
      AND  diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))); 

select count(*) from scratch_qli2b.SA_Case_ever_attempters; /* 468896 all periods; 429057 before 2018-10-01 5-30 same # as 5-3 same version of database 
            427546 6-26-20 12-31-19 version of database */

/* codes below adapted from Grace Wang's code from 10-30-18 */

drop table if exists scratch_qli2b.SA_Case_ICD10; --must be owner of relation sa_case_icd10;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_sa_date INTO scratch_qli2b.SA_Case_ICD10_any_attempt
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2017-10-01' 
      AND diag_date < '2018-10-01' 
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
      )
GROUP BY ptid;

select count(distinct ptid) from scratch_qli2b.SA_Case_ICD10_any_attempt; --46771
 
drop table if exists scratch_qli2b.SA_1_ICD10_any_attempt;
SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active2,
       last_month_active2 INTO scratch_qli2b.SA_1_ICD10_any_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.patient
      WHERE LENGTH(birth_yr) = 4
      AND gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Case_ICD10_any_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_1_ICD10_any_attempt; --42959

DROP TABLE if exists scratch_qli2b.SA_control_ICD10_any_attempt;

SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.SA_control_ICD10_any_attempt
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diag_date >= '2017-10-01' --case control cohort
      AND diag_date < '2018-10-01'
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
)
AND   diag_date >= '2017-10-01' --case control cohort
AND   diag_date < '2018-10-01'
AND   diagnosis_cd_type IN ('ICD10') --- added
AND   diagnosis_status IN ('Diagnosis of', 'History of') --- added
AND   problem_list IN ('N') --added
GROUP BY ptid;

select count(distinct(ptid)) from scratch_qli2b.SA_control_ICD10_any_attempt; --27,828,567

DROP TABLE if exists scratch_qli2b.SA_0_ICD10_any_attempt;

SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active2,
       last_month_active2 INTO scratch_qli2b.SA_0_ICD10_any_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Control_ICD10_any_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_0_ICD10_any_attempt; /* 26,194,426 */
 
DROP TABLE if exists scratch_qli2b.SA_GRP_any_attempt_20200830; /* change dur calculation */

SELECT DISTINCT *,  datediff(month, first_month_active2, last_month_active2) as DUR,
       datediff(month, first_month_active2, index_date) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_any_attempt_20200830
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.SA_1_ICD10_any_attempt
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.SA_0_ICD10_any_attempt)
WHERE datediff(month, first_month_active2, index_date) >= 24;

select count(*) from scratch_qli2b.SA_GRP_any_attempt_20200830; /* 19854617 */

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_any_attempt_20200830
GROUP BY grp_num;

--all comers 
--grp_num=1	32006
--grp_num=0	19822611

select * into scratch_qli2b.SA_GRP_any_attempt_200830
from scratch_qli2b.SA_GRP_any_attempt_20200830
where age >= 13;

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_any_attempt_200830
GROUP BY grp_num;
--grp_num=1	    31,425
--grp_num=0	17,763,650

/* step 2 Run SAS matching code */

/* http://10.37.94.22:8080/scratch_upload */
/* http://services.rhealth.jnj.com/scratch_upload_auto needs to be in csv format*/
--drop table if exists scratch_qli2b.Optum_1_1_match_any_attempt;
/*
CREATE TABLE scratch_qli2b.Optum_1_1_match_any_attempt 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);
    
COPY scratch_qli2b.Optum_1_1_match_last_attempt FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_06282020.txt_2020-06-28_170213'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
*/

--select * from stl_load_errors;   

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.sau57910_Optum_data_for_modeling
GROUP BY grp_num; -- true	31425 false 31425

desc ext_scratch_qli2b.sau57910_Optum_data_for_modeling;

create table scratch_qli2b.SA_GRP_any_attempt_200830b as
(select * from ext_scratch_qli2b.SA_GRP_any_attempt_200830 where ptid in (select ptid from ext_scratch_qli2b.sau57910_Optum_data_for_modeling));

select * from ext_scratch_qli2b.SA_GRP_any_attempt_200830b;

select count(distinct(ptid)) from ext_scratch_qli2b.SA_GRP_any_attempt_200830; --17795075 
select count(distinct(ptid)) from ext_scratch_qli2b.SA_GRP_any_attempt_200830b; --62850

/* step 3 run Grace's SAS Enterprise Guide codes */

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.SA_GRP_any_attempt_200830b
GROUP BY grp_num;  ---31425*2  

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.SA_GRP_any_attempt_200830
GROUP BY grp_num; 
--0	17,763,650 (all in the cohort)
--1	31,425

select count(*) from ext_scratch_qli2b.SA_GRP_any_attempt_200830 where ptid not in (select ptid from patient);/* ptid from version 1234 not in 8/27/21 version of database */
--5,344,119 1:1 match and 20180701 um were also query against the current version of native database 8/27/21 need to run medication_1234 and also new label (time varying labels)

select count(*) from ext_scratch_qli2b.SA_GRP_any_attempt_200830 where ptid not in (select ptid from native_1234.patient); --0

select grp, count(distinct ptid) from scratch_qli2b.sau57914_SA_all_csv GROUP BY grp; --0	31425

drop table if exists scratch_qli2b.broad_test_all_comers_any_attempt;
select ptid, grp_num into scratch_qli2b.broad_test_all_comers_any_attempt
from scratch_qli2b.SA_GRP_any_attempt_200830
where ptid not in (select ptid from scratch_qli2b.sau57914_SA_all_csv);

select count(ptid) from ext_scratch_qli2b.sau57914_SA_all_csv; --62850

select grp_num,
       COUNT(DISTINCT ptid) 
       from ext_scratch_qli2b.broad_test_all_comers_any_attempt
       GROUP BY grp_num;
--0	17732225 all unmatched controls

drop table if exists scratch_qli2d.broad_test_holdout_nm_all_comers_any_attempt;

select ptid, grp_num into scratch_qli2d.broad_test_holdout_nm_all_comers_any_attempt
from ext_scratch_qli2b.broad_test_all_comers_any_attempt
where ptid in (select ptid from scratch_qli2d.sau71066_holdoutData_nm_subjectI); --this failed

CREATE TABLE scratch_qli2d.broad_test_holdout_nm_all_comers_any_attempt AS SELECT ptid, grp_num FROM ext_scratch_qli2b.broad_test_all_comers_any_attempt
WHERE ptid in (select ptid from scratch_qli2d.sau71066_holdoutData_nm_subjectI); -- this works

select count(*) from scratch_qli2d.broad_test_holdout_nm_all_comers_any_attempt;

select ptid, grp_num into scratch_qli2d.broad_test_holdout_nm_all_comers_any_attempt
from scratch_qli2b_restored_466.broad_test_all_comers_any_attempt
where ptid in (select ptid from scratch_qli2d.sau71066_holdoutData_nm_subjectI);


/* end here 8-31-2020 */

DROP TABLE if exists scratch_qli2b.medication_administrations;
create table scratch_qli2b.medication_administrations as 
(select * from native.medication_administrations where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and order_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.patient_reported_medications;
create table scratch_qli2b.patient_reported_medications as 
(select * from native.patient_reported_medications where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and reported_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.prescriptions_written;
create table scratch_qli2b.prescriptions_written as 
(select * from native.prescriptions_written where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and rxdate >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.diagnosis;
create table scratch_qli2b.diagnosis as 
(select * from native.diagnosis where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and diag_date >= '2015-10-1'
and diagnosis_cd_type IN ('ICD10'));

select a.*,b.diag_desc,b.diag_fst4_desc 
from native.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') ---PT251399534 ---PT226603638
and a.diagnosis_cd = b.diag_cd
order by diag_date;

select * from scratch_qli2b.lu_diagnosis b;

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in (select a.diagnosis_cd 
from scratch_qli2b.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') 
and a.diagnosis_cd = b.diag_cd);

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in ('R45851');

select distinct (source_id) from native.patient;

desc scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv;

select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1'); #410
select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 2'); # 47
select count(*) from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt'); #458
select * from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt') and diag_cd not in 
(select REPLACE(code, '.', '') from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1','Group 2'));
 
select * from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where code = '969.7';

select count(*) from native_1234.patient;
