SELECT DISTINCT  diaggroup FROM scratch_qli2b.optum_diaggroup12

/* AFD patients, first / last attemp */

select max(diag_date) from diagnosis; /* 2019-09-30; Since 6-20 cannot access native during the day, after regaining access 2019-12-31 */

/* codes below adapted from Grace Wang's code from 10-30-18 */

drop table if exists scratch_qli2b.AFD_index_date;

select ptid, min(diag_date) AS index_afd_date INTO scratch_qli2b.AFD_index_date
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date < '2018-09-01' 
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('MDD','BIP')))
GROUP BY ptid;

select count(*) from scratch_qli2b.AFD_index_date; /* 4,803,223 MDD; 754,622 BIP; 5,236,240 AFD */

drop table if exists scratch_qli2b.AFD_SA_Case_ICD10;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_sa_date INTO scratch_qli2b.AFD_SA_Case_ICD10
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' 
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
      AND   ptid in (select ptid from scratch_qli2b.AFD_index_date) --also requires cases having AFD 
      )
GROUP BY ptid;

drop table if exists scratch_qli2b.AFD_SA_Case_ICD10_first_attempt;
SELECT DISTINCT ptid,
       Min(diag_date) AS index_sa_date INTO scratch_qli2b.AFD_SA_Case_ICD10_first_attempt
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' 
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
      AND   ptid in (select ptid from scratch_qli2b.AFD_index_date) --also requires cases having AFD 
      )
GROUP BY ptid;

select count(distinct ptid) from scratch_qli2b.AFD_SA_Case_ICD10; --14,161 MDD; 5,357 BIP; 15500 AFD
select count(distinct ptid) from scratch_qli2b.AFD_SA_Case_ICD10_first_attempt; --15500 AFD

drop table if exists scratch_qli2b.AFD_SA_1_ICD10; /* last attempt */
SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.AFD_SA_1_ICD10
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	
      ) a 
  RIGHT JOIN scratch_qli2b.AFD_SA_Case_ICD10 b ON a.ptid = b.ptid;

/* ever attempter ICD-9 or -10 before 2018-10-01*/
drop table if exists scratch_qli2b.SA_Case_ever_attempters;
SELECT ptid INTO scratch_qli2b.SA_Case_ever_attempters
FROM (SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diagnosis_status IN ('Diagnosis of')
      AND  diag_date < '2018-10-01' 
      AND  problem_list IN ('N')
      AND  diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))); 

select count(*) from scratch_qli2b.SA_Case_ever_attempters; /* 468896 all periods; 429057 before 2018-10-01 5-30 same # as 5-3 same version of database */

drop table if exists scratch_qli2b.AFD_SA_1_ICD10_first_attempt;  

SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.AFD_SA_1_ICD10_first_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      AND ptid not in (select ptid from scratch_qli2b.SA_Case_ever_attempters) 
      ) a 
  RIGHT JOIN scratch_qli2b.AFD_SA_Case_ICD10_first_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.AFD_SA_1_ICD10; -- 12,961 MDD; 4,801 BIP; 14,171 AFD (case control model) 

select count(distinct ptid) from scratch_qli2b.AFD_SA_1_ICD10_first_attempt; --8,120 MDD; 2,499 BIP; 9,016 AFD

DROP TABLE if exists scratch_qli2b.AFD_SA_control_ICD10;

SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.AFD_SA_control_ICD10
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' --case control cohort
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
)
AND   diag_date >= '2018-10-01' --case control cohort
AND   diagnosis_cd_type IN ('ICD10') --- added
AND   diagnosis_status IN ('Diagnosis of', 'History of') --- added
AND   problem_list IN ('N') --added
AND   ptid in (select ptid from scratch_qli2b.AFD_index_date) --also requires controls having AFD 
GROUP BY ptid;

DROP TABLE if exists scratch_qli2b.AFD_SA_control_ICD10_first_attempt;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.AFD_SA_control_ICD10_first_attempt
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' --case control cohort
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
)
AND   diag_date >= '2018-10-01' --case control cohort
AND   diagnosis_cd_type IN ('ICD10') --- added
AND   diagnosis_status IN ('Diagnosis of', 'History of') --- added
AND   problem_list IN ('N') --added
AND   ptid in (select ptid from scratch_qli2b.AFD_index_date) --also requires controls having AFD 
AND   ptid not in (select ptid from scratch_qli2b.SA_Case_ever_attempters) 
GROUP BY ptid;

select count(distinct(ptid)) from scratch_qli2b.AFD_SA_control_ICD10_first_attempt;

DROP TABLE if exists scratch_qli2b.AFD_SA_0_ICD10;
SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.AFD_SA_0_ICD10
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      ) a 
  RIGHT JOIN scratch_qli2b.AFD_SA_Control_ICD10 b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.AFD_SA_0_ICD10; 

DROP TABLE if exists scratch_qli2b.AFD_SA_0_ICD10_first_attempt;
SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.AFD_SA_0_ICD10_first_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      ) a 
  RIGHT JOIN scratch_qli2b.AFD_SA_Control_ICD10_first_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.AFD_SA_0_ICD10;
-- 2,141,062 MDD; 283,856 BIP; 2,281,597 AFD case control cohort 5-29-20 (controls could have attempts before identification period; 
    
select count(distinct ptid) from scratch_qli2b.AFD_SA_0_ICD10_first_attempt; --2199143 6-10-20, controls cannot have attempts prior to identification period

DROP TABLE if exists scratch_qli2b.AFD_SA_GRP_last_attempt_20200530;

SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.AFD_SA_GRP_last_attempt_20200530
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.AFD_SA_1_ICD10
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.AFD_SA_0_ICD10)
WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) >= 2;

DROP TABLE if exists scratch_qli2b.AFD_SA_GRP_first_attempt_200530;

SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.AFD_SA_GRP_first_attempt_200530
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.AFD_SA_1_ICD10_first_attempt
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.AFD_SA_0_ICD10_first_attempt)
WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) >= 2;

select min(first_month_active) from scratch_qli2b.AFD_SA_GRP_last_attempt_20200530; --200601
select max(first_month_active) from scratch_qli2b.AFD_SA_GRP_last_attempt_20200530; --201712

select min(first_month_active) from scratch_qli2b.AFD_SA_GRP_first_attempt_200530; --200601
select max(first_month_active) from scratch_qli2b.AFD_SA_GRP_first_attempt_200530; --201712

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.AFD_SA_GRP_last_attempt_20200530
GROUP BY grp_num;

--MDD
--grp_num=1 12,491
--grp_num=0 2,103,256

--BIP
--grp_num=1 4,671
--grp_num=0 278,207

--AFD
--grp_num=1 13625
--grp_num=0 2239572

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.AFD_SA_GRP_first_attempt_200530
GROUP BY grp_num;

--MDD
--grp_num=1 7,781
--grp_num=0 2,103,256

--BIP
--grp_num=1 2,417
--grp_num=0 278,207

--AFD
--grp_num=1 8624
--grp_num=0 2239572 updated to be 2158095 on 6/10/20

--AFD
--grp_num=1 8618
--grp_num=0 2158095

/* step 2 Run SAS matching code */

/* http://10.37.94.22:8080/scratch_upload */
drop table if exists scratch_qli2b.Optum_1_1_match_AFD_first_attempt;

CREATE TABLE scratch_qli2b.Optum_1_1_match_AFD_first_attempt 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);

drop table if exists scratch_qli2b.Optum_1_1_match_AFD_last_attempt;
CREATE TABLE scratch_qli2b.Optum_1_1_match_AFD_last_attempt 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);

COPY scratch_qli2b.Optum_1_1_match_AFD_first_attempt FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_AFD_first_attempt_05302020.txt_2020-06-17_233335'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
    
COPY scratch_qli2b.Optum_1_1_match_AFD_last_attempt FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_AFD_last_attempt_05302020.txt_2020-05-30_113525'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
        
select * from stl_load_errors;   

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.Optum_1_1_match_AFD_first_attempt
GROUP BY grp_num; -- 8557

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.Optum_1_1_match_AFD_last_attempt
GROUP BY grp_num; --13545

drop table if exists scratch_qli2b.AFD_SA_GRP_last_attempt_200530b;
create table scratch_qli2b.AFD_SA_GRP_last_attempt_200530b as
(select * from scratch_qli2b.AFD_SA_GRP_last_attempt_20200530 where ptid in (select ptid from scratch_qli2b.Optum_1_1_match_AFD_last_attempt));

drop table if exists scratch_qli2b.AFD_SA_GRP_first_attempt_200530b;

create table scratch_qli2b.AFD_SA_GRP_first_attempt_200530b as
(select * from scratch_qli2b.AFD_SA_GRP_first_attempt_200530 where ptid in (select ptid from scratch_qli2b.Optum_1_1_match_AFD_first_attempt));

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.AFD_SA_GRP_last_attempt_200530b
GROUP BY grp_num;  ---13545*2 13 years and above filtering in SAS

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.AFD_SA_GRP_first_attempt_200530b
GROUP BY grp_num; --8557

/* step 3 run Grace's SAS Enterprise code */

/* end here 6-17-2020 */

DROP TABLE if exists scratch_qli2b.medication_administrations;
create table scratch_qli2b.medication_administrations as 
(select * from native.medication_administrations where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and order_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.patient_reported_medications;
create table scratch_qli2b.patient_reported_medications as 
(select * from native.patient_reported_medications where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and reported_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.prescriptions_written;
create table scratch_qli2b.prescriptions_written as 
(select * from native.prescriptions_written where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and rxdate >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.diagnosis;
create table scratch_qli2b.diagnosis as 
(select * from native.diagnosis where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and diag_date >= '2015-10-1'
and diagnosis_cd_type IN ('ICD10'));

select a.*,b.diag_desc,b.diag_fst4_desc 
from native.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') ---PT251399534 ---PT226603638
and a.diagnosis_cd = b.diag_cd
order by diag_date;

select * from scratch_qli2b.lu_diagnosis b;

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in (select a.diagnosis_cd 
from scratch_qli2b.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') 
and a.diagnosis_cd = b.diag_cd);

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in ('R45851');

select distinct (source_id) from native.patient;

desc scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv;

select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1'); #410
select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 2'); # 47
select count(*) from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt'); #458
select * from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt') and diag_cd not in 
(select REPLACE(code, '.', '') from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1','Group 2'));
 
select * from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where code = '969.7';
