SELECT DISTINCT diaggroup FROM scratch_qli2b.optum_diaggroup12

drop table if exists scratch_qli2b.patient;
SELECT ptid, birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active,
             to_date(cast(substring(first_month_active,5,2) AS int) || '/' || cast(substring(first_month_active,1,4) AS int), 'MM/YYYY') as first_month_active2,
             to_date(cast(substring(last_month_active,5,2) AS int) || '/' || cast(substring(last_month_active,1,4) AS int), 'MM/YYYY') as last_month_active2
INTO scratch_qli2b.patient
FROM patient;
      
/* all patients, first / last attemp */
select max(diag_date) from diagnosis; /* 2019-09-30; after the weekend of 6-26-20 2019-12-31; query 8-28-21 2020-12-31 */
select max(diag_date) from native_1234.diagnosis; /* 2019-12-31 */
select max(last_month_active) from patient; /* 202012 */

drop table if exists scratch_qli2b.index_date2;
select ptid, count(diag_date) AS count_date INTO scratch_qli2b.index_date2
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date < '2018-10-01' 
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('BIP')))
GROUP BY ptid;

select * from scratch_qli2b.index_date2 limit 50;

drop table if exists scratch_qli2b.index_date3;

select ptid, count_date INTO scratch_qli2b.index_date3
from scratch_qli2b.index_date2
where count_date >= 2;

select count(*) from scratch_qli2b.index_date2; /* 4,764,350 bipolar diagnosis prior to 10-1-18 */
select count(*) from scratch_qli2b.index_date3; /* 3,189,226 more than 2 bipolar codes prior to 10-1-18*/

drop table if exists scratch_qli2b.index_date4;

select ptid, max(diag_date) AS index_date INTO scratch_qli2b.index_date4
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date < '2018-09-01' 
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('BIP'))
      AND ptid in (select ptid from scratch_qli2b.index_date3))
GROUP BY ptid;

select count(*) from scratch_qli2b.index_date4 where index_date < '2015-10-01' ; /* 432,527 */
select count(*) from scratch_qli2b.index_date4 where index_date >= '2015-10-01'; /* 2,756,699 */

drop table if exists scratch_qli2b.index_date;

select * into scratch_qli2b.index_date
from scratch_qli2b.index_date4
where index_date >= '2015-10-01'; /* the most recent diagnosis after 10-1-15 and before 9-1-18 */

select count(*) from scratch_qli2b.index_date; /* 4,803,223 MDD; 754,622 BIP; 5,236,240 AFD; 
                                                  4,764,350 MDD 6-26-20; 
                                                  2,785,922 6-28-20 requiring at least two MDD codes and most recent MDD diagnosis to be after 2015-10-1 */
                                                 -- 399,906 6-28-20 requiring at least two BIP codes and most recent BIP diagnosis to be after 2015-10-1

/* ever attempter ICD-9 or -10 before 2018-10-01*/
drop table if exists scratch_qli2b.SA_Case_ever_attempters;

SELECT ptid INTO scratch_qli2b.SA_Case_ever_attempters
FROM (SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diagnosis_status IN ('Diagnosis of')
      AND  diag_date < '2018-10-01' 
      AND  problem_list IN ('N')
      AND  diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))); 

select count(*) from scratch_qli2b.SA_Case_ever_attempters; /* 468,896 all periods; 
                                                               429,057 before 2018-10-01 5-30 same # as 5-3 same version of database 
                                                               427,546 6-26-20 12-31-19 version of database */

/* codes below adapted from Grace Wang's code from 10-30-18 */

drop table if exists scratch_qli2b.SA_Case_ICD10; --must be owner of relational database table sa_case_icd10;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_sa_date INTO scratch_qli2b.SA_Case_ICD10_last_attempt
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' 
      AND diag_date < '2019-10-01' 
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
      )
GROUP BY ptid;

drop table if exists scratch_qli2b.SA_Case_ICD10_first_attempt;

SELECT DISTINCT ptid,
       Min(diag_date) AS index_sa_date INTO scratch_qli2b.SA_Case_ICD10_first_attempt
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' 
      AND diag_date < '2019-10-01' 
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
      )
GROUP BY ptid;

select count(distinct ptid) from scratch_qli2b.SA_Case_ICD10; --14,161 BIP; 5,357 BIP; 15,500 AFD; 14228 BIP 6-26; 11061 6-28-20  --last attempt
select count(distinct ptid) from scratch_qli2b.SA_Case_ICD10_first_attempt; --15500 AFD; 14228 BIP 6-26; 11061 6-28-20 
                                                                            --41209 all comers

drop table if exists scratch_qli2b.SA_1_ICD10; /* last attempt */-- must be owner of relation sa_1_icd10;
drop table if exists scratch_qli2b.SA_1_ICD10_last_attempt;
SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active2,
       last_month_active2 INTO scratch_qli2b.SA_1_ICD10_last_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.patient
      WHERE LENGTH(birth_yr) = 4
      AND gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Case_ICD10_last_attempt b ON a.ptid = b.ptid;

drop table if exists scratch_qli2b.SA_1_ICD10_first_attempt;  

SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active2,
       last_month_active2 INTO scratch_qli2b.SA_1_ICD10_first_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.patient
      WHERE LENGTH(birth_yr) = 4
      AND gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      AND ptid not in (select ptid from scratch_qli2b.SA_Case_ever_attempters) 
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Case_ICD10_first_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_1_ICD10; -- 12,961 BIP; 4,801 BIP; 14,171 AFD (case control model); 12981 BIP 6-26; 10096 6-28-2020 

select count(distinct ptid) from scratch_qli2b.SA_1_ICD10_first_attempt; --8,120 BIP; 2,499 BIP; 9,016 AFD; 8170 BIP 6-26; 6003 6-28-2020 
                                                      --32143 all comers first attempt 7-13-20

DROP TABLE if exists scratch_qli2b.SA_control_ICD10_last_attempt;

SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.SA_control_ICD10_last_attempt
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' --case control cohort
      AND diag_date < '2019-10-01'
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
)
AND   diag_date >= '2018-10-01' --case control cohort
AND   diag_date < '2019-10-01'
AND   diagnosis_cd_type IN ('ICD10') --- added
AND   diagnosis_status IN ('Diagnosis of', 'History of') --- added
AND   problem_list IN ('N') --added
GROUP BY ptid;

DROP TABLE if exists scratch_qli2b.SA_control_ICD10_first_attempt;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.SA_control_ICD10_first_attempt
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' --case control cohort
      AND   diag_date < '2019-10-01'
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
)
AND   diag_date >= '2018-10-01' --case control cohort
AND   diag_date < '2019-10-01'
AND   diagnosis_cd_type IN ('ICD10') --- added
AND   diagnosis_status IN ('Diagnosis of', 'History of') --- added
AND   problem_list IN ('N') --added
AND   ptid not in (select ptid from scratch_qli2b.SA_Case_ever_attempters) 
GROUP BY ptid;

select count(distinct(ptid)) from scratch_qli2b.SA_control_ICD10_first_attempt; /* 2,175,617; 1480880 6-28-20 MDD; 182007 BIP*/
                                                                  --25,637,723 7-13-2020
DROP TABLE if exists scratch_qli2b.SA_0_ICD10_last_attempt;

SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active2,
       last_month_active2 INTO scratch_qli2b.SA_0_ICD10_last_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Control_ICD10_last_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_0_ICD10; /* 2108060; 1441227 6-28-20 */

DROP TABLE if exists scratch_qli2b.SA_0_ICD10_first_attempt;

SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active2,
       last_month_active2 INTO scratch_qli2b.SA_0_ICD10_first_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Control_ICD10_first_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_0_ICD10;
-- 2,141,062 MDD; 283,856 BIP; 2,281,597 AFD case control cohort 5-29-20 (controls could have attempts before identification period; 
-- 2,108,060 MDD 6-26   
-- 1441227 MDD 6-28 
-- 187435 BIP 6-28
select count(distinct ptid) from scratch_qli2b.SA_0_ICD10_first_attempt; --2,199,143 6-10-20, controls cannot have attempts prior to identification period
-- 2033226 MDD 6-26
--1,384,624 MDD 6-28
--168,872 BIP 6-28
--24,312,308 all comers 7-13-2020

DROP TABLE if exists scratch_qli2b.SA_GRP_last_attempt_20200530;
DROP TABLE if exists scratch_qli2b.SA_GRP_last_attempt_20200628; /* change dur calculation and requiring two BIP diagnosis */

SELECT DISTINCT *,  datediff(month, first_month_active2, last_month_active2) as DUR,
       datediff(month, first_month_active2, index_date) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_last_attempt_20200628
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.SA_1_ICD10_last_attempt
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.SA_0_ICD10_last_attempt)
WHERE datediff(month, first_month_active2, index_date) >= 36;

DROP TABLE if exists scratch_qli2b.SA_GRP_first_attempt_200530;
DROP TABLE if exists scratch_qli2b.SA_GRP_first_attempt_200628;
select count(*) from scratch_qli2b.SA_GRP_first_attempt_200628; /* 17172447 */

SELECT DISTINCT *,datediff(month,first_month_active2, last_month_active2) as DUR,
       datediff(month,first_month_active2,index_date) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_first_attempt_200628
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.SA_1_ICD10_first_attempt
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active2,
             last_month_active2
      FROM scratch_qli2b.SA_0_ICD10_first_attempt)
WHERE datediff(month,first_month_active2,index_date) >= 36;

select min(first_month_active) from scratch_qli2b.SA_GRP_last_attempt_20200530; --200601
select max(first_month_active) from scratch_qli2b.SA_GRP_last_attempt_20200530; --201712

select min(first_month_active) from scratch_qli2b.SA_GRP_first_attempt_200530; --200601
select max(first_month_active) from scratch_qli2b.SA_GRP_first_attempt_200530; --201712

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_last_attempt_20200530
GROUP BY grp_num;

--MDD
--grp_num=1 12,491
--grp_num=0 2,103,256

--BIP
--grp_num=1 4,671
--grp_num=0 278,207

--AFD
--grp_num=1 13625
--grp_num=0 2,239,572

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.SA_GRP_last_attempt_20200628
GROUP BY grp_num;
--BIP
--grp_num=1	3240
--grp_num=0	175638

--all comers 
--grp_num=1	26,951
--grp_num=0	17,260,529

select * into scratch_qli2b.SA_GRP_last_attempt_20200628c
from scratch_qli2b.SA_GRP_last_attempt_20200628
where age >= 13;

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.SA_GRP_last_attempt_20200628c
GROUP BY grp_num;
--grp_num=1	26,350
--grp_num=0	15,702,733

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_first_attempt_200530
GROUP BY grp_num;

--MDD
--grp_num=1 7,781
--grp_num=0 2,103,256

--BIP
--grp_num=1 2,417
--grp_num=0 278,207

--AFD
--grp_num=1 8624
--grp_num=0 2239572 updated to be 2158095 on 6/10/20

--AFD
--grp_num=1 8618
--grp_num=0 2158095

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_first_attempt_200628
GROUP BY grp_num;
--BIP
--grp_num=1	1596
--grp_num=0	157,681

--all comers
--grp_num=1	21546
--grp_num=	17150901

/* step 2 Run SAS matching code */

/* http://10.37.94.22:8080/scratch_upload */
drop table if exists scratch_qli2b.Optum_1_1_match_first_attempt;

CREATE TABLE scratch_qli2b.Optum_1_1_match_first_attempt 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);

drop table if exists scratch_qli2b.Optum_1_1_match_last_attempt;

CREATE TABLE scratch_qli2b.Optum_1_1_match_last_attempt 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);

COPY scratch_qli2b.Optum_1_1_match_first_attempt FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_all_comers_first_attempt_07132020.txt_2020-07-13_202924'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
    
COPY scratch_qli2b.Optum_1_1_match_last_attempt FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_06282020.txt_2020-06-28_170213'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
        
select * from stl_load_errors;   

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.Optum_1_1_match_first_attempt
GROUP BY grp_num; -- true	20972 8-29-21 query still return 20972

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.Optum_1_1_match_last_attempt
GROUP BY grp_num; --13545; true	11864 6-26 3 yr history ; 9082 6-28 MDD; 3229 6-28 BIP; true	26350 all comers

drop table if exists scratch_qli2b.SA_GRP_last_attempt_200530b; 
drop table if exists scratch_qli2b.SA_GRP_last_attempt_200628b;

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.SA_GRP_last_attempt_20200503b
GROUP BY grp_num;
--grp_num	count
--1	28409
--0	28409


SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM ext_scratch_qli2b.SA_GRP_last_attempt_200628b
GROUP BY grp_num;
--grp_num	count
--1	26350
--0	26350


create table scratch_qli2b.SA_GRP_last_attempt_200628b as
(select * from scratch_qli2b.SA_GRP_last_attempt_20200628 where ptid in (select ptid from scratch_qli2b.Optum_1_1_match_last_attempt));

drop table if exists scratch_qli2b.SA_GRP_first_attempt_200530b;

create table scratch_qli2b.SA_GRP_first_attempt_200628b as
(select * from scratch_qli2b.SA_GRP_first_attempt_200628 where ptid in (select ptid from scratch_qli2b.Optum_1_1_match_first_attempt));

/* step 3 run Grace's SAS Enterprise code */

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_last_attempt_200530b
GROUP BY grp_num;  ---13545*2 13 years and above filtering in SAS

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_last_attempt_200628b
GROUP BY grp_num; --1	26350

select grp, count(distinct ptid) from scratch_qli2b.sau57603_SA_train_csv GROUP BY grp; --true	19763

drop table if exists scratch_qli2b.broad_test_all_comers_last_attempt;
select ptid, grp_num into scratch_qli2b.broad_test_all_comers_last_attempt
from scratch_qli2b.SA_GRP_last_attempt_20200628c
where ptid not in (select ptid from scratch_qli2b.sau57603_SA_train_csv);

select grp_num,
       COUNT(DISTINCT ptid) 
       from scratch_qli2b.broad_test_all_comers_last_attempt
       GROUP BY grp_num;
       --1	6587
--0	15682970
       
SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_first_attempt_200628b
GROUP BY grp_num; --1 20972

/* end here 7-13-2020 */

DROP TABLE if exists scratch_qli2b.medication_administrations;
create table scratch_qli2b.medication_administrations as 
(select * from native.medication_administrations where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and order_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.patient_reported_medications;
create table scratch_qli2b.patient_reported_medications as 
(select * from native.patient_reported_medications where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and reported_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.prescriptions_written;
create table scratch_qli2b.prescriptions_written as 
(select * from native.prescriptions_written where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and rxdate >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.diagnosis;
create table scratch_qli2b.diagnosis as 
(select * from native.diagnosis where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and diag_date >= '2015-10-1'
and diagnosis_cd_type IN ('ICD10'));

select a.*,b.diag_desc,b.diag_fst4_desc 
from native.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') ---PT251399534 ---PT226603638
and a.diagnosis_cd = b.diag_cd
order by diag_date;

select * from scratch_qli2b.lu_diagnosis b;

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in (select a.diagnosis_cd 
from scratch_qli2b.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') 
and a.diagnosis_cd = b.diag_cd);

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in ('R45851');

select distinct (source_id) from native.patient;

desc scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv;

select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1'); #410
select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 2'); # 47
select count(*) from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt'); #458
select * from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt') and diag_cd not in 
(select REPLACE(code, '.', '') from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1','Group 2'));
 
select * from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where code = '969.7';

select count(distinct ptid) from patient; /* 105,632,445 */

select * from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv where tc_level_code in ('2') and sui=1

select tcgpi_name from medi_span.mf2tcgpi where tcgpi_id like '58%' and tc_level_code = '08';

select distinct brnd_nm, gnrc_nm, ahfsclss_desc, ahfsclss from lu_ndc
where ahfsclss_desc ilike '%ntidepressant%' or ahfsclss_desc ilike '%REUPTAKE INHIBITOR%' 
or ahfsclss_desc ilike '%SEROTONIN MODULATOR%'
order by ahfsclss_desc;
 
select distinct brnd_nm, gnrc_nm, ahfsclss_desc, ahfsclss from lu_ndc where gnrc_nm ilike '%citalopram%';
select distinct brnd_nm, gnrc_nm, ahfsclss_desc, ahfsclss from lu_ndc where gnrc_nm ilike '%duloxetine%';
select distinct brnd_nm, gnrc_nm, ahfsclss_desc, ahfsclss from lu_ndc where brnd_nm ilike '%Symbyax%';
select distinct brnd_nm, gnrc_nm, ahfsclss_desc, ahfsclss from lu_ndc where gnrc_nm ilike '%vilazodone%';
select distinct brnd_nm, gnrc_nm, ahfsclss_desc, ahfsclss from lu_ndc where gnrc_nm ilike '%aripiprazole%';
