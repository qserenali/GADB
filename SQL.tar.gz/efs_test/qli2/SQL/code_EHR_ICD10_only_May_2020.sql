/* all comers first / last attemp */
select distinct sourceid from patient;

select sourceid, count(sourceid) from patient group by sourceid;

select distinct region from patient;

select region, count(region) from patient group by region;

select max(diag_date) from diagnosis; /* 2019-09-30 */

/* codes below adapted from Grace Wang's code from 10-30-18 */
drop table if exists scratch_qli2b.SA_Case_ICD10_last_attempt;

SELECT DISTINCT ptid,
       MAX(diag_date) AS index_sa_date INTO scratch_qli2b.SA_Case_ICD10_last_attempt
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' 
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt')))
GROUP BY ptid; 

drop table if exists scratch_qli2b.SA_Case_ICD10_first_attempt;
SELECT DISTINCT ptid,
       MIN(diag_date) AS index_sa_date INTO scratch_qli2b.SA_Case_ICD10_first_attempt
FROM (SELECT DISTINCT ptid,
             diag_date
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' 
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt')))
GROUP BY ptid; 

select count(distinct ptid) from scratch_qli2b.SA_Case_ICD10_last_attempt; --40146 (2018-10-1); table deleted now same as below 155,460 (2015-10-1) comment out probelm list; 42,294 (2018-01-01); 149,770 (2015-10-1)
select count(distinct ptid) from scratch_qli2b.SA_Case_ICD10_first_attempt; --40146 (2018-10-1) 

drop table if exists scratch_qli2b.SA_1_ICD10_last_attempt;
SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.SA_1_ICD10_last_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Case_ICD10_first_attempt b ON a.ptid = b.ptid;
  
select count(*) from scratch_qli2b.SA_1_ICD10_last_attempt; --37572

/* ever attempter ICD-9 or -10 before 2018-10-01*/
drop table if exists scratch_qli2b.SA_Case_ever_attempters;
SELECT ptid INTO scratch_qli2b.SA_Case_ever_attempters
FROM (SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diagnosis_status IN ('Diagnosis of')
      AND  diag_date < '2018-10-01' 
      AND  problem_list IN ('N')
      AND  diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))); 

select count(*) from scratch_qli2b.SA_Case_ever_attempters; /* 468896 all periods; 429057 before 2018-10-01 */

drop table if exists scratch_qli2b.SA_1_ICD10_first_attempt;  
SELECT DISTINCT a.ptid,
       index_sa_date,
       birth_yr,
       gender,
       race, ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.SA_1_ICD10_first_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      AND ptid not in (select ptid from scratch_qli2b.SA_Case_ever_attempters) 
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Case_ICD10_first_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_1_ICD10_last_attempt; --37207 case control model 5-3-2020
select count(distinct ptid) from scratch_qli2b.SA_1_ICD10_first_attempt; --31198

DROP TABLE if exists scratch_qli2b.SA_control_ICD10_last_attempt;
SELECT DISTINCT ptid,
       MAX(diag_date) AS index_control_date INTO scratch_qli2b.SA_control_ICD10_last_attempt
FROM diagnosis
WHERE ptid NOT IN (
SELECT DISTINCT ptid
      FROM diagnosis
      WHERE diag_date >= '2018-10-01' --case control cohort
      AND   diagnosis_cd_type IN ('ICD10')
      AND   diagnosis_status IN ('Diagnosis of', 'History of')
      AND   problem_list IN ('N')
      AND   diagnosis_cd IN (SELECT DISTINCT  diag_cd
                             FROM scratch_qli2b.optum_diaggroup12
                             WHERE diaggroup in ('Suicidal attempt'))
)
AND   diag_date >= '2018-10-01' --case control cohort
AND   diagnosis_cd_type IN ('ICD10') --- added
AND   diagnosis_status IN ('Diagnosis of', 'History of') --- added
AND   problem_list IN ('N') --added
GROUP BY ptid;

DROP TABLE if exists scratch_qli2b.SA_0_ICD10_last_attempt;
SELECT DISTINCT a.ptid,
       index_control_date,
       birth_yr,
       gender,
       race,  ethnicity, region,
       first_month_active,
       last_month_active INTO scratch_qli2b.SA_0_ICD10_last_attempt
FROM (SELECT ptid,
             birth_yr,
             gender,
             race, ethnicity, region,
             first_month_active,
             last_month_active
      FROM patient
      WHERE LENGTH(birth_yr) = 4
      AND   gender IN ('Female','Male')
      AND region not in ('Other/Unknown')	--added 7-9-2019
      ) a 
  RIGHT JOIN scratch_qli2b.SA_Control_ICD10_last_attempt b ON a.ptid = b.ptid;

select count(distinct ptid) from scratch_qli2b.SA_0_ICD10_last_attempt; -- 24,225,402 case control cohort 5-3-20

DROP TABLE if exists scratch_qli2b.SA_GRP_last_attempt_20200503;
SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_last_attempt_20200503
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_1_ICD10_last_attempt
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_0_ICD10_last_attempt)
WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) >= 2;

DROP TABLE if exists scratch_qli2b.SA_GRP_first_attempt_20200530;
SELECT DISTINCT *,cast(substring(last_month_active,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR,
       cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) as DUR1, --added requiring 2 years of data prior to index date
       cast(substring(index_date,1,4) AS int) - cast(birth_yr AS int) AS AGE INTO scratch_qli2b.SA_GRP_first_attempt_20200530
FROM (SELECT DISTINCT 1 AS grp_num,
             ptid,
             index_sa_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_1_ICD10_first_attempt
      UNION ALL
      SELECT DISTINCT 0 AS grp_num,
             ptid,
             index_control_date AS index_date,
             birth_yr,
             gender,
             race,
             ethnicity,
             region,
             first_month_active,
             last_month_active
      FROM scratch_qli2b.SA_0_ICD10_last_attempt)
WHERE cast(substring(index_date,1,4) AS int) - cast(substring(first_month_active,1,4) AS int) >= 2;

select min(first_month_active) from scratch_qli2b.SA_GRP_last_attempt_20200503; --200601
select max(first_month_active) from scratch_qli2b.SA_GRP_last_attempt_20200503; --201712

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_last_attempt_20200503
GROUP BY grp_num;

--grp_num=1 29,071
--grp_num=0 19,189,310

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_first_attempt_20200530
GROUP BY grp_num;

--grp_num=1 23292
--grp_num=0 19,189,310

/* step 2 Run Qingqin's matching code in SAS Studio */

/* Step 3 Run Grace's SAS enterprise Guide code in SAS Studio */

/* http://10.37.94.22:8080/scratch_upload */
drop table if exists scratch_qli2b.Optum_data_for_modeling_1_1_match_05032020;
CREATE TABLE scratch_qli2b.Optum_data_for_modeling_1_1_match_05032020 
(grp_num boolean,  
ptid char(11) NOT NULL,
MatchID int);

COPY scratch_qli2b.Optum_data_for_modeling_1_1_match_05032020 FROM 's3://itx-agu-scratch-import/Optum_data_for_modeling_1_1_match_05032020.txt_2020-05-03_231317'
    CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

create table scratch_qli2b.Optum_1_1_match_first_attempt
as select * from scratch_qli2b.Optum_1_1_match_MDD_first_attempt; --22656
        
select * from stl_load_errors;   

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.Optum_data_for_modeling_1_1_match_05032020
GROUP BY grp_num; --28409

/* end 5-30-2020 */

drop table if exists scratch_qli2b.SA_GRP_last_attempt_20200503b;
create table scratch_qli2b.SA_GRP_last_attempt_20200503b as
(select * from scratch_qli2b.SA_GRP_last_attempt_20200503 where ptid in (select ptid from scratch_qli2b.Optum_data_for_modeling_1_1_match_05032020));

drop table if exists scratch_qli2b.SA_GRP_first_attempt_200530b;
create table scratch_qli2b.SA_GRP_first_attempt_200530b as
(select * from scratch_qli2b.SA_GRP_first_attempt_20200530 where ptid in (select ptid from scratch_qli2b.Optum_1_1_match_first_attempt));

SELECT grp_num,
       COUNT(DISTINCT ptid)
FROM scratch_qli2b.SA_GRP_last_attempt_20200503b
GROUP BY grp_num;  ---28409*2 13 years and above filtering in SAS

/* end here 5-3-2020 */

DROP TABLE if exists scratch_qli2b.medication_administrations;
create table scratch_qli2b.medication_administrations as 
(select * from native.medication_administrations where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and order_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.patient_reported_medications;
create table scratch_qli2b.patient_reported_medications as 
(select * from native.patient_reported_medications where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and reported_date >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.prescriptions_written;
create table scratch_qli2b.prescriptions_written as 
(select * from native.prescriptions_written where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and rxdate >= '2015-10-1');

DROP TABLE if exists scratch_qli2b.diagnosis;
create table scratch_qli2b.diagnosis as 
(select * from native.diagnosis where ptid in (select ptid from scratch_qli2b.SA_GRP_20190521b)
and diag_date >= '2015-10-1'
and diagnosis_cd_type IN ('ICD10'));

select a.*,b.diag_desc,b.diag_fst4_desc 
from native.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') ---PT251399534 ---PT226603638
and a.diagnosis_cd = b.diag_cd
order by diag_date;

select * from scratch_qli2b.lu_diagnosis b;

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in (select a.diagnosis_cd 
from scratch_qli2b.diagnosis a,scratch_qli2b.lu_diagnosis b
where ptid in ('PT251399534') 
and a.diagnosis_cd = b.diag_cd);

select * from scratch_qli2b.optum_diaggroup12 where diag_cd in ('R45851');

select distinct (source_id) from native.patient;

desc scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv;

select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1'); #410
select count(*) from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 2'); # 47
select count(*) from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt'); #458
select * from scratch_qli2b.optum_diaggroup12 where diaggroup in ('Suicidal attempt') and diag_cd not in 
(select REPLACE(code, '.', '') from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where _group in ('Group 1','Group 2'));
 
select * from scratch_qli2b.sau2514_janssen_suicide_risk_mod_csv where code = '969.7';
