create table scratch_qli2b.gpiPred as
select * from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv;

create table scratch_qli2b.david_hilary_diag_final_all_20180807 as
select *, replace(icd_code, '.', '') as code1 from scratch_qli2b.sau2112_david_hilary_diag_final_; /* 2018 version */

/* redcapid,personid,ICD_Code,ICD_Version,FirstDiagYr,FirstDiagMo,lastDiagYr,lastDiagMo,total,flagUUHSC,flagUPDB,flagIHC 
cannot upload the data somehow at both http://services.rhealth.jnj.com/scratch_upload_auto and http://10.37.94.22:8080/scratch_upload server responded with 0 code */

CREATE TABLE scratch_qli2b.Diag_2Year_Details_20190730 (
   redcapid     bigint,
   personid     bigint, 
   icd_code     varchar(255),
   icd_version  bigint,
   diagYr	      bigint,
   diagMo       bigint,
   source	      varchar(255),
   LastWeekFlag varchar(255)
)

COPY scratch_qli2b.Diag_2Year_Details_20190730 FROM 's3://itx-agu-scratch-import/David_Hilary_Diag_2Year_Details_20190730.CSV_2020-01-26_145744'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY' csv quote as '"';

create table scratch_qli2b.Diag_2Year as
select * from scratch_qli2b.Diag_2Year_Details_20190730;

CREATE TABLE scratch_qli2b.AllDiag2019_20190730
(
   redcapid     bigint,
   personid     bigint, 
   icd_code     varchar(255),
   icd_version  bigint,
   firstdiagyr  bigint,
   firstdiagmo  bigint,
   lastdiagyr   bigint,
   lastdiagmo   bigint,
   total        bigint,
   flaguuhsc    varchar(255),
   flagupdb     varchar(255),
   flagihc      varchar(255)
);
/* redcapid,personid,ITEM,FirstDiagYr,FirstDiagMo,lastDiagYr,lastDiagMo,total,flagUUHSC,flagIHC */

select count (distinct redcapid) from scratch_qli2b.david_hilary_diag_final_all_20180807; /* 37008, 2018 version */

select * from scratch_qli2b.david_hilary_diag_final_all_20180807 where code1 like '2962%';

select max(to_date(lastdiagmo || '/' || lastdiagyr, 'MM/YYYY')) from scratch_qli2b.david_hilary_diag_final_all_20180807
where code1 in (select diag_cd from scratch_qli2b.optum_diaggroup12 where diaggroup in ('MDD')) 
and redcapid = 692601;

select max(to_date(lastdiagmo || '/' || lastdiagyr, 'MM/YYYY')) from scratch_qli2b.david_hilary_diag_final_all_20180807; /* owerall latest diagnosis 2018-07, latest death date is 2017-10 */

select max(to_date(lastdiagmo || '/' || lastdiagyr, 'MM/YYYY')) from scratch_qli2b.david_hilary_diag_final_all_20180807
where code1 in (select diag_cd from scratch_qli2b.optum_diaggroup12 where diaggroup in ('MDD')) 
and redcapid = 19569; /* 19569 is a oontrol */

drop table scratch_qli2b.out_mdd;

create table scratch_qli2b.out_mdd as
select redcapid, max(to_date(lastdiagmo || '/' || lastdiagyr, 'MM/YYYY')) 
from scratch_qli2b.david_hilary_diag_final_all_20180807
where code1 in (select diag_cd from scratch_qli2b.optum_diaggroup12 where diaggroup in ('MDD')) 
group by redcapid;

/*
[qli2@awsanbnva1151 scripts]$ more ../data/David_Hilary_CaseControlMatch_20180501.csv|grep 692601
692601,709590,836375,836554,839234,839603,F,1974
more ../data/David_Hilary_CaseControlMatch_20180501.csv|grep 19569
569605,1219569,561783,565004,565214,567202,M,1987
26250,19569,81784,129434,130231,154095,F,1927
*/
select * from scratch_qli2b.out_mdd where redcapid in ('692601','19569');

select count(*) from scratch_qli2b.out_mdd; /* 2955; 2971 on 3/7/19 after changing to optum_diaggroup12 */

select *  from scratch_qli2b.david_hilary_diag_final_all_20180807
where code1 in (select diag_cd from scratch_qli2b.optum_diaggroup12 where diaggroup in ('MDD')) 
and redcapid = 19569;

drop table scratch_qli2b.Redcap_Demographics_DATA;
drop table scratch_qli2b.sau2386_redcap_demographics_data_csv; /* failed */

/* Original_RedCapID,PersonID,UPDBArchiveID,affected,EnrollmentStatus,OMEID,LabID,SuicideCaseControl,Gender,DeathCertificateExist,StateNum,Race,Spanish,DAge,
Month_Birth,Year_Birth,Month_Death,Year_Death,Veteran,mannerdeath,EducationMax,EgoMaritalStatus,EgoOccupationCode80,EgoOccupationCode90,EgoNamPowersScore,
RedCapID */
CREATE TABLE scratch_qli2b.RedCapDemographics072019
(
   Original_redcapid      bigint,
   personid               bigint,
   updbarchiveid          bigint,
   affected               varchar(255),
   enrollmentstatus       varchar(255),
   omeid                  bigint,
   labid                  bigint,
   suicidecasecontrol     boolean,
   gender                 varchar(255),
   deathcertificateexist  varchar(255),
   statenum               varchar(255),
   race                   varchar(255),
   spanish                varchar(255),
   dage                   numeric(18),
   month_birth            bigint,
   year_birth             bigint,
   month_death            bigint,
   year_death             bigint,
   veteran                varchar(255),
   mannerdeath            varchar(255),
   educationmax           bigint,
   egomaritalstatus       varchar(255),
   egooccupationcode80    bigint,
   egooccupationcode90    bigint,
   EgoNamPowersScore      bigint,
   redcapid               bigint
);

COPY scratch_qli2b.RedCapDemographics072019 FROM 's3://itx-agu-scratch-import/CoonRedCapDemographics072019_Hilary.csv_2020-01-25_225443'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY' csv quote as '"';

select affected, count(*) 
from scratch_qli2b.RedCapDemographics072019
group by affected;
/*	100405
N	948
Y	19251 */

select count(*) from scratch_qli2b.RedCapDemographics072019 where suicidecasecontrol in ('true') and affected in ('N'); /* 948 */
 
select mannerdeath, count(*) from scratch_qli2b.RedCapDemographics072019 where suicidecasecontrol in ('true') and affected in ('N')
group by mannerdeath;
/*UNDETERMINED	3
Undetermined, if Injured Purposely or Accidentally	94
Accident	632
Homicide	61
NATURAL	2
Natural	23
Pending Investigation	40
ACCIDENT	7
	86*/

select suicidecasecontrol, count(*) 
from scratch_qli2b.RedCapDemographics072019 
group by suicidecasecontrol;
/* false	100405
true	20199*/

select * from scratch_qli2b.RedCapDemographics072019 where redcapid = 1205514;

/* https://askubuntu.com/questions/20414/find-and-replace-text-within-a-file-using-commands */
sed -i 's/Undetermined, if Injured Purposely or Accidentally/"Undetermined, if Injured Purposely or Accidentally"/g' CoonRedCapDemographics072019_Hilary.csv

select * from stl_load_errors;

create table scratch_qli2b.Redcap_Demographics_DATA as
select redcapid, suicidecasecontrol, to_date(month_death || '/' || year_death, 'MM/YYYY') as date_death 
from scratch_qli2b.sau2392_Redcap_Demographics_DATA; /* 111488 */

drop table scratch_qli2b.Redcap_Demographics_DATA012620;

create table scratch_qli2b.Redcap_Demographics_DATA012620 as
select redcapid, affected, suicidecasecontrol, to_date(month_death || '/' || year_death, 'MM/YYYY') as date_death 
from scratch_qli2b.RedCapDemographics072019; /* 120604 */

select max(to_date(month_death || '/' || year_death, 'MM/YYYY')) from scratch_qli2b.sau2392_Redcap_Demographics_DATA where affected in ('Y'); /* 2017-08-01 */

select max(to_date(month_death || '/' || year_death, 'MM/YYYY')) from scratch_qli2b.RedCapDemographics072019 where affected in ('Y'); /* 2018-11-01 */
select max(to_date(diagmo || '/' || diagyr, 'MM/YYYY')) from scratch_qli2b.Diag_2Year_Details_20190730; /* 2018-11-01 */
select min(to_date(diagmo || '/' || diagyr, 'MM/YYYY')) from scratch_qli2b.Diag_2Year_Details_20190730; /* 1993-08-01 */

select * from scratch_qli2b.Diag_2Year_Details_20190730
order by redcapid, diagyr, diagmo;

select * from scratch_qli2b.sau2392_Redcap_Demographics_DATA; 

select * from scratch_qli2b.Redcap_Demographics_DATA;

drop table scratch_qli2b.out_mdd2;

create table scratch_qli2b.out_mdd2 as
select a.date_death, a.suicidecasecontrol, b.* 
from scratch_qli2b.Redcap_Demographics_DATA a, scratch_qli2b.out_mdd b
where a.redcapid=b.redcapid;

select count(*) from scratch_qli2b.out_mdd2; /*2954; 2970 on 3/7/19 */

select redcapid, suicidecasecontrol, date_death, max, datediff(month, max, date_death) from scratch_qli2b.out_mdd2; /* max is the latest MDD diagnosis date */

select lastdiagmo || '/' || lastdiagyr as date1 from scratch_qli2b.david_hilary_diag_final_all_20180807
where code1 in (select diag_cd from scratch_qli2b.optum_diaggroup12 where diaggroup in ('MDD')) 
and redcapid = 692601;

select distinct redcapid from scratch_qli2b.david_hilary_diag_final_all_20180807; /* 37008 */

select distinct diaggroup from scratch_qli2b.optum_diaggroup12; /* 28 */

select * from lu_ndc where ahfsclss not in ('UNK') and ahfsclss_desc not in ('UNKNOWN') and gnrc_nm not in ('') limit 50;

select tcgpi_id from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv where tc_level_code in ('2') and sui=1; /* 41 */

select * from medi_span.mf2tcgpi where tcgpi_id like '58%' and tc_level_code = '08';
select * from scratch_qli2b.sau2113_david_hilary_med_final_a where item ilike 'mirtazapine%' ;

select * from scratch_qli2b.david_hilary_diag_final_all_20180807 where redcapid in (1223738, 1053039, 1089569, 1104116, 1129127, 1206353);
select * from scratch_qli2b.david_hilary_diag_final_all_20180807 where redcapid in (1229431, 23473, 109775, 123784, 1245164, 918697); 

select * from scratch_qli2b.sau2392_Redcap_Demographics_DATA where redcapid in (1223738, 1053039, 1089569, 1104116, 1129127, 1206353);
select * from scratch_qli2b.sau2392_Redcap_Demographics_DATA where redcapid in (1229431, 23473, 109775, 123784, 1245164, 918697); 

drop table scratch_qli2b.ref_date;
CREATE TABLE scratch_qli2b.ref_date
(
   redcapid   bigint,
   month_ref  bigint,
   year_ref   bigint,
   is_case    boolean
);
insert into scratch_qli2b.ref_date
        values(770607, 8, 1998, 1);
        
drop table scratch_qli2b.ref_date2;

CREATE TABLE scratch_qli2b.ref_date2
(
   ControlRedCapID   bigint,
   CaseRedCapID   bigint,
   month_ref  bigint,
   year_ref   bigint,
   is_case    boolean
);

create table scratch_qli2b.id_with_EMR as
select distinct redcapid from (
select distinct redcapid from scratch_qli2b.david_hilary_diag_final_all_20180807
union
select distinct redcapid from scratch_qli2b.sau2113_david_hilary_med_final_a);

create table scratch_qli2b.id_in_matching as 
(select CaseRedCapID as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol
union
select control1redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol
union
(select control2redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1)
union
(select control3redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control3redcapid !=1)
union
(select control4redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control4redcapid !=1)
union
(select control5redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control5redcapid !=1));

/* 2 subjects with only 1 matching controls 
UNION operator when used to combine multiple record sets, combines the rows from multiple SELECT statements and removes duplicates.*/

select count(*) from scratch_qli2b.id_in_matching; /* 110774 expect 18542*6-8=111244 */

create table scratch_qli2b.id_in_matching_case as 
select CaseRedCapID as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol;

select count(*) from scratch_qli2b.id_in_matching_case; /* 18542 */
select count(*) from scratch_qli2b.id_in_matching_control; /* 92232 */ 

select * from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid = 1; /* I guess these are the two subjects with only 1 matching control */

create table scratch_qli2b.id_in_matching_control as 
(select control1redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control1redcapid not in (select redcapid from scratch_qli2b.id_in_matching_case)
union
(select control2redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1 and control2redcapid not in (select redcapid from scratch_qli2b.id_in_matching_case))
union
(select control3redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control3redcapid !=1 and control3redcapid not in (select redcapid from scratch_qli2b.id_in_matching_case))
union
(select control4redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control4redcapid !=1 and control4redcapid not in (select redcapid from scratch_qli2b.id_in_matching_case))
union
(select control5redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control5redcapid !=1 and control5redcapid not in (select redcapid from scratch_qli2b.id_in_matching_case)));

select count(distinct CaseRedCapID) from scratch_qli2b.sau2444_david_hilary_casecontrol; /*18542 */
select count(distinct control1redcapid) from scratch_qli2b.sau2444_david_hilary_casecontrol; /*18542 */
select count(distinct control2redcapid) from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1;/* 18540 */
select count(distinct control3redcapid) from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1;/* 18540 */
select count(distinct control4redcapid) from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1;/* 18540 */
select count(distinct control5redcapid) from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1;/* 18540 */

select control2redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1 
and control2redcapid in (select control1redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union 
select control3redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union 
select control4redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union 
select control5redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol); /*n = 1, 1241287 */

select control2redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol where control2redcapid !=1 
and control2redcapid in (select CaseRedCapID  from scratch_qli2b.sau2444_david_hilary_casecontrol); /* 75 */

select * from scratch_qli2b.sau2441_david_danli_newredcapid2;
select count(*) from scratch_qli2b.sau2441_david_danli_newredcapid2; /* 26 */
select old_redcapid from scratch_qli2b.sau2441_david_danli_newredcapid2 where old_redcapid in (select redcapid from scratch_qli2b.sau2392_Redcap_Demographics_DATA); /* 0 */
select old_redcapid from scratch_qli2b.sau2441_david_danli_newredcapid2 where old_redcapid in (select redcapid from scratch_qli2b.id_with_EMR); /* 26 */

select new_redcapid from scratch_qli2b.sau2441_david_danli_newredcapid2 where new_redcapid in (select redcapid from scratch_qli2b.sau2392_Redcap_Demographics_DATA); /* 26 only demo use newredid*/
select old_redcapid from scratch_qli2b.sau2441_david_danli_newredcapid2 where old_redcapid in (select redcapid from scratch_qli2b.sau2392_Redcap_Demographics_DATA); /* after update sql, demo now also used oldredcapid*/

select new_redcapid from scratch_qli2b.sau2441_david_danli_newredcapid2 where new_redcapid in (select redcapid from scratch_qli2b.id_in_matching); /* 0 */
select old_redcapid from scratch_qli2b.sau2441_david_danli_newredcapid2 where old_redcapid in (select redcapid from scratch_qli2b.id_in_matching); /* 26 */

select count(*) from scratch_qli2b.id_with_EMR; /* 37783 */
select count(*) from scratch_qli2b.id_with_EMR where redcapid in (select redcapid from scratch_qli2b.id_in_matching); /* 37781 */
select * from scratch_qli2b.id_with_EMR where redcapid not in (select redcapid from scratch_qli2b.id_in_matching); /* n = 2; 948866; 1589364 */

select count(*) from scratch_qli2b.id_with_EMR where redcapid in (select redcapid from scratch_qli2b.id_in_matching_case); /* 7505 */
select count(*) from scratch_qli2b.id_with_EMR where redcapid in (select redcapid from scratch_qli2b.id_in_matching_control); /* 30276 */

select count(redcapid) from scratch_qli2b.sau2445_ref_date_csv where redcapid not in (select CaseRedCapID from scratch_qli2b.sau2446_ref_date2_csv); /* 401 cases without matching controls) */
select a.redcapid, affected, suicidecasecontrol from scratch_qli2b.sau2445_ref_date_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.redcapid = b.redcapid;

select affected, count(affected) from scratch_qli2b.sau2445_ref_date_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.redcapid = b.redcapid
group by affected; /* 7383 Y; 122 N */

desc scratch_qli2b.Redcap_Demographics_DATA;

select suicidecasecontrol, count(suicidecasecontrol) from scratch_qli2b.sau2445_ref_date_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.redcapid = b.redcapid
group by suicidecasecontrol; /* true 7505 */

select affected, count(affected) 
from scratch_qli2b.sau2445_ref_date_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b, scratch_qli2b.sau2445_ref_date_csv c
where a.redcapid = b.redcapid
and a.redcapid = c.redcapid
and a.redcapid in (select CaseRedCapID from scratch_qli2b.sau2446_ref_date2_csv)
group by affected; /* 6982 Y 122 N also need to remove No - need to have at least one matching control */

select affected, count(affected) 
from scratch_qli2b.sau2445_ref_date_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.redcapid = b.redcapid
and a.redcapid in (select CaseRedCapID from scratch_qli2b.sau2446_ref_date2_csv)
and a.redcapid not in (select control1redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control2redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control3redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control4redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control5redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol)
group by affected; /* 6781 Y 118 N also need to remove No - need to have at least one matching control - also exclude if the case ever shows up as control - not sure what the ref_date is (isong case date or control date)*/

select * from scratch_qli2b.sau2392_Redcap_Demographics_DATA where redcapid=1241287;/* this is the control matching to more than 1 case */
select * from scratch_qli2b.id_with_EMR where redcapid=1241287; /* no EMR */

select count(redcapid) from scratch_qli2b.sau2445_ref_date_csv where redcapid in (select CaseRedCapID from scratch_qli2b.sau2446_ref_date2_csv); /* 7104 */  

select b.*
from scratch_qli2b.sau2446_ref_date2_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.ControlRedCapID = b.redcapid; /* 30276 most had null affected*/

select affected, count(affected) 
from scratch_qli2b.sau2446_ref_date2_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.ControlRedCapID = b.redcapid
group by affected; /* N 1; null 0 No Y -that is good*/

/* more ref_date2.csv|cut -f2 -d ","|sort|uniq -c >t2
[qli2@awsanbnva1151 Utah]$ more ref_date2.csv|cut -f1 -d ","|sort|uniq -c >t1
[qli2@awsanbnva1151 Utah]$ awk '{if ($1!=1) print}' t1 #all had just one case
[qli2@awsanbnva1151 Utah]$ awk '{if ($1==1) print}' t1|head
      1 1000379
[qli2@awsanbnva1151 Utah]$ awk '{if ($1==1) print}' t2|wc -l
973
[qli2@awsanbnva1151 Utah]$ awk '{if ($1==2) print}' t2|wc -l
1057
[qli2@awsanbnva1151 Utah]$ awk '{if ($1==3) print}' t2|wc -l
1481
[qli2@awsanbnva1151 Utah]$ awk '{if ($1==4) print}' t2|wc -l
2148
[qli2@awsanbnva1151 Utah]$ awk '{if ($1==5) print}' t2|wc -l
2831
*/
drop table if exists scratch_qli2b.utah_pm_cohort;

/* create case control cohort */
create table scratch_qli2b.utah_pm_cohort as
((select a.redcapid, to_date(month_ref || '/' || year_ref, 'MM/YYYY') as date_ref, is_case, to_date(month_birth || '/' || year_birth, 'MM/YYYY') as date_birth, 
to_date(month_death || '/' || year_death, 'MM/YYYY') as date_death
from scratch_qli2b.sau2445_ref_date_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.redcapid = b.redcapid
and a.redcapid in (select CaseRedCapID from scratch_qli2b.sau2446_ref_date2_csv)
and a.redcapid not in (select control1redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control2redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control3redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control4redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol union
    select control5redcapid as redcapid from scratch_qli2b.sau2444_david_hilary_casecontrol)
and affected in ('Y')) /* 6781 */
union
(select ControlRedCapID as redcapid, to_date(month_ref || '/' || year_ref, 'MM/YYYY') as date_ref, '0' as is_case, to_date(month_birth || '/' || year_birth, 'MM/YYYY') as date_birth, 
to_date(month_death || '/' || year_death, 'MM/YYYY') as date_death from scratch_qli2b.sau2446_ref_date2_csv a, scratch_qli2b.sau2392_Redcap_Demographics_DATA b
where a.ControlRedCapID = b.redcapid)); /*30276 */

select count(*) from scratch_qli2b.utah_pm_cohort;/*37057 */

drop table if exists scratch_qli2b.utah_pm_cohort2;

create table scratch_qli2b.utah_pm_cohort2 as 
select date_ref, date_birth, date_death, is_case, b.*
from scratch_qli2b.utah_pm_cohort a, scratch_qli2b.active_period5 b
where a.redcapid = b.redcapid;

select count(*) from scratch_qli2b.utah_pm_cohort2; /* 25161 */

select * from scratch_qli2b.utah_pm_cohort where redcapid = 9585;

drop table if exists scratch_qli2b.utah_pm_cohort3;

create table scratch_qli2b.utah_pm_cohort3 as
select *, datediff(month, max_date_last, date_ref) as date_diff_max_ref, datediff(year, date_birth, date_ref) as ref_age,  
  datediff(month, date_ref, date_death) as sanity_check
from scratch_qli2b.utah_pm_cohort2;

select count(*) from scratch_qli2b.utah_pm_cohort3 where sanity_check < 0; /* 89 */

drop table if exists scratch_qli2b.utah_pm_cohort4;

select * from scratch_qli2b.utah_pm_cohort3 where date_diff_max_ref < 0; /* 43 */

create table scratch_qli2b.utah_pm_cohort4 as
select *
from scratch_qli2b.utah_pm_cohort3
where date_diff_max_ref <= 12;

select count(*) from scratch_qli2b.utah_pm_cohort4; /* 16574 */

select * from scratch_qli2b.utah_pm_cohort4 where sanity_check < 0; /* 83 */

drop table if exists scratch_qli2b.utah_pm_cohort5;

create table scratch_qli2b.utah_pm_cohort5 as
select *
from scratch_qli2b.utah_pm_cohort4
where sanity_check >= 0 or sanity_check is null;

select count(*) from scratch_qli2b.utah_pm_cohort5; /* 16491*/

select is_case, count(redcapid) from scratch_qli2b.utah_pm_cohort3 group by is_case; /* 4891 cases and 20270 controls */

drop table if exists scratch_qli2b.out_Suicidal_attempt;
drop table if exists scratch_qli2b.out_Suicidal_attempt_2;
drop table if exists scratch_qli2b.out_Suicidal_attempt_2a;
drop table if exists scratch_qli2b.out_Suicidal_attempt_2b;
drop table if exists scratch_qli2b.out_Suicidal_attempt_3;

create table scratch_qli2b.out_Suicidal_attempt as
        select redcapid, max(to_date(lastdiagmo || '/' || lastdiagyr, 'MM/YYYY')),
        max(to_date(firstdiagmo || '/' || firstdiagyr, 'MM/YYYY')) as max2
        from scratch_qli2b.david_hilary_diag_final_all_20180807
        where code1 in (select diag_cd from scratch_qli2b.optum_diaggroup11 where diaggroup in ('Suicidal attempt'))
        group by redcapid;
      
select * from scratch_qli2b.out_Suicidal_attempt;

create table scratch_qli2b.out_Suicidal_attempt_2 as
select a.date_ref, a.is_case, b.* from scratch_qli2b.utah_pm_cohort2 a, scratch_qli2b.out_Suicidal_attempt b
where a.redcapid=b.redcapid;

select * from scratch_qli2b.out_Suicidal_attempt_2;

create table scratch_qli2b.out_Suicidal_attempt_2a as
select redcapid, is_case, date_ref, max as max_Suicidal_attempt, datediff(month, max, date_ref) as diff_Suicidal_attempt from scratch_qli2b.out_Suicidal_attempt_2;
create table scratch_qli2b.out_Suicidal_attempt_2b as
select redcapid, is_case, date_ref, max2 as max_Suicidal_attempt, datediff(month, max2, date_ref) as diff_Suicidal_attempt from scratch_qli2b.out_Suicidal_attempt_2;

create table scratch_qli2b.out_Suicidal_attempt_3 as
select * from scratch_qli2b.out_Suicidal_attempt_2a where diff_Suicidal_attempt !=0 /*1477 */
union
select * from scratch_qli2b.out_Suicidal_attempt_2b where diff_Suicidal_attempt !=0 
and redcapid not in (select redcapid from scratch_qli2b.out_Suicidal_attempt_2a where diff_Suicidal_attempt !=0); /* 23 */

select * from scratch_qli2b.out_Suicidal_attempt_3;

drop table if exists scratch_qli2b.out_mdd;
drop table if exists scratch_qli2b.out_mdd2;

/* define active period for each redcapid based on the med/diag/proc */

create table scratch_qli2b.active_period as
(select redcapid, firstdiagyr, firstdiagmo, lastdiagyr, lastdiagmo from scratch_qli2b.sau2113_david_hilary_med_final_a
union
select redcapid, firstdiagyr, firstdiagmo, lastdiagyr, lastdiagmo from scratch_qli2b.sau2112_david_hilary_diag_final_
union
select redcapid, firstdiagyr, firstdiagmo, lastdiagyr, lastdiagmo from scratch_qli2b.sau2448_david_hilary_proc_final_); 

create table scratch_qli2b.active_period2 as
select redcapid, to_date(firstdiagmo || '/' || firstdiagyr, 'MM/YYYY') as date_first, to_date(lastdiagmo || '/' || lastdiagyr, 'MM/YYYY') as date_last 
from scratch_qli2b.active_period;

drop table if exists scratch_qli2b.active_period3;

create table scratch_qli2b.active_period3 as
select redcapid, min(date_first) as min_date_first, max(date_last) as max_date_last
from scratch_qli2b.active_period2
group by redcapid;

drop table if exists scratch_qli2b.active_period4;

create table scratch_qli2b.active_period4 as 
select redcapid, min_date_first, max_date_last, datediff(month, min_date_first, max_date_last) as date_diff_min_max from scratch_qli2b.active_period3;

select count(*) from scratch_qli2b.active_period4; /* 38609 */

drop table if exists scratch_qli2b.active_period5;

create table scratch_qli2b.active_period5 as
select * from scratch_qli2b.active_period4
where date_diff_min_max >= 36;

select count(*) from scratch_qli2b.active_period5; /* 25494 */

/* end of define active period for each redcapid based on the med/diag/proc */

desc scratch_qli2b.lu_diagnosis;

select a.active, a.diaggroup, a.diag_cd, a.icd_ver_cd, b.diag_desc 
from scratch_qli2b.optum_diaggroup11 a, scratch_qli2b.lu_diagnosis b where a.diag_cd = b.diag_cd;

select a.active, a.diaggroup, a.diag_cd, a.icd_ver_cd, b.diag_desc 
from scratch_qli2b.optum_diaggroup11 a, scratch_qli2b.lu_diagnosis b 
where diaggroup in ('MDD','depression') 
and a.diag_cd = b.diag_cd
order by icd_ver_cd, diag_cd;

delete from scratch_qli2b.optum_diaggroup11 where diaggroup in ('MDD') and diag_cd in ('F32', 'F33', 'F338');

desc scratch_qli2b.optum_diaggroup11;

create table scratch_qli2b.optum_diaggroup11b as
select active, 'MDD' as diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd
from scratch_qli2b.optum_diaggroup11
where diaggroup in ('depression') 
and diag_cd in ('F320', 'F321','F322','F323','F324','F325');

create table scratch_qli2b.optum_diaggroup12 as
select * from scratch_qli2b.optum_diaggroup11b
union
select * from scratch_qli2b.optum_diaggroup11;

select count(*) from scratch_qli2b.optum_diaggroup11; /*7277 */

select count(*) from scratch_qli2b.optum_diaggroup12; /* 7283 11-15-18 */

select tcgpi_id from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv where tc_level_code in ('2') and sui=1;
select * from scratch_qli2b.sau1250_worksheet_in_gpi_general_csv;

select tcgpi_name from medi_span.mf2tcgpi where tcgpi_id like '58%' and tc_level_code = '08';
select tcgpi_name from medi_span.mf2tcgpi where tcgpi_id like '58%' and tc_level_code = '08';
select * from medi_span.mf2tcgpi where tcgpi_id like '58%' and tc_level_code = '08';

create table scratch_qli2b.out_58 as
                        select redcapid, max(to_date(lastdiagmo || '/' || lastdiagyr, 'MM/YYYY'))
                        from scratch_qli2b.sau2113_david_hilary_med_final_a
                        where item ilike 'Mirtazapine%' or item ilike 'Brexanolone%' group by redcapid;
select * from scratch_qli2b.out_58;

create table scratch_qli2b.out_58_2 as
select a.date_ref, a.is_case, b.* from scratch_qli2b.utah_pm_cohort2 a, scratch_qli2b.out_58 b
where a.redcapid=b.redcapid;

select * from scratch_qli2b.out_58_2;

desc scratch_qli2b.optum_diaggroup12;
desc scratch_qli2b.lu_diagnosis;

SELECT DISTINCT  a.diag_cd, a.diag_desc, a.icd_ver_cd, b.diag_fst3_desc, b.diag_fst4_desc, mdc_cd_desc, c._group 
FROM scratch_qli2b.optum_diaggroup12 a, scratch_qli2b.lu_diagnosis b, scratch_qli2b.sau55842_janssen_suicide_risk c
                             WHERE diaggroup in ('Suicidal attempt') 
                             and a.diag_cd = b.diag_cd
                             and a.diag_cd = c.code1
                             order by a.diag_cd; --457 before joining with sau55842_janssen_suicide_risk; after joining with table c 456
                             
drop table if exists scratch_qli2b.optum_diaggroup12_with_desc;
                             
create table scratch_qli2b.optum_diaggroup12_with_desc as                             
SELECT DISTINCT a.diag_cd, b.diag_desc, a.icd_ver_cd, b.diag_fst3_desc, b.diag_fst4_desc, mdc_cd_desc 
FROM scratch_qli2b.optum_diaggroup12 a, scratch_qli2b.lu_diagnosis b 
                             WHERE diaggroup in ('Suicidal attempt') 
                             and a.diag_cd = b.diag_cd
                             order by a.diag_cd;
                              
select a.*, b._group
from scratch_qli2b.optum_diaggroup12_with_desc a left join scratch_qli2b.sau55842_janssen_suicide_risk b
on a.diag_cd = b.code1 
order by a.diag_cd;

select * from diagnosis where diagnosis_cd in ('T1491XA');

select * from scratch_qli2b.optum_diaggroup12 where diag_fst4_cd in ('T149');
select * from scratch_qli2b.optum_diaggroup13 where diag_fst4_cd in ('T149');

create table scratch_qli2b.optum_diaggroup13 as select * from scratch_qli2b.optum_diaggroup12; -- 9-29-2020

insert into scratch_qli2b.optum_diaggroup13
        values('1','Suicidal attempt', 'T1491XA', 'T14','T149','10');
                           
GRANT SELECT ON scratch_qli2b.optum_diaggroup12 TO ekogan;
GRANT SELECT ON scratch_qli2b.optum_diaggroup13 TO ekogan;

drop table if exists scratch_qli2b.optum_diaggroup13_with_desc;

create table scratch_qli2b.optum_diaggroup13_with_desc as                             
SELECT DISTINCT a.diag_cd, b.diag_desc, a.icd_ver_cd, b.diag_fst3_desc, b.diag_fst4_desc, mdc_cd_desc 
FROM scratch_qli2b.optum_diaggroup13 a left join scratch_qli2b.lu_diagnosis b 
on a.diag_cd = b.diag_cd
WHERE diaggroup in ('Suicidal attempt') 
order by a.diag_cd;  -- 458
                              
select a.*, b.*
from scratch_qli2b.optum_diaggroup13_with_desc a full join scratch_qli2b.sau55842_janssen_suicide_risk b
on a.diag_cd = b.code1 
order by b._group, a.diag_cd ;
