drop table scratch_qli2c.optum_diagGroup4;

CREATE TABLE scratch_qli2c.optum_diagGroup4
(
   unique_id int,
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

CREATE TABLE scratch_qli2c.optum_diagGroup5
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

/*111854 original, 111856 now*/
insert into scratch_qli2c.optum_diagGroup4 (unique_id, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd) 
select row_NUMBER() OVER (ORDER BY icd_ver_cd, diag_fst3_cd, diag_fst4_cd) as unique_id, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from lu_diagnosis
where diag_desc not in ('UNKNOWN DIAGNOSIS', 'NO DIAGNOSIS CODE')
order by icd_ver_cd, diag_fst3_cd, diag_fst4_cd;

insert into scratch_qli2c.optum_diagGroup5  
select active, 'MH' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where (unique_id between 96988 and 97636)
or (unique_id between 4782 and 5721);

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Overweight, obesity and other hyperalimentation' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst3_cd in ('E65','E66', 'E67','E68', '278');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Overweight and obesity' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('2780')
or diag_fst3_cd in ('E66');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Diseases of the circulatory system' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where (unique_id between 10660 and 12330)
or (unique_id between 99351 and 99958);

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Epilepsy and recurrent seizures' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst3_cd in ('345')
or diag_fst3_cd in ('G40');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'Migraine' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst3_cd in ('346')
or diag_fst3_cd in ('G43');

COPY scratch_qli2c.optum_diagGroup5 FROM 's3://itx-agu-scratch-import/icd_with_grouping.csv_2017-11-15_005702'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY';

delete from scratch_qli2c.optum_diagGroup5
where diagGroup in ('COPD', 'seizures', 'migraine');

insert into scratch_qli2c.optum_diagGroup5  
select active, 'COPD' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('4912')
or diag_fst3_cd in ('J44');

insert into scratch_qli2c.optum_diagGroup5  
select '1' as active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('5310','5312','5314','5316',
'5320','5322','5324','5326',
'5330','5332','5334','5336',
'5340','5342','5344','5346',
'4560','5307',
'4552','4555','4558','5997','6238','6266','7191','7847','7848','7863',
'4230','4590')
or diag_cd in ('53501','53511','53521','53531','53541','53551','53561',
'53783','45620','53082',
'56202','56203','56212','56213','56881','5693','56985','59381','56881')
or diag_fst3_cd in ('578','430','431','432');

insert into scratch_qli2c.optum_diagGroup5  
select '1' as active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup4 
where diag_fst4_cd in ('K250','K252','K254','K256',
'K260','K262','K264','K266',
'K270','K272','K274','K276',
'K280','K282','K284','K2806',
'N921','M250','I312')
or diag_cd in ('K2901','K2921','K2931','K2941','K2951','K2961','K2971','K2981','K2991',
'K31811','I8501','I8511','53021','K2211','K226',
'K5701','K5711','K5713','K5721','K5731','K5733','K5741','K5751','K5753','K5781','K5791','K5793',
'K661','K625','K5521','N280','K661','K920','K921','K922','R58')
or diag_fst3_cd in ('R31','I60','I61','I62','R04');

select diagGroup, count(diag_cd)  
from scratch_qli2c.optum_diagGroup5 
where diagGroup is not null 
group by diagGroup
order by diagGroup;

select count(*) from scratch_qli2c.optum_diagGroup5; 

drop table scratch_qli2c.optum_diagGroup6;

create table scratch_qli2c.optum_diagGroup6 as
select * from scratch_qli2c.optum_diagGroup4;

select count(*) from scratch_qli2c.optum_diagGroup5;

/*2066 optum_diagGroup6 update active tag using optum_diagGroup5*/
update scratch_qli2c.optum_diagGroup6
set active = 1
where diag_cd in (select distinct diag_cd from scratch_qli2c.optum_diagGroup5
where active = 1); /* 1961, now 2060 */

update scratch_qli2c.optum_diagGroup6 
set active = 0
where diag_cd in (select distinct diag_cd from scratch_qli2c.optum_diagGroup5
where active = 0); /* 61 */

update scratch_qli2c.optum_diagGroup6
set active = 1 where active is null; /*109832 rows affected 109571*/

CREATE TABLE scratch_qli2c.optum_diagGroup7
(
   active varchar(3),
   Diaggroup varchar(100),
   diag_cd         varchar(10),
   diag_fst3_cd    varchar(3),
   diag_fst4_cd    varchar(4),
   icd_ver_cd      char(2)
);

insert into scratch_qli2c.optum_diagGroup7  
select active, 'MH' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where (unique_id between 96988 and 97636)
or (unique_id between 4782 and 5721);

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Overweight, obesity and other hyperalimentation' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst3_cd in ('E65','E66', 'E67','E68', '278');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Overweight and obesity' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst4_cd in ('2780')
or diag_fst3_cd in ('E66');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Diseases of the circulatory system' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where (unique_id between 10660 and 12330)
or (unique_id between 99351 and 99958);

insert into scratch_qli2c.optum_diagGroup7  
select active, 'COPD' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst4_cd in ('4912')
or diag_fst3_cd in ('J44');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Epilepsy and recurrent seizures' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst3_cd in ('345')
or diag_fst3_cd in ('G40');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'Migraine' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst3_cd in ('346')
or diag_fst3_cd in ('G43');

insert into scratch_qli2c.optum_diagGroup7  
select active, 'MB' as Diaggroup, diag_cd, diag_fst3_cd, diag_fst4_cd, icd_ver_cd 
from scratch_qli2c.optum_diagGroup6 
where diag_fst4_cd in ('5310','5312','5314','5316',
'5320','5322','5324','5326',
'5330','5332','5334','5336',
'5340','5342','5344','5346','4560','5307',
'4552','4555','4558','5997','6238','6266','7191','7847','7848','7863')
or diag_cd in ('53501','53511','53521','53531','53541','53551','53561','53783','45620','53082','56202','56203','56212','56213','56881','5693','56985','59381','56881')
or diag_fst3_cd in ('578','430','431','432','423','459');

COPY scratch_qli2c.optum_diagGroup7 FROM 's3://itx-agu-scratch-import/icd_with_grouping.csv_2017-11-15_005702'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'DD-MON-YY'; /* this file needs to be updated with the one without COPD, seisures, and migraine */

select count (*) from scratch_qli2c.optum_diagGroup5 where diagGroup in ('COPD', 'seisures', 'migraine'); /* 166 */
select distinct (diagGroup) from scratch_qli2c.optum_diagGroup5 order by diagGroup;

update scratch_qli2c.optum_diagGroup7
set active = 0
where diag_cd in (select a.diag_cd
from lu_diagnosis a right outer join scratch_qli2c.Optum_diagGroup5 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1'));

/* not sure why these 4 codes was missed */
select *
from lu_diagnosis a right outer join scratch_qli2c.Optum_diagGroup7 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1');


create table scratch_stellaqing.optum_diagGroup8 as
select * from scratch_qli2c.optum_diagGroup7;

update scratch_stellaqing.optum_diagGroup8
set active = 0
where diag_cd in (select a.diag_cd
from lu_diagnosis a right outer join scratch_qli2c.Optum_diagGroup7 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1'));

select *
from lu_diagnosis a right outer join scratch_stellaqing.Optum_diagGroup8 b 
on a.diag_cd = b.diag_cd
and a.diag_fst3_cd = b.diag_fst3_cd
and a.diag_fst4_cd= b.diag_fst4_cd
and a.icd_ver_cd = b.icd_ver_cd
where diag_desc ilike '%remis%' and active in  ('1');

select count(*) from scratch_qli2c.optum_diagGroup7; /* 6478 */ 

create table scratch_qli2c.test7 as
select diagGroup, count (diag_cd) from scratch_qli2c.optum_diagGroup7 group by diagGroup;

create table scratch_qli2c.test5 as
select diagGroup, count (diag_cd) from scratch_qli2c.optum_diagGroup5 group by diagGroup;

select a.*, b.diagGroup as diagGroup2, b.count as count2 from scratch_qli2c.test5 a full outer join scratch_qli2c.test7 b on a.diagGroup=b.diagGroup where a.count != b.count;

select * from scratch_qli2c.optum_diagGroup7 where diagGroup in ('Overweight and obesity');
select * from scratch_qli2c.optum_diagGroup5 where diagGroup in ('Overweight and obesity');

create table scratch_qli2c.mh_note
(diag_cd         varchar(10),
 diag_desc       varchar(100)
 );
 
COPY scratch_qli2c.mh_note FROM 's3://itx-agu-scratch-import/MH_note.txt_2017-11-06_110834'
CREDENTIALS 'aws_access_key_id=AKIAJ2WTCGSDNWVQ7DAQ;aws_secret_access_key=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'
IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

CREATE TABLE scratch_qli2c.drug_class
(drug_class        varchar(150)
);

insert into scratch_qli2c.drug_class  
select distinct drug_class from scratch_qli2c.qing_medication_administrations
union
select distinct drug_class from scratch_qli2c.qing_prescriptions_written
union
select distinct drug_class from scratch_qli2c.qing_patient_reported_medications;

drop table scratch_qli2c.drug_class;

drop table scratch_qli2c.drug_class2;

CREATE TABLE scratch_qli2c.drug_class2
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50)
);

insert into scratch_qli2c.drug_class2 
select distinct ndc, drug_class, 'medication_administrations' as source from scratch_qli2c.qing_medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source from scratch_qli2c.qing_prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source from scratch_qli2c.qing_patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source  from scratch_qli2c.qing_lu_ndc;

drop table scratch_qli2c.drug_class3; 

/* preferred */
CREATE TABLE scratch_qli2c.drug_class3
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass varchar(150)
);

CREATE TABLE scratch_qli2c.drug_class4
(ndc varchar(11),
drug_class        varchar(150),
source varchar(50),
superclass1 varchar(150),
superclass2 varchar(150)
);

insert into scratch_qli2c.drug_class3 
select ndc, drug_class, source, '' as superclass from scratch_qli2c.drug_class2;

insert into scratch_qli2c.drug_class4 
select ndc, drug_class, source, '' as superclass1, '' as superclass2 from scratch_qli2c.drug_class2;

/*from scratch */
insert into scratch_qli2c.drug_class3 
select distinct ndc, drug_class, 'medication_administrations' as source, '' as superclass from scratch_qli2c.qing_medication_administrations
union
select distinct ndc, drug_class, 'prescriptions_written' as source, '' as superclass from scratch_qli2c.qing_prescriptions_written
union
select distinct ndc, drug_class, 'patient_reported_medications' as source, '' as superclass from scratch_qli2c.qing_patient_reported_medications
union
select distinct ndc, ahfsclss_desc as drug_class, 'lu_ndc' as source, '' as superclass  from scratch_qli2c.qing_lu_ndc;
 
update scratch_qli2c.drug_class4
set superclass1 = 'antidepressants'
where drug_class ilike '%ANTIDEPRESSANTS%' or drug_class in ('Selective serotonin reuptake inhibitor (SSRI) antidepressants','Antidepressants; miscellaneous','Tricyclic antidepressants','SELECTIVE-SEROTONIN REUPTAKE INHIBITORS','Serotonin and norepinephrine reuptake inhibitors','SEROTONIN MODULATORS','SEL.SEROTONIN,NOREPI REUPTAKE INHIBITOR');

update scratch_qli2c.drug_class4
set superclass1 = 'antipsychotics'
where drug_class ilike '%Antipsychotics%';

update scratch_qli2c.drug_class4
set superclass1 = 'anxiolytics'
where drug_class ilike '%Anxiolytics%';

update scratch_qli2c.drug_class4
set superclass2 = 'sedative hypnotics'
where drug_class ilike '%Sedative hypnotics%' or drug_class ilike '%Sedative-hypnotics%'
or drug_class ilike '%SEDATIVES,AND HYPNOTICS%' or drug_class like '%SEDATIVES & HYPNOTICS%' or drug_class ilike '%SEDATIVE/HYP%';

update scratch_qli2c.drug_class3
set superclass = 'antidepressants'
where drug_class ilike '%ANTIDEPRESSANTS%' or drug_class in ('Selective serotonin reuptake inhibitor (SSRI) antidepressants','Antidepressants; miscellaneous','Tricyclic antidepressants','SELECTIVE-SEROTONIN REUPTAKE INHIBITORS','Serotonin and norepinephrine reuptake inhibitors','SEROTONIN MODULATORS','SEL.SEROTONIN,NOREPI REUPTAKE INHIBITOR','Monoamine oxidase (MAO) inhibitors');

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'antipsychotics' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Antipsychotics%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'anxiolytics' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Anxiolytics%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'sedative hypnotics' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Sedative hypnotics%' or drug_class ilike '%Sedative-hypnotics%'
or drug_class ilike '%SEDATIVES,AND HYPNOTICS%' or drug_class like '%SEDATIVES & HYPNOTICS%' or drug_class ilike '%SEDATIVE/HYP%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Antimanic agents' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Antimanic agents%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'statins' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%HMG & CoA reductase inhibitors (statins)%'
or drug_class ilike '%HMG & CoA reductase inhibitor combinations; statin & various%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Antidiabetic' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Antidiabetic combination agents%'
or drug_class ilike '%Antidiabetic agents%'
or drug_class ilike '%Insulin%'
or drug_class ilike '%Glucagon-like peptide 1 receptor agonists; and other misc. diabetes agents'
or drug_class ilike '%Thiazides & related agents';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'HIV antivirals' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike 'HIV antivirals%'   
or drug_class ilike 'HIV antiviral%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Opioid dependence drug therapy' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike 'Opioid dependence drug therapy%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Narcotic Analgesics' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Narcotic & analgesic combinations%'
or drug_class ilike '%Narcotic agonist analgesics%'; 

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Centrally-acting analgesics' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Centrally-acting analgesics%';  

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'analgesics' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%analgesic%'; 

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Anticonvulsants' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Anticonvulsants%'; 

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'chemotherapeutic' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%chemotherapeutic%'
or drug_class ilike '%Mitotic inhibitors%'
or drug_class ilike '%MTOR inhibitors%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Antihypertensive' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Antihypertensive%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Anticoagulants' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Factor Xa inhibitors%'
or drug_class ilike '%Anticoagulants%';

insert into scratch_qli2c.drug_class3
select ndc, drug_class, source, 'Migraine agents' as superclass
from scratch_qli2c.drug_class4
where drug_class ilike '%Migraine agents%';

select count(*) from scratch_qli2c.drug_class3; /*539554*/

/* scratch_qli2c.icdcategorygrouping has decimal point, scratch_qli2c.icdcategorygrouping2 without decimal point and corrects trailing space data loading issyes, but 300.0 and 300.00 all became 300 also there is lower letter */
CREATE TABLE scratch_qli2c.icdcategorygrouping3
(
   code               varchar(10)     NOT NULL,
   diagnosis_cd_type  varchar(10),
   notes              varchar(300),
   category           varchar(100)
);
insert into scratch_qli2c.icdcategorygrouping3
select upper(code),diagnosis_cd_type,notes, category from scratch_qli2c.icdcategorygrouping2;


/* new control random 2% */
create table scratch_qli2c.control1 as
select ptid from scratch_qli2c.random1 where ptid not in (select * from scratch_stellasw.indexid); 
;
select count (distinct ptid) from scratch_qli2c.control; /* 621595 */
select count (distinct ptid) from scratch_stellawangsw.control;
select count (distinct ptid) from scratch_qli2c.control1; /*313674*/
select count (distinct ptid) from scratch_stellawangsw.sui; /*241,253*/
select count (distinct ptid) from scratch_stellasw.sui; /*241,253*/
select count (distinct ptid) from scratch_stellasw.indexid; /*241,253*/

/*total_cohort=control+suicide*/ 
CREATE TABLE scratch_qli2c.total_cohort 
AS
SELECT DISTINCT ptid
FROM scratch_qli2c.control1
UNION
SELECT DISTINCT ptid
FROM scratch_stellasw.sui;

/* total_cohort=control+suicide with case/control status */ 
CREATE TABLE scratch_qli2c.total_cohort2 
AS
SELECT DISTINCT ptid, 'Control' AS CAT 
FROM scratch_qli2c.control1
UNION
SELECT DISTINCT ptid, 'Case' as CAT
FROM scratch_stellasw.sui;

CREATE TABLE scratch_qli2c.total_cohort3 
AS
(SELECT DISTINCT a.ptid, diagnosis_cd AS diag,
     diag_date, 'Control' AS CAT 
FROM scratch_qli2c.control1 a,  scratch_qli2c.qing_diagnosis b
where a.ptid=b.ptid
and b.diagnosis_status IN ('Diagnosis of')
AND b.problem_list = 'N'
UNION
SELECT DISTINCT ptid, diag,
     diag_date, CAT
FROM scratch_stellasw.sui);

/* what kind of diagnosis for control really doesn't matter, just want a date when the patient shows up in the system using the diagnosis table alone */
CREATE TABLE scratch_qli2c.control2 
AS
SELECT DISTINCT control1.ptid, diagnosis_cd AS diag, diag_date, 'Control' AS CAT /*, diagnosis_status,  problem_list */
FROM scratch_qli2c.control1 left outer join scratch_qli2c.qing_diagnosis 
on control1.ptid=qing_diagnosis.ptid;

/*
CREATE TABLE scratch_qli2c.control3
as SELECT DISTINCT ptid, diag, diag_date,  cat
where diagnosis_status not in ('History of', 'Family history of', 'Not recorded', 'Possible diagnosis of', 'Other diagnosis status')
*/

CREATE TABLE scratch_qli2c.total_cohort4 
AS
(SELECT DISTINCT ptid, diag, diag_date, CAT 
FROM scratch_qli2c.control2 
UNION
SELECT DISTINCT ptid, diag, diag_date, CAT
FROM scratch_stellasw.sui);
select count(distinct ptid) from scratch_qli2c.control2  where diag_date is null; /*45483 */

select count(distinct ptid) from scratch_qli2c.total_cohort4; /*554927 there are patients that do not have any Dx code */
select count(distinct ptid) from scratch_qli2c.total_cohort3; /*494034 */
select count(distinct ptid) from scratch_qli2c.total_cohort2; /*554,927*/
select ptid from scratch_qli2c.total_cohort2 where ptid not in (select ptid from scratch_qli2c.total_cohort3); /* 60893 */

select ptid from scratch_qli2c.total_cohort2 where ptid not in (select ptid from scratch_qli2c.total_cohort3) 
and ptid not in (select distinct ptid from scratch_qli2c.control2  where diag_date is null); /* 15410 */

select * from scratch_qli2c.qing_diagnosis where ptid = 'PT116704835'; /* some had Not recorded diagnostic status and did not make it to total_cohort3 */

select count(*) from scratch_qli2c.total_cohort; /*554,927*/
select count (distinct ptid) from scratch_qli2c.total_cohort /*554,927*/


/*use total cohort patient ID to extract tables*/

/*create temp table*/
/*_pos_episode_visit*/
create table scratch_qli2c.qing_pos_episode_visit as
select*from
_pos_episode_visit where ptid in (select * from scratch_qli2c.total_cohort);

create table scratch_qli2c.qing_version as
select*from
_version;

/*care_area*/
create table scratch_qli2c.qing_care_area as
select*from
care_area where ptid in (select * from scratch_qli2c.total_cohort);

/*cost_factor--no ptid column in this table*/
create table scratch_qli2c.qing_cost_factor as
select*from cost_factor;

/*diagnosis*/
create table scratch_qli2c.qing_diagnosis as
select* from diagnosis where ptid in (select * from scratch_qli2c.total_cohort);

/*encounter*/
create table scratch_qli2c.qing_encounter as
select* from encounter where ptid in (select * from scratch_qli2c.total_cohort);

/*encounter_provider---use encid to match*/
create table scratch_qli2c.qing_encounter_provider as
select* from encounter_provider; 

/*immunizations*/
create table scratch_qli2c.qing_immunizations as
select* from immunizations where ptid in (select * from scratch_qli2c.total_cohort);

/*inpatient_confinement*/
create table scratch_qli2c.qing_inpatient_confinement as
select* from inpatient_confinement where ptid in (select * from scratch_qli2c.total_cohort);

/*insurance*/
--drop table scratch_stellasw.qing_insurance
create table scratch_qli2c.qing_insurance as
select* from insurance where ptid in (select * from scratch_qli2c.total_cohort);

/*lab_results*/
create table scratch_qli2c.qing_lab_results as
select* from lab_results where ptid in (select * from scratch_qli2c.total_cohort);

/*labs*/
create table scratch_qli2c.qing_labs as
select* from labs where ptid in (select * from scratch_qli2c.total_cohort);

/*lu_abnl_cd*/
create table scratch_qli2c.qing_lu_abnl_cd as
select* from lu_abnl_cd; 

/*lu_ahfsclss*/
create table scratch_qli2c.qing_lu_ahfsclss as
select* from lu_ahfsclss; 

/*lu_bus_line*/
create table scratch_qli2c.qing_lu_bus_line as
select* from lu_bus_line; 

/*lu_cdhp*/
create table scratch_qli2c.qing_lu_cdhp as
select* from lu_cdhp; 

/*lu_cob*/
create table scratch_qli2c.qing_lu_cob as
select* from lu_cob;

/*lu_daw*/
create table scratch_qli2c.qing_lu_daw as
select* from lu_daw;

/*lu_diagnosis*/
create table scratch_qli2c.qing_lu_diagnosis as
select* from lu_diagnosis;

/*lu_dischstatus*/
create table scratch_qli2c.qing_lu_dischstatus as
select* from lu_dischstatus;

/*lu_drg*/
create table scratch_qli2c.qing_lu_drg as
select* from lu_drg;

/*lu_encounter*/
create table scratch_qli2c.qing_lu_encounter as
select* from lu_encounter;

/*lu_form_ind*/
create table scratch_qli2c.qing_lu_form_ind as
select* from lu_form_ind;

/*lu_form_typ*/
create table scratch_qli2c.qing_lu_form_typ as
select* from lu_form_typ;


/*lu_fst_fill*/
create table scratch_qli2c.qing_lu_fst_fill as
select* from lu_fst_fill;

/*lu_gnrc_ind*/
create table scratch_qli2c.qing_lu_gnrc_ind as
select* from lu_gnrc_ind;

/*lu_hccc*/
create table scratch_qli2c.qing_lu_hccc as
select* from lu_hccc;

/*lu_icd_flag*/
create table scratch_qli2c.qing_lu_icd_flag as
select* from lu_icd_flag;

/*lu_ipstatus*/
create table scratch_qli2c.qing_lu_ipstatus as
select* from lu_ipstatus;

/*lu_loc_cd*/
create table scratch_qli2c.qing_lu_loc_cd as
select* from lu_loc_cd;

/*lu_ndc*/
create table scratch_qli2c.qing_lu_ndc as
select* from lu_ndc;

/*lu_poa*/
create table scratch_qli2c.qing_lu_poa as
select* from lu_poa;

/*lu_pos*/
create table scratch_qli2c.qing_lu_pos as
select* from lu_pos;


/*lu_prc_typ*/
create table scratch_qli2c.qing_lu_prc_typ as
select* from lu_prc_typ;


/*lu_procedure*/
create table scratch_qli2c.qing_lu_procedure as
select* from lu_procedure;

/*lu_procmod*/
create table scratch_qli2c.qing_lu_procmod as
select* from lu_procmod; 

/*lu_product*/
create table scratch_qli2c.qing_lu_product as
select* from lu_product;

/*lu_provcat*/
create table scratch_qli2c.qing_lu_provcat as
select* from lu_provcat;

/*lu_rvnu_cd*/
create table scratch_qli2c.qing_lu_rvnu_cd as
select* from lu_rvnu_cd;

/*lu_specclss*/
create table scratch_qli2c.qing_lu_specclss as
select* from lu_specclss;

/*lu_tos_cd*/
create table scratch_qli2c.qing_lu_tos_cd as
select* from lu_tos_cd;


/*medical_claims*/
create table scratch_qli2c.qing_medical_claims as
select* from medical_claims where ptid in (select * from scratch_qli2c.total_cohort);

/*medication_administrations*/
create table scratch_qli2c.qing_medication_administrations as
select* from medication_administrations where ptid in (select * from scratch_qli2c.total_cohort);


/*member_detail*/
create table scratch_qli2c.qing_member_detail as
select* from member_detail where ptid in (select * from scratch_qli2c.total_cohort);

/*microbiology*/
create table scratch_qli2c.qing_microbiology as
select* from microbiology where ptid in (select * from scratch_qli2c.total_cohort);

/*nlp_biomarkers*/
create table scratch_qli2c.qing_nlp_biomarkers as
select* from nlp_biomarkers where ptid in (select * from scratch_qli2c.total_cohort);

/*nlp_custom*/
create table scratch_qli2c.qing_nlp_custom as
select* from nlp_custom where ptid in (select * from scratch_qli2c.total_cohort);

/*nlp_drug_rationale*/
create table scratch_qli2c.qing_nlp_drug_rationale as
select* from nlp_drug_rationale where ptid in (select * from scratch_qli2c.total_cohort);

/*nlp_measurement*/
create table scratch_qli2c.qing_nlp_measurement as
select* from nlp_measurement where ptid in (select * from scratch_qli2c.total_cohort);


/*nlp_sds*/
create table scratch_qli2c.qing_nlp_sds as
select* from nlp_sds where ptid in (select * from scratch_qli2c.total_cohort);


/*nlp_sds_family*/
create table scratch_qli2c.qing_nlp_sds_family as
select* from nlp_sds_family where ptid in (select * from scratch_qli2c.total_cohort);

/*observations*/
create table scratch_qli2c.qing_observations as
select* from observations where ptid in (select * from scratch_qli2c.total_cohort);


/*patient*/
create table scratch_qli2c.qing_patient as
select* from patient where ptid in (select * from scratch_qli2c.total_cohort);


/*patient_reported_medications*/
create table scratch_qli2c.qing_patient_reported_medications as
select* from patient_reported_medications where ptid in (select * from scratch_qli2c.total_cohort);

/*prescriptions_written*/
create table scratch_qli2c.qing_prescriptions_written as
select* from prescriptions_written where ptid in (select * from scratch_qli2c.total_cohort);

/*procedure*/
create table scratch_qli2c.qing_procedure as
select* from procedure where ptid in (select * from scratch_qli2c.total_cohort);

/*provider*/
create table scratch_qli2c.qing_provider as
select* from provider; 


/*rx_claims*/
create table scratch_qli2c.qing_rx_claims as
select* from rx_claims where ptid in (select * from scratch_qli2c.total_cohort);

/*visit*/
create table scratch_qli2c.qing_visit as
select* from visit where ptid in (select * from scratch_qli2c.total_cohort);

select min(diag_date) from diagnosis where diagnosis_cd_type = 'ICD9';/*2007-1-1*/
select max(diag_date) from diagnosis where diagnosis_cd_type = 'ICD9'; /*2017-3-31*/
select max(diag_date) from diagnosis where diagnosis_cd_type = 'ICD10'; /*2017-3-31*/
select min(diag_date) from diagnosis where diagnosis_cd_type = 'ICD10';/*2007-1-1*/
