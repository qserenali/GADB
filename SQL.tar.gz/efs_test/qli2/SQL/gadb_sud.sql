
/* PTSD */
drop table if exists gadb.pts_eur_freeze2_overall_results;
CREATE TABLE gadb.pts_eur_freeze2_overall_results
CREATE TABLE gadb.pts_all_freeze2_overall_results
CREATE TABLE gadb.pts_aam_freeze2_overall_results
(CHR	int,
SNP char(30), 	
BP int,
A1 char(200),
A2 char(200),
FRQ_A float,
FRQ_U float,
INFO float,
Odds_Ratio float,
SE float,	
P float,
ngt int,
Direction char(200),
HetISqt float,
HetDf float,
HetPVa float,
Nca int,
Nco int,
Neff float);

COPY gadb.pts_eur_freeze2_overall_results FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pts_eur_freeze2_overall.results'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
    
COPY gadb.pts_all_freeze2_overall_results FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pts_all_freeze2_overall.results'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
    
COPY gadb.pts_aam_freeze2_overall_results FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pts_aam_freeze2_overall.results'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';

drop table if exists gadb.pgc_format;
create table gadb.pgc_format as
SELECT *, 'pts_eur_freeze2_overall.results' as source_file
FROM gadb.pts_eur_freeze2_overall_results
union
SELECT *, 'pts_all_freeze2_overall.results' as source_file
FROM gadb.pts_all_freeze2_overall_results
union
SELECT *, 'pts_aam_freeze2_overall.results' as source_file
FROM gadb.pts_aam_freeze2_overall_results;

--occasionally the file extension was incorrect such as tar -xvzf opioid-exposed_vs._opioid-unexposed_controls_in_African-ancestry_cohorts.gz
CREATE TABLE gadb.opi_EXPvUNX_AFR_noAF_tbl
CREATE TABLE gadb.opi_EXPvUNX_EUR_noAF_tbl
CREATE TABLE gadb.opi_EXPvUNX_trans_ancestry_noAF_tbl
CREATE TABLE gadb.opi_DEPvEXP_AFR_noAF_tbl
CREATE TABLE gadb.opi_DEPvEXP_EUR_noAF_tbl
CREATE TABLE gadb.opi_DEPvEXP_trans_ancestry_noAF_tbl
CREATE TABLE gadb.opi_DEPvUNX_AFR_noAF_tbl
CREATE TABLE gadb.opi_DEPvUNX_EUR_noAF_tbl
CREATE TABLE gadb.opi_DEPvUNX_trans_ancestry_noAF_tbl
(SNP char(30),
A1 char(200),
A2 char(200),
Weight float,
Zscore float,
P float, 
HetISq float,
HetChiSq float,
HetDf float,   
HetPVal float,
Total_N int,
NCa int,
NCo int,
ngt int);

COPY gadb.opi_EXPvUNX_AFR_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.EXPvUNX_AFR.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
COPY gadb.opi_EXPvUNX_EUR_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.EXPvUNX_EUR.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';
COPY gadb.opi_EXPvUNX_trans_ancestry_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.EXPvUNX_trans.ancestry.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 
COPY gadb.pgc3_gwas FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pgc3_gwas.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 

-- 5 line malformed for opi.DEPvEXP_AFR.noAF.tbl --need to upload to s3 again
COPY gadb.opi_DEPvEXP_AFR_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.DEPvEXP_AFR.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY'; 
    
select * from stl_load_errors;
 
COPY gadb.opi_DEPvEXP_EUR_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.DEPvEXP_EUR.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';  
COPY gadb.opi_DEPvEXP_trans_ancestry_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.DEPvEXP_trans.ancestry.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';   
    
COPY gadb.opi_DEPvUNX_AFR_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.DEPvUNX_AFR.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';  
COPY gadb.opi_DEPvUNX_EUR_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.DEPvUNX_EUR.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';  
COPY gadb.opi_DEPvUNX_trans_ancestry_noAF_tbl FROM 's3://itx-bhq-scratch/scratch_prj_qli2/opi.DEPvUNX_trans.ancestry.noAF.tbl'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';  
    
drop table if exists gadb.pgc_format2;
create table gadb.pgc_format2 as
SELECT *, 'opi.EXPvUNX_AFR.noAF.tbl' as source_file
FROM gadb.opi_EXPvUNX_AFR_noAF_tbl
union
SELECT *, 'opi.EXPvUNX_EUR.noAF.tbl' as source_file
FROM gadb.opi_EXPvUNX_EUR_noAF_tbl
union
SELECT *, 'opi.EXPvUNX_trans.ancestry.noAF.tbl' as source_file
FROM gadb.opi_EXPvUNX_trans_ancestry_noAF_tbl
union
SELECT *, 'opi.DEPvEXP_EUR.noAF.tbl' as source_file
FROM gadb.opi_DEPvEXP_EUR_noAF_tbl
union
SELECT *, 'opi.DEPvEXP_trans.ancestry.noAF.tbl' as source_file
FROM gadb.opi_DEPvEXP_trans_ancestry_noAF_tbl
union
SELECT *, 'opi.DEPvUNX_AFR.noAF.tbl' as source_file
FROM gadb.opi_DEPvUNX_AFR_noAF_tbl
union
SELECT *, 'opi.DEPvUNX_EUR.noAF.tbl' as source_file
FROM gadb.opi_DEPvUNX_EUR_noAF_tbl
union
SELECT *, 'opi.DEPvUNX_trans.ancestry.noAF.tbl' as source_file
FROM gadb.opi_DEPvUNX_trans_ancestry_noAF_tbl;

/* Study 4 Alcohol dependence */
drop table if exists gadb.pgc_alcdep_eur_unrelated_aug2018;
CREATE TABLE gadb.pgc_alcdep_eur_unrelated_aug2018
CREATE TABLE gadb.pgc_alcdep_afr_unrelated_aug2018
(CHR	int,
SNP char(600),
BP int,
A1 char(500),
A2 char(500),
Zscore float,
P float, 
Weight float,
orig_SNP char(1000));

COPY gadb.pgc_alcdep_eur_unrelated_aug2018 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pgc_alcdep.eur_unrelated.aug2018_release_mod.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';  
COPY gadb.pgc_alcdep_afr_unrelated_aug2018 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pgc_alcdep.afr_unrelated.aug2018_release_mod.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'DD-MON-YY';  
    
select * from stl_load_errors;    

drop table if exists gadb.pgc_format3;
create table gadb.pgc_format3 as
SELECT *, snp || ':chr' || chr || ':' || bp || ':' || a1 || ':' || a2 as orig_snp2, 'pgc_alcdep.eur_unrelated.aug2018_release.txt' as sum_stat, 'Walters_2018' as folder, 'alcdep.eur' as phenotype
FROM gadb.pgc_alcdep_eur_unrelated_aug2018
union
SELECT *, snp || ':chr' || chr || ':' || bp || ':' || a1 || ':' || a2 as orig_snp2, 'pgc_alcdep.afr_unrelated.aug2018_release.txt' as sum_stat, 'Walters_2018' as folder, 'alcdep.afr' as phenotype
FROM gadb.pgc_alcdep_afr_unrelated_aug2018;

create table gadb.pgc_format3_b38 as
select a.*, b.chr as chr_hg38, b.bp as pos_hg38 
from gadb.pgc_format3 a, gadb.hg192hg38 b
where a.orig_snp2(+) = b.orig_snp;

select distinct * from gadb.pgc_format3_b38 where SNP in ('rs6265'); --hg19 11:27658369 (GRCh38)
                                                            -- 11:27679916 (GRCh37)
desc gadb.pgc3_gwas_b38;        
select count(*) from gadb.pgc_format3_b38; --102174122
INSERT INTO gadb.pgc3_GWAS_b38 (snp, chr, bp, a1, a2, p, chr_hg38, pos_hg38, source_file, reference) 
SELECT snp, cast(chr as varchar), bp, a1, a2, p, chr_hg38, pos_hg38, sum_stat as source_file, folder as reference FROM gadb.pgc_format3_b38; --102174122 rows affected

desc gadb.pgc_format3_b38;                                                    

/* Study 4 Cannabis Use Disorder */
CREATE TABLE gadb.CUD_AFR_full_public_11_14_2020
CREATE TABLE gadb.CUD_EUR_full_public_11_14_2020
(CHR int,
SNP char(30),
BP int,
A1 char(200),
A2 char(200),
Zscore float,
P float, 
NCa int,
NCo int,
Total_N int);

COPY gadb.CUD_AFR_full_public_11_14_2020 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/CUD_AFR_full_public_11.14.2020'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ' ' DATEFORMAT AS 'DD-MON-YY';  
COPY gadb.CUD_EUR_full_public_11_14_2020 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/CUD_EUR_full_public_11.14.2020'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ' ' DATEFORMAT AS 'DD-MON-YY'; 
    
drop table if exists gadb.pgc_format4;
create table gadb.pgc_format4 as
SELECT *, 'CUD_AFR_full_public_11.14.2020' as source_file
FROM gadb.CUD_AFR_full_public_11_14_2020
union
SELECT *, 'CUD_EUR_full_public_11.14.2020' as source_file
FROM gadb.CUD_EUR_full_public_11_14_2020;   

select * from stl_load_errors;

/*        
CREATE TABLE gadb.pgc_format_build_37
(CHR	int,
SNP char(600), 	
BP int,
A1 char(500),
A2 char(500),
FRQ_A float,
FRQ_U float,
INFO float,
Odds_Ratio float,
SE float,	
Zscore float,
P float,
ngt int,
Direction char(200),
HetISqt float,
HetChiSq float,
HetDf float,
HetPVa float,
Total_N int,
Nca int,
Nco int,
Neff float,
orig_SNP char(1000),
source_file char(300)); */

drop table if exists gadb.pgc3_GWAS_b38; 
 
CREATE TABLE gadb.pgc3_GWAS_b38 
(SNP varchar(600), 	
CHR	varchar(10),
BP int,
A1 varchar(500),
A2 varchar(500),
FRQ_A float,
FRQ_U float,
INFO float,
EFFECT_SIZE float,
SE float,	
P float,
ngt int,
Direction varchar(200),
HetISqt float,
HetDf float,
HetPVa float,
Nca int,
Nco int,
Neff_half float,
Neff float,
chr_hg38 varchar(100),        
pos_hg38 int,
TYPE_OF_EFFECT_SIZE varchar(5),
source_file varchar(300),
reference varchar(300));

--https://stackoverflow.com/questions/53533454/redshift-copy-command-append-replace-or-upsert
--The COPY command always appends data to a table.

COPY gadb.pgc3_GWAS_b38 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/pgc3_gwas.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL REMOVEQUOTES  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY'; --45874243 record(s) loaded successfully

select count(*) from gadb.pgc3_GWAS_b38;  --add 102,174,122 alcdep 
-- 45874243+102174122
--[1] 148048365
select count(*) from gadb.pgc3_GWAS_b38; --add 91,491,600 pgc3_mdd
--91491600+148048365
--[1] 239539965
select count(*) from gadb.pgc3_GWAS_b38; --add 110,280,198 ISGC+MVP
--110280198+239539965
--[1] 349,820,163
delete from gadb.pgc3_GWAS_b38 where source_file is null or source_file in ('');

select count(*) from gadb.pgc3_GWAS_b38_unique; --96,522,035

select * from gadb.pgc3_GWAS_b38 where source_file is null or source_file in ('') limit 5;
select * from gadb.pgc3_GWAS_b38 where source_file not in (select source_file from gadb.toc) limit 5; --no record returned

drop table if exists gadb.pgc3_GWAS_b38_unique;
create table gadb.pgc3_GWAS_b38_unique as
select distinct * from gadb.pgc3_GWAS_b38;

select distinct source_file from gadb.pgc3_GWAS_b38;
select count(distinct source_file) from gadb.pgc3_GWAS_b38;
select source_file, count(*) from gadb.pgc3_GWAS_b38 group by source_file;

create table gadb.toc as 
(select source_file, count(*) from gadb.pgc3_GWAS_b38_unique group by source_file);

select count(*) from gadb.pgc3_GWAS_b38 where source_file is null or source_file in (''); --224,458,803
select * from gadb.pgc3_GWAS_b38 where source_file is null or source_file in ('') limit 30;
 
select * from stl_load_errors;
          
insert into gadb.pgc_format_build_37
select * from gadb.pgc_format;

select * from gadb.pgc_format where SNP in ('rs6265');
select * from gadb.pgc_format2 where SNP in ('rs6265');--no chr/bp info
select * from gadb.pgc_format3 where SNP in ('rs6265'); --hg19
select * from gadb.pgc_format4 where SNP in ('rs6265');

select * from gadb.pgc_format where SNP in ('rs324420'); --PTSD
select * from gadb.pgc_format2 where SNP in ('rs324420'); --Opioid dependence
select * from gadb.pgc_format3 where SNP in ('rs324420'); --Alcohol dependence

drop table if exists gadb.sumstats_harmonized;
create table gadb.sumstats_harmonized 
(folder varchar(200),
Phenotype varchar(200),
sum_stat varchar(200),
snp varchar(200),
bp VARCHAR(20),
Effect_size_type varchar(64),
stat float,
pvalue float,
chr varchar(3),
A1 varchar(200),
A2 varchar(200),
N float,
NCON float,
NCAS float,
NEFF float,
Build varchar(30));

COPY gadb.sumstats_harmonized FROM 's3://itx-bhq-scratch/scratch_prj_qli2/sumstats-harmonized_X_only_except_Forstner_2021_Mullins_2021.csv'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'MM/DD/YYYY';
    
select count(*) from gadb.sumstats_harmonized; --107929

COPY gadb.sumstats_harmonized FROM 's3://itx-bhq-scratch/scratch_prj_qli2/sumstats-harmonized_except_Forstner_2021_Mullins_2021_and_X.csv'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER ',' DATEFORMAT AS 'MM/DD/YYYY';
select count(*) from gadb.sumstats_harmonized; --343963922 (343855993 loaded + 107929 from previous loading) indeed the effect of copy is append



drop table if exists gadb.sumstats_harmonized_b37;
create table gadb.sumstats_harmonized_b37 as
select *, snp || ':chr' || chr || ':' || bp || ':' || A1 || ':' || A2 as orig_snp from gadb.sumstats_harmonized
where build in ('GRCh37/hg19');

drop table if exists gadb.sumstats_harmonized_b36;
create table gadb.sumstats_harmonized_b36 as
select *, snp || ':chr' || chr || ':' || bp || ':' || A1 || ':' || A2 as orig_snp from gadb.sumstats_harmonized
where build in ('NCBI36/hg18');

drop table if exists gadb.hg192Hg38;

create table gadb.hg182Hg38
create table gadb.hg192Hg38
(chr varchar(200),
start int,
bp int,
orig_snp varchar(2000));

COPY gadb.hg182Hg38 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/unique_snps_in_hg18_to_be_lifted.out'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 0 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY';  --4759527 record(s) loaded successfully input is liftOver output
    
COPY gadb.hg192Hg38 FROM 's3://itx-bhq-scratch/scratch_prj_qli2/unique_snps_in_hg19_to_be_lifted.out'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 0 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY';

select * from stl_load_errors;  

drop table if exists gadb.sumstats_harmonized_b37_to_hg38;

create table gadb.sumstats_harmonized_b37_to_hg38 as
select a.*, b.chr as chr_hg38, b.bp as pos_hg38
from gadb.sumstats_harmonized_b37 a, gadb.hg192Hg38 b
where a.orig_snp (+) = b.orig_snp;

drop table if exists gadb.sumstats_harmonized_b36_to_hg38;

create table gadb.sumstats_harmonized_b36_to_hg38 as
select a.*, b.chr as chr_hg38, b.bp as pos_hg38
from gadb.sumstats_harmonized_b36 a, gadb.hg182Hg38 b
where a.orig_snp (+) = b.orig_snp;

drop materialized view gadb.sumstats_harmonized_hg38;

create materialized view gadb.sumstats_harmonized_hg38 as
(select * from gadb.sumstats_harmonized_b37_to_hg38
union
select * from gadb.sumstats_harmonized_b36_to_hg38);

drop table if exists gadb.custom_studies;

create table gadb.custom_studies
(CCB_INDEX_from_Original_BigTable_tab int,
 CCB_INDEX_for_ALL_FILES varchar(20),
 Publication_Title varchar(250),
 PMID varchar(50),
 GWAS_Catalog_Study_Accession varchar(50),
 In_GWAS_catalog varchar(50),
 In_GRASP varchar(50),
 In_either_GWAS_Catalog_or_GRASP varchar(10),
 Data_web_page varchar(250),
 Manuscript_link varchar(250),
 Author_year varchar(250),
 Folder_Name varchar(50),
 Filename varchar(250),
 Phenotype_abb varchar(100),
 Build varchar(30),
 snp_col_header varchar(100),
 bp_col_header varchar(100),
 Effect_size_Type varchar(100),
 stat_col_header varchar(200),
 pvalue_col_header varchar(100),
 chr_col_header varchar(100),
 A1_col_header varchar(100),
 A1_definition_per_README varchar(200),
 A2_col_header varchar(100),
 A2_definition_per_README varchar(200),
 N varchar(50),
 Is_Binary_Trait varchar(100),
 N_cases_from_QL_or_EL varchar(200),
 N_controls_from_QL_or_EL varchar(200),
 N_total_from_QL_or_EL varchar(200),
 NEFF varchar(200),
 N_cases_from_QL varchar(200),
 N_controls_from_QL varchar(200),
 N_total_from_QL varchar(200),
 pop_prev float,
 samp_prev float,
 File_size_from_QL varchar(500),
 N_SNPs_from_QL varchar(500),
 Workflow_Status varchar(1000));
 
/*,
 Liftover_required_to_GRCh38 varchar(100),
 Comments varchar(1000)); */
 
COPY gadb.custom_studies FROM 's3://itx-bhq-scratch/scratch_prj_qli2/GWAS_Template_2022-08-04.txt'
    CREDENTIALS 'aws_access_key_id=AKIAU4A3W7LKJJSW6CZU;aws_secret_access_key=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'
    IGNOREHEADER 1 BLANKSASNULL EMPTYASNULL  DELIMITER '\t' DATEFORMAT AS 'MM/DD/YYYY';
    
select * from stl_load_errors; 

SELECT distinct sum_stat from gadb.sumstats_harmonized;
SELECT distinct sum_stat from gadb.sumstats_harmonized where chr in ('X');
