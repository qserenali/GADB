select tcgpi_id from ext_scratch_qli2b.sau1250_worksheet_in_gpi_general_csv where tc_level_code in ('2') and sui=1

select * from ext_scratch_qli2b.sau1250_worksheet_in_gpi_general_csv;

select * from medi_span.mf2tcgpi where tcgpi_id like '58%' and tc_level_code = '08';

select * from medi_span.mf2tcgpi where tcgpi_id like '58%' and tc_level_code = '04';


select * from medi_span.mf2tcgpi where tcgpi_id like '59%' and tc_level_code = '02';
select * from medi_span.mf2tcgpi where tcgpi_id like '59%' and tc_level_code = '04';
select * from medi_span.mf2tcgpi where tcgpi_id like '59%' and tc_level_code = '08';
select * from medi_span.mf2tcgpi where tcgpi_name in ('Risperidone', 'Quetiapine', 'Olanzapine', 'Aripiprazole','Brexpiprazole', 'Lithium') and tc_level_code = '08';  
select * from medi_span.mf2tcgpi where tcgpi_id like '5907%' and tc_level_code = '08';
select * from medi_span.mf2tcgpi where tcgpi_id like '5925%' and tc_level_code = '08';

select * from medi_span.mf2tcgpi where tcgpi_name ilike 'milnacipran';
select * from medi_span.mf2tcgpi where tcgpi_id like '6250%' and tc_level_code = '04'; /* Fibromyalgia Agents */

select * from medi_span.mf2tcgpi where (tcgpi_id like '5816%' or tcgpi_id like '5818%')and tc_level_code = '04';

select * from medi_span.mf2tcgpi where (tcgpi_id like '5816%' or tcgpi_id like '5818%')and tc_level_code = '08'; --drug names easy to understand
 
/* SSRI & SNRI */
select a.*, c.ndc_upc_hri 
from medi_span.mf2tcgpi a, medi_span.mf2name b, medi_span.mf2ndc c  
where a.tcgpi_id = b.generic_product_identifier
and b.drug_descriptor_id = c.drug_descriptor_id
and (tcgpi_id like '5816%' or tcgpi_id like '5818%')and tc_level_code = '14';

/* all antidepressants */
select a.*, c.ndc_upc_hri 
from medi_span.mf2tcgpi a, medi_span.mf2name b, medi_span.mf2ndc c  
where a.tcgpi_id = b.generic_product_identifier
and b.drug_descriptor_id = c.drug_descriptor_id
and tcgpi_id like '58%' and tc_level_code = '14';

/* augmentation */
select a.*, c.ndc_upc_hri 
from medi_span.mf2tcgpi a, medi_span.mf2name b, medi_span.mf2ndc c  
where a.tcgpi_id = b.generic_product_identifier
and b.drug_descriptor_id = c.drug_descriptor_id
and (tcgpi_id like '59070070%' or tcgpi_id like '59153070%' or
  tcgpi_id like '59157060%' or tcgpi_id like '59250015%' or
  tcgpi_id like '59250020%' or tcgpi_id like '59500010%')   and tc_level_code = '14';

select * from medication_administrations where ndc = 58864084930; --an example code from medi_span did not return anything
select * from medi_span.mf2ndc where ndc_upc_hri = 51079016120; --an example code from Optum

select a.*, c.ndc_upc_hri 
from medi_span.mf2tcgpi a, medi_span.mf2name b, medi_span.mf2ndc c  
where a.tcgpi_id = b.generic_product_identifier
and b.drug_descriptor_id = c.drug_descriptor_id
and ndc_upc_hri = 51079016120; 

select * from medi_span.mf2tcgpi where tcgpi_id like '58%';

select * from 
